import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {resolve,dirname} from 'node:path';
import {randomBytes} from 'node:crypto';
import {openDb,createUser,checkPassword,digest,id,now} from './db.mjs';
const root = dirname(fileURLToPath(import.meta.url));
const fail = (status,message) => {const e = new Error(message); e.status=status; throw e;};
const txt = (v,max=200,required=false) => {
  if(typeof v !== 'string') v='';
  v=v.trim(); if(v.length>max) fail(400,`A field exceeds its ${max}-character limit.`);
  if(required && !v) fail(400,'Please complete all required fields.'); return v;
};
function normalizePhone(value,required=false){
  const s=txt(value,30).replace(/[\s()+-]/g,'');
  if(!s && !required) return '';
  const n=s.length===10?'91'+s:s;
  if(!/^91[6-9]\d{9}$/.test(n)) fail(400,'Use a valid 10-digit Indian mobile number (optionally +91).');
  return n;
}
async function body(req){
  if(!(req.headers['content-type']||'').startsWith('application/json')) fail(415,'Expected JSON.');
  let size=0; const chunks=[];
  for await(const chunk of req){size+=chunk.length;if(size>3*1024*1024) fail(413,'Upload too large (maximum 2 MB image).');chunks.push(chunk);}
  try {const result=JSON.parse(Buffer.concat(chunks).toString());if(!result||Array.isArray(result)||typeof result!=='object') throw Error();return result;}
  catch{fail(400,'Invalid JSON request.');}
}
export function createApp({dbPath,production=process.env.NODE_ENV==='production',origin=process.env.APP_ORIGIN}={}){
  if(production && (!origin || !origin.startsWith('https://'))) throw Error('Production requires APP_ORIGIN=https://your-domain');
  const db=openDb(dbPath);const limits=new Map();let requestCount=0;
  function rate(key,max=15){
    const t=Date.now();if(++requestCount%100===0) for(const [k,v] of limits) if(t>v.until) limits.delete(k);
    if(!limits.has(key) && limits.size>10000) fail(429,'Too many requests. Please try later.');
    const x=limits.get(key);if(!x||x.until<t) limits.set(key,{n:1,until:t+15*60*1000});
    else if(++x.n>max) fail(429,'Too many attempts. Please try again in 15 minutes.');
  }
  function user(req){
    const token=(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('ib_session='))?.slice(11);
    if(!token) return null;
    return db.prepare('SELECT u.id,u.email,u.name,u.role FROM users u JOIN sessions s ON s.user_id=u.id WHERE s.token_hash=? AND s.expires_at>?').get(digest(token),Date.now())||null;
  }
  function needUser(req,admin=false){const u=user(req);if(!u)fail(401,'Please sign in.');if(admin&&u.role!=='admin') fail(403,'Administrator access required.');return u;}
  const cookie = (token,age) => `ib_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${age}${production?'; Secure':''}`;
  function session(res,u){const token=randomBytes(32).toString('hex');db.prepare('DELETE FROM sessions WHERE expires_at<?').run(Date.now());db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(digest(token),u.id,Date.now()+7*86400000);res.setHeader('Set-Cookie',cookie(token,7*86400));}
  function ownerShop(shopId,u){const s=db.prepare('SELECT * FROM shops WHERE id=?').get(shopId);if(!s)fail(404,'Shop not found.');if(s.owner_id!==u.id)fail(403,'This shop belongs to another account.');return s;}
  function validate(data,u,complete=false){
    const clean={name:txt(data.name,100,complete),number:txt(data.number,30,complete),floor:txt(data.floor,50,complete),description:txt(data.description,1500,complete),hours:txt(data.hours,200),keywords:txt(data.keywords,500),phone:normalizePhone(data.phone,complete),whatsapp:normalizePhone(data.whatsapp),sample:false};
    if(!Array.isArray(data.categories)||data.categories.length>6) fail(400,'Choose up to six categories.');
    clean.categories=[...new Set(data.categories)];
    for(const cat of clean.categories) if(typeof cat!=='string'||!db.prepare('SELECT id FROM categories WHERE id=? AND active=1').get(cat)) fail(400,'Choose an active category.');
    if(complete && !clean.categories.length) fail(400,'Choose at least one category.');
    if(!Array.isArray(data.photos)||data.photos.length>3) fail(400,'Use up to three photos.');
    clean.photos=[...new Set(data.photos)];
    for(const asset of clean.photos) if(typeof asset!=='string'||!db.prepare('SELECT id FROM assets WHERE id=? AND owner_id=?').get(asset,u.id)) fail(400,'Invalid photo.');
    return clean;
  }
  const audit=(u,action,target)=>db.prepare('INSERT INTO audit_log VALUES(?,?,?,?,?)').run(id(),u.id,action,target,now());
  const server=http.createServer(async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob:; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
    res.setHeader('X-Frame-Options','DENY');res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');
    if(production)res.setHeader('Strict-Transport-Security','max-age=31536000');
    const json=(value,status=200)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));};
    try{
      const path=new URL(req.url,'http://localhost').pathname;const method=req.method;
      if(path.startsWith('/api/')){
        if(!['GET','HEAD'].includes(method)){
          const allowed=origin||`http://${req.headers.host}`;
          if(req.headers.origin!==allowed) fail(403,'Request origin is not allowed. Reload this page and try again.');
        }
        if(method==='GET'&&path==='/api/me')return json({user:user(req)});
        if(method==='GET'&&path==='/api/categories')return json(db.prepare('SELECT * FROM categories ORDER BY name').all());
        if(method==='POST'&&['/api/register','/api/login'].includes(path)){
          const b=await body(req);const email=txt(b.email,254,true).toLowerCase();
          rate('auth:'+req.socket.remoteAddress,25);rate('email:'+email,15);
          const password=b.password;
          if(typeof password!=='string'||!password.length||password.length>128)fail(400,'Enter a password of up to 128 characters.');
          if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))fail(400,'Enter a valid email address.');
          if(path==='/api/register'){
            if(password.length<12)fail(400,'Use a password of at least 12 characters.');
            const name=txt(b.name,80,true);
            if(db.prepare('SELECT id FROM users WHERE email=?').get(email))fail(409,'An account with this email already exists. Please sign in.');
            createUser(db,email,name,password);
          }
          const u=db.prepare('SELECT * FROM users WHERE email=?').get(email);
          if(!checkPassword(password,u?.password_hash))fail(401,'Email or password is incorrect.');
          // Rotate the browser session on login.
          const old=(req.headers.cookie||'').match(/(?:^|;\s*)ib_session=([^;]+)/)?.[1];
          if(old)db.prepare('DELETE FROM sessions WHERE token_hash=?').run(digest(old));
          session(res,u);return json({user:{id:u.id,name:u.name,email:u.email,role:u.role}});
        }
        if(method==='POST'&&path==='/api/logout'){
          const token=(req.headers.cookie||'').match(/(?:^|;\s*)ib_session=([^;]+)/)?.[1];
          if(token)db.prepare('DELETE FROM sessions WHERE token_hash=?').run(digest(token));res.setHeader('Set-Cookie',cookie('',0));return json({ok:true});
        }
        if(method==='GET'&&path==='/api/shops'){
          const params=new URL(req.url,'http://localhost').searchParams;
          const q=(params.get('q')||'').trim().toLowerCase().slice(0,200),cat=params.get('category');
          const rows=db.prepare('SELECT id,public_data,reviewed_at FROM shops WHERE published=1 AND public_data IS NOT NULL ORDER BY reviewed_at DESC').all().map(s=>({id:s.id,...JSON.parse(s.public_data),reviewedAt:s.reviewed_at}));
          return json(rows.filter(s=>(!cat||s.categories.includes(cat))&&(!q||[s.name,s.description,s.keywords,...s.categories.map(c=>db.prepare('SELECT name FROM categories WHERE id=?').get(c)?.name||'')].join(' ').toLowerCase().includes(q))));
        }
        const detail=path.match(/^\/api\/shops\/([a-f0-9]{32})$/);
        if(method==='GET'&&detail){const s=db.prepare('SELECT * FROM shops WHERE id=? AND published=1 AND public_data IS NOT NULL').get(detail[1]);if(!s)fail(404,'This shop is not publicly available.');return json({id:s.id,...JSON.parse(s.public_data),reviewedAt:s.reviewed_at});}
        if(method==='GET'&&path==='/api/owner/shops'){
          const u=needUser(req);const rows=db.prepare('SELECT * FROM shops WHERE owner_id=? ORDER BY created_at DESC').all(u.id);
          return json(rows.map(s=>{const sub=db.prepare('SELECT * FROM submissions WHERE shop_id=? ORDER BY created_at DESC,rowid DESC LIMIT 1').get(s.id);return {id:s.id,published:!!s.published,publicData:s.public_data?JSON.parse(s.public_data):null,submission:sub?{...sub,data:JSON.parse(sub.data)}:null};}));
        }
        if(method==='POST'&&path==='/api/owner/shops'){
          const u=needUser(req);rate('create:'+u.id,30);const b=await body(req);const data=validate(b,u);const sid=id();
          db.exec('BEGIN');try{db.prepare('INSERT INTO shops(id,owner_id,created_at) VALUES(?,?,?)').run(sid,u.id,now());db.prepare('INSERT INTO submissions(id,shop_id,data,status,created_at) VALUES(?,?,?,?,?)').run(id(),sid,JSON.stringify(data),'draft',now());db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}return json({id:sid},201);
        }
        const edit=path.match(/^\/api\/owner\/shops\/([a-f0-9]{32})(\/submit)?$/);
        if(edit&&['PUT','POST'].includes(method)){
          const u=needUser(req),sid=edit[1];ownerShop(sid,u);const existing=db.prepare("SELECT * FROM submissions WHERE shop_id=? AND status IN ('draft','pending')").get(sid);
          if(existing?.status==='pending')fail(409,'This listing is awaiting review. You can edit it after a decision.');
          if(method==='PUT'&&!edit[2]){
            const clean=validate(await body(req),u);
            if(existing)db.prepare('UPDATE submissions SET data=? WHERE id=?').run(JSON.stringify(clean),existing.id);
            else db.prepare('INSERT INTO submissions(id,shop_id,data,status,created_at) VALUES(?,?,?,?,?)').run(id(),sid,JSON.stringify(clean),'draft',now());
            return json({ok:true});
          }
          if(method==='POST'&&edit[2]){
            if(!existing)fail(400,'Save a draft before submitting.');
            validate(JSON.parse(existing.data),u,true);
            db.prepare("UPDATE submissions SET status='pending' WHERE id=?").run(existing.id);return json({ok:true});
          }
        }
        if(method==='POST'&&path==='/api/assets'){
          const u=needUser(req);rate('upload:'+u.id,50);const b=await body(req);
          if(typeof b.base64!=='string'||b.base64.length>2800000)fail(413,'Image must be smaller than 2 MB.');
          const bytes=Buffer.from(b.base64,'base64');if(!bytes.length||bytes.length>2*1024*1024)fail(413,'Image must be smaller than 2 MB.');
          let mime;if(bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))mime='image/png';
          else if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)mime='image/jpeg';
          else if(bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP')mime='image/webp';
          else fail(400,'Only PNG, JPEG and WebP photos are accepted.');
          const asset=id();db.prepare('INSERT INTO assets VALUES(?,?,?,?,?)').run(asset,u.id,mime,bytes,now());return json({id:asset},201);
        }
        const image=path.match(/^\/api\/assets\/([a-f0-9]{32})$/);
        if(method==='GET'&&image){
          const a=db.prepare('SELECT * FROM assets WHERE id=?').get(image[1]);if(!a)fail(404,'Photo not found.');
          const isPublic=db.prepare('SELECT public_data FROM shops WHERE published=1').all().some(s=>s.public_data&&JSON.parse(s.public_data).photos.includes(a.id));
          const u=user(req);if(!isPublic&&(!u||(u.id!==a.owner_id&&u.role!=='admin')))fail(404,'Photo not found.');
          res.writeHead(200,{'Content-Type':a.mime,'Cache-Control':'private, no-store'});return res.end(a.bytes);
        }
        if(method==='GET'&&path==='/api/admin/submissions'){
          needUser(req,true);return json(db.prepare("SELECT s.*,u.email AS owner_email FROM submissions s JOIN shops sh ON sh.id=s.shop_id JOIN users u ON u.id=sh.owner_id WHERE s.status='pending' ORDER BY s.created_at").all().map(s=>({...s,data:JSON.parse(s.data)})));
        }
        if(method==='GET'&&path==='/api/admin/shops'){
          needUser(req,true);return json(db.prepare('SELECT s.id,s.published,s.public_data,u.email FROM shops s JOIN users u ON s.owner_id=u.id WHERE s.public_data IS NOT NULL ORDER BY s.reviewed_at DESC').all().map(s=>({...s,data:JSON.parse(s.public_data),public_data:undefined})));
        }
        const review=path.match(/^\/api\/admin\/submissions\/([a-f0-9]{32})\/review$/);
        if(method==='POST'&&review){
          const u=needUser(req,true),b=await body(req);if(!['approve','reject'].includes(b.action))fail(400,'Invalid review action.');
          const sub=db.prepare("SELECT * FROM submissions WHERE id=? AND status='pending'").get(review[1]);if(!sub)fail(409,'This submission has already been reviewed or is not pending.');
          const reason=txt(b.reason,500,b.action==='reject');
          db.exec('BEGIN');try{
            db.prepare('UPDATE submissions SET status=?,reason=?,reviewer_id=?,reviewed_at=? WHERE id=?').run(b.action==='approve'?'approved':'rejected',reason,u.id,now(),sub.id);
            if(b.action==='approve')db.prepare('UPDATE shops SET public_data=?,published=1,reviewed_at=? WHERE id=?').run(sub.data,now(),sub.shop_id);
            audit(u,b.action,sub.id);db.exec('COMMIT');
          }catch(e){db.exec('ROLLBACK');throw e;}return json({ok:true});
        }
        const publish=path.match(/^\/api\/admin\/shops\/([a-f0-9]{32})\/publication$/);
        if(method==='POST'&&publish){const u=needUser(req,true),b=await body(req);if(typeof b.published!=='boolean')fail(400,'Invalid publication state.');const s=db.prepare('SELECT * FROM shops WHERE id=? AND public_data IS NOT NULL').get(publish[1]);if(!s)fail(404,'Approved shop not found.');db.prepare('UPDATE shops SET published=? WHERE id=?').run(b.published?1:0,s.id);audit(u,b.published?'publish':'unpublish',s.id);return json({ok:true});}
        if(method==='POST'&&path==='/api/admin/categories'){
          const u=needUser(req,true),b=await body(req),name=txt(b.name,60,true);
          if(db.prepare('SELECT id FROM categories WHERE name=?').get(name))fail(409,'Category already exists.');
          const cid=id();db.prepare('INSERT INTO categories(id,name) VALUES(?,?)').run(cid,name);audit(u,'category_create',cid);return json({id:cid},201);
        }
        const category=path.match(/^\/api\/admin\/categories\/([a-z0-9-]+)$/);
        if(method==='PUT'&&category){const u=needUser(req,true),b=await body(req);if(typeof b.active!=='boolean')fail(400,'Invalid category state.');if(!db.prepare('SELECT id FROM categories WHERE id=?').get(category[1]))fail(404,'Category not found.');db.prepare('UPDATE categories SET active=? WHERE id=?').run(b.active?1:0,category[1]);audit(u,'category_update',category[1]);return json({ok:true});}
        fail(404,'API endpoint not found.');
      }
      if(!['GET','HEAD'].includes(method))fail(405,'Method not allowed.');
      const staticFiles={'/app.js':['app.js','text/javascript'],'/style.css':['style.css','text/css'],'/favicon.svg':['favicon.svg','image/svg+xml']};
      if(path==='/health'){return json({ok:true});}
      const file=staticFiles[path]||['index.html','text/html'];
      const content=await readFile(resolve(root,'public',file[0]));res.writeHead(200,{'Content-Type':file[1]+'; charset=utf-8','Cache-Control':'no-cache'});res.end(method==='HEAD'?undefined:content);
    }catch(e){if(!e.status)console.error('Request failed:',e.message);if(!res.headersSent)json({error:e.status?e.message:'Something went wrong. Please try again.'},e.status||500);else res.end();}
  });
  return {server,db};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const {server}=createApp();const port=Number(process.env.PORT||3000),host=process.env.HOST||'127.0.0.1';
  server.listen(port,host,()=>console.log(`Indira Bhawan OS is running at http://${host}:${server.address().port}\nCreate an administrator with: npm run admin -- your-email@example.com`));
  server.on('error',e=>{console.error(e.message);process.exitCode=1;});
}
