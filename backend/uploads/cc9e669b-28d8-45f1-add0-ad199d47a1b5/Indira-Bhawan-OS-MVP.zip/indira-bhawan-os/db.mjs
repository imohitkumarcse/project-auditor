import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { randomBytes, scryptSync, timingSafeEqual, createHash } from 'node:crypto';
export const now = () => new Date().toISOString();
export const id = () => randomBytes(16).toString('hex');
export const digest = token => createHash('sha256').update(token).digest('hex');
export function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  return salt + ':' + scryptSync(password, salt, 64, {N:32768, maxmem:64*1024*1024}).toString('hex');
}
const dummyHash = hashPassword('unused-comparison-password');
export function checkPassword(password, stored) {
  const [salt, hash] = (stored || dummyHash).split(':');
  const actual = scryptSync(password, salt, 64, {N:32768,maxmem:64*1024*1024});
  return timingSafeEqual(actual, Buffer.from(hash, 'hex')) && Boolean(stored);
}
export function openDb(path = process.env.DB_PATH || './data/app.sqlite') {
  if (path !== ':memory:') mkdirSync(dirname(resolve(path)), {recursive:true});
  const db = new DatabaseSync(path);
  db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
  CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE COLLATE NOCASE, name TEXT NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'owner' CHECK(role IN ('owner','admin')), created_at TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS categories (id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE COLLATE NOCASE, active INTEGER NOT NULL DEFAULT 1);
  CREATE TABLE IF NOT EXISTS shops (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES users(id), public_data TEXT, published INTEGER NOT NULL DEFAULT 0, reviewed_at TEXT, created_at TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS submissions (id TEXT PRIMARY KEY, shop_id TEXT NOT NULL REFERENCES shops(id) ON DELETE CASCADE, data TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('draft','pending','approved','rejected')), reason TEXT NOT NULL DEFAULT '', reviewer_id TEXT REFERENCES users(id), created_at TEXT NOT NULL, reviewed_at TEXT);
  CREATE UNIQUE INDEX IF NOT EXISTS one_open_submission ON submissions(shop_id) WHERE status IN ('draft','pending');
  CREATE TABLE IF NOT EXISTS assets (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES users(id), mime TEXT NOT NULL, bytes BLOB NOT NULL, created_at TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS audit_log (id TEXT PRIMARY KEY, actor_id TEXT NOT NULL REFERENCES users(id), action TEXT NOT NULL, target_id TEXT NOT NULL, created_at TEXT NOT NULL);
  CREATE INDEX IF NOT EXISTS submissions_queue ON submissions(status,created_at);
  CREATE INDEX IF NOT EXISTS shop_owners ON shops(owner_id);`);
  const insert = db.prepare('INSERT OR IGNORE INTO categories(id,name) VALUES (?,?)');
  for (const [key,name] of [['computers','Computers & laptops'],['mobiles','Mobiles & accessories'],['components','Components & parts'],['repairs','Repairs & servicing'],['audio','Audio & entertainment'],['security','CCTV & security']]) insert.run(key,name);
  return db;
}
export function createUser(db, email, name, password, role = 'owner') {
  const userId = id();
  db.prepare('INSERT INTO users(id,email,name,password_hash,role,created_at) VALUES(?,?,?,?,?,?)').run(userId,email.toLowerCase(),name,hashPassword(password),role,now());
  return userId;
}
