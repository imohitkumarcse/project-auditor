import {randomBytes} from 'node:crypto';
import {openDb,hashPassword} from '../db.mjs';
const email=(process.argv[2]||'').trim().toLowerCase(),db=openDb();
try{const u=db.prepare('SELECT id FROM users WHERE email=?').get(email);if(!u)throw Error('Account not found. Usage: npm run reset-password -- existing-email@example.com');const password=randomBytes(18).toString('base64url');db.exec('BEGIN');db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(hashPassword(password),u.id);db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);db.exec('COMMIT');console.log(`New password for ${email}: ${password}\nAll previous sessions have been revoked. Account role is unchanged.`);}catch(e){console.error(e.message);process.exitCode=1;}finally{db.close();}
