import {mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {openDb} from '../db.mjs';
mkdirSync('backups',{recursive:true});const out=resolve('backups',`indira-bhawan-${new Date().toISOString().replace(/[:.]/g,'-')}.sqlite`),db=openDb();
try{db.prepare('VACUUM INTO ?').run(out);console.log(`Consistent database backup created: ${out}\nContains photos, accounts and session data. Store securely off this device.`);}finally{db.close();}
