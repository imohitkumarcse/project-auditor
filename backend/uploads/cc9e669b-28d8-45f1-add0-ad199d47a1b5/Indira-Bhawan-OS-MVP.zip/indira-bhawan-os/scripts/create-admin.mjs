import {randomBytes} from 'node:crypto';
import {openDb,createUser} from '../db.mjs';
const email=(process.argv[2]||'').trim().toLowerCase();
if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){console.error('Usage: npm run admin -- your-email@example.com');process.exit(1);}
const db=openDb();
try{
  if(db.prepare('SELECT id FROM users WHERE email=?').get(email))throw Error('This account already exists. Use the reset-password script to reset a password. Existing owners are not automatically promoted.');
  const password=randomBytes(18).toString('base64url');createUser(db,email,'Market administrator',password,'admin');
  console.log(`Administrator created: ${email}\nPassword (save it in a password manager): ${password}\nSign in at your running app’s /login page. This credential was generated on your computer.`);
}catch(e){console.error(e.message);process.exitCode=1;}finally{db.close();}
