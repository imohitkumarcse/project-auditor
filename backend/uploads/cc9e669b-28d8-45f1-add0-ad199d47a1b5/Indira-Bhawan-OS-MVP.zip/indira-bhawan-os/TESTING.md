# Validation performed

## Automated backend tests

Run `npm test` with Node.js 24. The suite uses a temporary database and local HTTP server, then removes test data. It does not change your application database.

18 passing tests cover:

1. Initial page and empty directory.
2. Cross-origin mutation rejection.
3. Registration, password requirements and prevention of administrator self-assignment.
4. Login errors and administrator sign-in.
5. Owner/anonymous denial of admin APIs.
6. Image format restrictions and private unpublished photo access.
7. Private drafts and Indian mobile number normalization.
8. Cross-owner edit and photo-attachment denial.
9. Incomplete drafts versus required submission fields.
10. Pending edit lock and public isolation.
11. Approval and public image access; repeated-review rejection.
12. Keyword/category filtering and zero results.
13. Pending edits preserve the public version; rejection needs a reason.
14. Revision after rejection; approved replacement removes public access to removed photos.
15. Unpublish and republish behavior.
16. Admin-only category management and inactive category restrictions.
17. Consistent SQLite snapshot reopened and checked for integrity, listing data and image data.
18. Session revocation on logout.

## Browser checks performed during development

Local Chromium, desktop width 1440 px and mobile width 390 px. The exercised workflow was registration → listing editor → image upload → submit → administrator sign-in → review → approve → public shop page → inspect WhatsApp link. No WhatsApp message or call was sent.

Screens inspected: home (light and dark), directory, search-empty state, sample shop, registration, login, owner empty dashboard, owner editor, pending dashboard, admin queue and category controls, approved shop detail, privacy and pilot notices. No horizontal page overflow or browser JavaScript errors were observed in that run.

## Not verified by these checks

Public hosting, Docker runtime, reverse proxy behavior, real email delivery (not implemented), external WhatsApp delivery, real shop facts, legal sufficiency, large-scale load, accessibility certification and a full operator disaster-recovery drill. This is not a security audit.
