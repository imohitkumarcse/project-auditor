# Indira Bhawan OS — runnable pilot MVP

A mobile-friendly electronics shop directory for Indira Bhawan, Prayagraj. Customers browse without an account. Shopkeepers submit listings. Administrators approve, return, unpublish or republish them.

**This is a runnable self-hosted MVP, not a public deployment.** Real shop information, shopkeeper consent, operator details and hosting still need to be supplied. No official market-association affiliation is claimed.

## 1. Requirements

- Node.js **24 LTS or newer**, with npm (https://nodejs.org/).
- Windows, macOS or Linux; a terminal and modern browser.
- No API keys, cloud accounts, paid services or third-party npm dependencies.
- Node's built-in `node:sqlite` may print an ExperimentalWarning. This is expected on Node 24.

## 2. Run it

Extract the ZIP, open a terminal inside the extracted `indira-bhawan-os` folder, then run:

```sh
node --version
npm start
```

Open **http://localhost:3000** in your browser. Keep the terminal running. To stop, press Ctrl+C.

You do **not** need `npm install`. The database is created automatically at `data/app.sqlite`.

### Create your administrator

In a second terminal in the same folder:

```sh
npm run admin -- your-email@example.com
```

Replace that example email with your actual administrator email. The command generates a strong password and prints it **on your computer**. Save it in a password manager, then sign in at http://localhost:3000/login. No email is sent and email ownership is not verified in this pilot.

If you forget an account password, the operator can run:

```sh
npm run reset-password -- existing-email@example.com
```

This prints a new random password and revokes that account's sessions. It does not change the account's role. There is no password-reset email service or in-app password-change screen in this version.

### Optional sample shops

The app starts with an empty directory. To explore the UI with clearly fictional shops:

```sh
npm run seed-demo
```

Refresh the browser. Six listings marked **Sample listing** appear. They have no phone numbers and no working enquiry actions.

Before real launch, remove them:

```sh
npm run seed-demo -- --remove
```

This removes only listings flagged as samples; it does not delete real listings. No sample accounts or credentials are bundled in the ZIP.

## 3. Try the complete workflow

1. Use a private/incognito browser window to create a **shopkeeper** account at `/register` (12-character minimum password).
2. Go to **My shops → Add a shop**. Enter the shop name, number, floor, description, an Indian business mobile number and at least one category. Add an optional WhatsApp number and up to three photos.
3. **Save draft** supports incomplete listings. **Save & submit for review** requires the essential fields.
4. In your administrator window, open `/admin`. Inspect the submitted details and photos. Approve it, or return it with a correction note.
5. Approved listings appear under **Explore shops**. Search by shop name, category, product or service keyword.
6. Open the listing and test its call/WhatsApp links using a number you control. WhatsApp opens a prefilled message; it does **not** send automatically. A click does not prove a message was sent or received.
7. Edit an approved listing as its owner. The old approved version stays public while edits await review. Pending submissions are locked until reviewed.
8. Unpublish and republish an approved shop from the administrator panel.

## 4. Included

- Responsive public home page, keyword search, category filters and shop detail pages.
- Shopkeeper registration, password login, logout and seven-day sessions.
- Owner-scoped drafts, review submissions and correction feedback.
- Up to three PNG/JPEG/WebP photos per listing, 2 MB each; private before approval.
- Administrator review queue, publication controls and active/inactive categories.
- SQLite persistence, audit records for admin actions and consistent backup command.
- Password hashing with scrypt, hashed session tokens, HttpOnly cookies, same-origin mutation checks, validation and basic in-process rate limits.
- 18 backend workflow/security tests, run with `npm test`.

## 5. Technology and files

This first build deliberately uses **Node.js + SQLite + browser JavaScript** rather than the earlier proposed Next.js/Supabase stack. That keeps it immediately runnable without API credentials or external infrastructure. It is a new standalone implementation, not a recovered original project.

```text
server.mjs                 HTTP server, authentication and API
 db.mjs                    Schema initialization and password helpers
public/                    HTML, responsive styles and frontend application
scripts/                   Admin creation, password recovery, demo data, backups
 test/app.test.mjs          Automated backend tests
.env.example               Optional configuration examples
Dockerfile                 Optional persistent-server container
```

All photos are stored as database blobs. A database backup therefore includes photos, account data, audit records and sessions. The application serves only its explicitly listed static files; database files are not publicly exposed.

## 6. Configuration

Default: `HOST=127.0.0.1`, `PORT=3000`, `DB_PATH=./data/app.sqlite`.

Node does not automatically load `.env`. To use a file, copy `.env.example` to `.env`, edit it, then run:

```sh
node --env-file=.env server.mjs
```

Use the same `DB_PATH` when running management scripts. For example, if using `.env`:

```sh
node --env-file=.env scripts/create-admin.mjs your-email@example.com
node --env-file=.env scripts/backup.mjs
```

Do not commit `.env`, database files, backups or generated passwords.

## 7. Deployment boundary

This SQLite edition requires **one persistent Node process with writable persistent disk**. It is not suitable for Vercel serverless, ephemeral containers or multiple application replicas. A move to Next.js/Supabase or another managed Postgres stack is a separate migration, not included here.

For a persistent VM/container host:

- Use Node 24, a process supervisor, a persistent data directory, and a reverse proxy providing HTTPS.
- Set `NODE_ENV=production`, `APP_ORIGIN=https://your-domain`, `HOST=0.0.0.0`, and an absolute `DB_PATH` on persistent storage.
- Preserve the external Host header through the proxy. All mutations must come from the exact configured origin. Production cookies are Secure and require HTTPS.
- Add reverse-proxy request limits and per-client throttling. Application limits are deliberately conservative, in-memory and per-process; behind a proxy, clients share its socket address and can hit a shared cap. Do not trust arbitrary forwarded IP headers.
- Mount the data volume, keep a single replica, back up off-host, and restrict administrator access.
- Do not expose a development HTTP server to the internet.

Optional container build:

```sh
docker build -t indira-bhawan-os .
docker volume create ib-data
```

Run behind your HTTPS reverse proxy (replace the example origin):

```sh
docker run -d --name ib-os --restart unless-stopped \
  -p 127.0.0.1:3000:3000 -v ib-data:/app/data \
  -e NODE_ENV=production -e APP_ORIGIN=https://your-domain.example \
  indira-bhawan-os

docker exec -it ib-os node scripts/create-admin.mjs your-email@example.com
```

The image runs as a non-root user. Ensure any host bind-mounted database directory is writable by UID 1000. The Docker recipe is supplied as a deployment starting point; the tested run path is direct Node.js, not a deployed container.

## 8. Backup and recovery

```sh
npm run backup
```

This uses SQLite `VACUUM INTO` for a consistent snapshot, even with the server running. Keep encrypted copies off the host; backups contain sensitive account/session data.

To restore:

1. Stop the application and confirm no process is using its database.
2. Preserve the existing data directory elsewhere.
3. Restore the backup as your configured database path (default `data/app.sqlite`). Remove stale `app.sqlite-wal` / `app.sqlite-shm` files only while the application is stopped and after preserving the old database.
4. Start the server. Confirm logins and approved listings, including photos.
5. If restoring after a security incident, invalidate restored sessions before restarting using a trusted local database operation: `DELETE FROM sessions;`.

Test recovery on a separate instance before relying on this for production. The automated tests validate a snapshot's contents, but do not replace an operator's disaster-recovery drill.

## 9. Known pilot limitations and launch checklist

- No payments, inventory, delivery, reviews, billing or native app.
- No email verification, self-service email password reset, MFA, transactional emails or admin invitations.
- No analytics or enquiry click tracking. No claim of tracking WhatsApp messages or sales.
- Search is intentionally simple and loads published rows for filtering; add indexed search/pagination for a larger directory.
- Photo uploads use file signature checks, not antivirus scanning or full image re-encoding. Metadata is not stripped. Unattached/replaced images remain in storage; an operator retention/cleanup policy is still needed.
- No automated account-deletion UI, retention scheduler or deletion tooling. Handle pilot requests through the instance operator; define a proper deletion process before wider release.
- The default admin review is a manual content check, not certified business verification.
- Audit data is stored locally, not in tamper-proof external storage.
- SQLite database access implies full operator access; restrict disk and backup permissions.
- Policies are transparent pilot notices, not jurisdiction-specific legal advice. Add actual operator contact details, appropriate terms/privacy text and retention rules before public launch.
- Confirm market branding rights, onboard 5–10 consenting shops, remove samples, test real contact links, configure HTTPS and verify backups before launch.

## Troubleshooting

- **`node:sqlite` unavailable:** install Node.js 24 LTS or newer.
- **Port already in use:** stop the other process, or set `PORT` via `.env` and use `node --env-file=.env server.mjs`.
- **Cannot sign in:** ensure the server and admin script use the same `DB_PATH` and working directory.
- **Request origin error:** use the same browser origin consistently (`localhost` vs `127.0.0.1`); if setting `APP_ORIGIN`, it must exactly match scheme, hostname and port with no trailing slash.
- **No listing visible:** save and submit as shopkeeper, then approve as administrator. Drafts and pending changes are intentionally private.
- **HTTPS deployment login fails:** verify `APP_ORIGIN`, proxy setup and Secure cookie handling. Production mode intentionally does not work over plain HTTP.
