"""Regenerate DDL references without connecting to a database."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
from app.db import Base
from app import models  # Registers the tables; no network access.
from sqlalchemy.schema import CreateTable, CreateIndex
from sqlalchemy.dialects import postgresql, sqlite

for name, dialect in [
    ("postgresql", postgresql.dialect()),
    ("sqlite", sqlite.dialect()),
]:
    statements = ["-- DDL reference only. Use Alembic for actual migrations.\n"]
    for table in Base.metadata.sorted_tables:
        statements.append(str(CreateTable(table).compile(dialect=dialect)) + ";")
        for index in sorted(table.indexes, key=lambda item: item.name):
            statements.append(str(CreateIndex(index).compile(dialect=dialect)) + ";")
    (ROOT / "backend" / f"schema-{name}.sql").write_text("\n".join(statements) + "\n")
print(f"Generated DDL references for {len(Base.metadata.tables)} application tables.")
