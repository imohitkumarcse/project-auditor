-- DDL reference only. Use Alembic for actual migrations.


CREATE TABLE login_throttles (
	"key" VARCHAR(64) NOT NULL, 
	failures INTEGER NOT NULL, 
	window_start DATETIME NOT NULL, 
	PRIMARY KEY ("key")
)

;

CREATE TABLE organisations (
	id VARCHAR(36) NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	PRIMARY KEY (id)
)

;

CREATE TABLE users (
	id VARCHAR(36) NOT NULL, 
	email VARCHAR(254) NOT NULL, 
	password_hash TEXT NOT NULL, 
	active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (email)
)

;

CREATE TABLE auth_sessions (
	token_hash VARCHAR(64) NOT NULL, 
	user_id VARCHAR(36) NOT NULL, 
	csrf_hash VARCHAR(64) NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (token_hash), 
	FOREIGN KEY(user_id) REFERENCES users (id)
)

;

CREATE TABLE workspaces (
	id VARCHAR(36) NOT NULL, 
	organisation_id VARCHAR(36) NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(organisation_id) REFERENCES organisations (id)
)

;

CREATE TABLE assets (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	external_id VARCHAR(120) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	owner VARCHAR(200) NOT NULL, 
	criticality INTEGER NOT NULL, 
	internet_exposed BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (workspace_id, external_id), 
	UNIQUE (workspace_id, id), 
	CHECK (criticality BETWEEN 1 AND 5), 
	FOREIGN KEY(workspace_id) REFERENCES workspaces (id)
)

;
CREATE INDEX ix_assets_workspace_id ON assets (workspace_id);

CREATE TABLE audit_logs (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	actor_id VARCHAR(36), 
	action VARCHAR(100) NOT NULL, 
	target_id VARCHAR(100) NOT NULL, 
	details JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(workspace_id) REFERENCES workspaces (id)
)

;
CREATE INDEX ix_audit_logs_workspace_id ON audit_logs (workspace_id);

CREATE TABLE jobs (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	actor_id VARCHAR(36) NOT NULL, 
	kind VARCHAR(20) NOT NULL, 
	status VARCHAR(20) NOT NULL, 
	payload JSON NOT NULL, 
	result JSON NOT NULL, 
	attempts INTEGER NOT NULL, 
	lease_until DATETIME, 
	claim_token VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(workspace_id) REFERENCES workspaces (id), 
	FOREIGN KEY(actor_id) REFERENCES users (id)
)

;
CREATE INDEX ix_jobs_status ON jobs (status);
CREATE INDEX ix_jobs_workspace_id ON jobs (workspace_id);

CREATE TABLE memberships (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	user_id VARCHAR(36) NOT NULL, 
	role VARCHAR(20) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (workspace_id, user_id), 
	CHECK (role IN ('admin','manager','analyst','viewer')), 
	FOREIGN KEY(workspace_id) REFERENCES workspaces (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
)

;
CREATE INDEX ix_memberships_workspace_id ON memberships (workspace_id);

CREATE TABLE risk_snapshots (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	day VARCHAR(10) NOT NULL, 
	open_findings INTEGER NOT NULL, 
	high_priority INTEGER NOT NULL, 
	average_score FLOAT NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (workspace_id, day), 
	FOREIGN KEY(workspace_id) REFERENCES workspaces (id)
)

;
CREATE INDEX ix_risk_snapshots_workspace_id ON risk_snapshots (workspace_id);

CREATE TABLE findings (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	asset_id VARCHAR(36) NOT NULL, 
	fingerprint VARCHAR(64) NOT NULL, 
	source VARCHAR(120) NOT NULL, 
	source_id VARCHAR(200) NOT NULL, 
	source_severity VARCHAR(80) NOT NULL, 
	normalized_severity VARCHAR(20) NOT NULL, 
	vulnerability_id VARCHAR(100), 
	title VARCHAR(300) NOT NULL, 
	description TEXT NOT NULL, 
	exploitation_reported BOOLEAN NOT NULL, 
	exploitation_evidence TEXT NOT NULL, 
	score INTEGER NOT NULL, 
	factors JSON NOT NULL, 
	override_score INTEGER, 
	override_reason TEXT, 
	status VARCHAR(20) NOT NULL, 
	first_seen DATETIME NOT NULL, 
	last_seen DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (workspace_id, fingerprint), 
	UNIQUE (workspace_id, id), 
	FOREIGN KEY(workspace_id, asset_id) REFERENCES assets (workspace_id, id), 
	CHECK (score BETWEEN 0 AND 100), 
	CHECK (override_score IS NULL OR override_score BETWEEN 0 AND 100), 
	CHECK (status IN ('open','resolved')), 
	FOREIGN KEY(workspace_id) REFERENCES workspaces (id), 
	FOREIGN KEY(asset_id) REFERENCES assets (id)
)

;
CREATE INDEX ix_findings_workspace_id ON findings (workspace_id);

CREATE TABLE risk_register (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	title VARCHAR(300) NOT NULL, 
	owner_user_id VARCHAR(36), 
	finding_id VARCHAR(36), 
	treatment VARCHAR(20) NOT NULL, 
	rationale TEXT NOT NULL, 
	review_date VARCHAR(10) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(workspace_id, finding_id) REFERENCES findings (workspace_id, id), 
	FOREIGN KEY(workspace_id, owner_user_id) REFERENCES memberships (workspace_id, user_id), 
	CHECK (treatment IN ('mitigate','accept','avoid','transfer')), 
	FOREIGN KEY(workspace_id) REFERENCES workspaces (id), 
	FOREIGN KEY(owner_user_id) REFERENCES users (id), 
	FOREIGN KEY(finding_id) REFERENCES findings (id)
)

;
CREATE INDEX ix_risk_register_workspace_id ON risk_register (workspace_id);

CREATE TABLE score_reviews (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	finding_id VARCHAR(36) NOT NULL, 
	actor_id VARCHAR(36) NOT NULL, 
	score INTEGER, 
	reason TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(workspace_id, finding_id) REFERENCES findings (workspace_id, id), 
	FOREIGN KEY(workspace_id) REFERENCES workspaces (id), 
	FOREIGN KEY(finding_id) REFERENCES findings (id), 
	FOREIGN KEY(actor_id) REFERENCES users (id)
)

;
CREATE INDEX ix_score_reviews_workspace_id ON score_reviews (workspace_id);

CREATE TABLE tasks (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	finding_id VARCHAR(36) NOT NULL, 
	owner_user_id VARCHAR(36), 
	deadline VARCHAR(10) NOT NULL, 
	status VARCHAR(20) NOT NULL, 
	evidence TEXT NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(workspace_id, finding_id) REFERENCES findings (workspace_id, id), 
	FOREIGN KEY(workspace_id, owner_user_id) REFERENCES memberships (workspace_id, user_id), 
	CHECK (status IN ('todo','in_progress','blocked','done')), 
	FOREIGN KEY(workspace_id) REFERENCES workspaces (id), 
	UNIQUE (finding_id), 
	FOREIGN KEY(finding_id) REFERENCES findings (id), 
	FOREIGN KEY(owner_user_id) REFERENCES users (id)
)

;
CREATE INDEX ix_tasks_workspace_id ON tasks (workspace_id);
