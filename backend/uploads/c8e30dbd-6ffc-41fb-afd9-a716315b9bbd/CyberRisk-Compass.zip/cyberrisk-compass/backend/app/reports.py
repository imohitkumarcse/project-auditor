import csv, io, os
from pathlib import Path
from xml.sax.saxutils import escape
from sqlalchemy import select
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from .config import settings
from .models import Finding, Asset, Snapshot, RiskEntry
from .risk import effective, priority


def safe_cell(value):
    text = str(value if value is not None else "")
    if text.lstrip().startswith(("=", "+", "-", "@")) or text.startswith(("\t", "\r")):
        return "'" + text
    return text


def export_report(db, job):
    dataset = job.payload.get("dataset", "findings")
    if dataset != "findings":
        return export_register_or_history(db, job, dataset)
    findings = db.scalars(
        select(Finding)
        .where(Finding.workspace_id == job.workspace_id)
        .order_by(Finding.first_seen)
    ).all()
    assets = {
        x.id: x
        for x in db.scalars(select(Asset).where(Asset.workspace_id == job.workspace_id))
    }
    fmt = job.payload["format"]
    path = Path(settings().report_dir) / f"{job.id}.{fmt}"
    temporary = path.with_suffix(".tmp")
    if fmt == "csv":
        with temporary.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(
                [
                    "source",
                    "source_id",
                    "vulnerability_id",
                    "asset",
                    "title",
                    "source_severity",
                    "policy_score",
                    "effective_score",
                    "priority",
                    "status",
                    "override_reason",
                    "policy_version",
                    "score_factors",
                ]
            )
            import json

            for f in findings:
                writer.writerow(
                    [
                        safe_cell(x)
                        for x in [
                            f.source,
                            f.source_id,
                            f.vulnerability_id,
                            assets[f.asset_id].name,
                            f.title,
                            f.source_severity,
                            f.score,
                            effective(f),
                            priority(effective(f)),
                            f.status,
                            f.override_reason,
                            f.factors["policy"],
                            json.dumps(f.factors),
                        ]
                    ]
                )
    else:
        styles = getSampleStyleSheet()
        story = [
            Paragraph("CyberRisk Compass — Risk report", styles["Title"]),
            Paragraph(
                "Priority is not proof of security. Synthetic demonstration unless authorised findings were imported. Scores use policy compass-v1; overrides are separate.",
                styles["BodyText"],
            ),
            Spacer(1, 16),
        ]
        for f in findings:
            story.extend(
                [
                    Paragraph(escape(f.title), styles["Heading2"]),
                    Paragraph(
                        escape(
                            f"Source: {f.source} | Source ID: {f.source_id} | Asset: {assets[f.asset_id].name}"
                        ),
                        styles["BodyText"],
                    ),
                    Paragraph(
                        escape(
                            f"Source severity: {f.source_severity} | Policy score: {f.score} | Effective score: {effective(f)} | {priority(effective(f))} | Status: {f.status}"
                        ),
                        styles["BodyText"],
                    ),
                ]
            )
            for factor in f.factors["factors"]:
                story.append(
                    Paragraph(
                        escape(
                            f"{factor['factor']}: input={factor['input']}, points={factor['points']}/{factor['max']}"
                        ),
                        styles["BodyText"],
                    )
                )
            if f.override_reason:
                story.append(
                    Paragraph(
                        escape("Override reason: " + f.override_reason),
                        styles["BodyText"],
                    )
                )
            story.append(Spacer(1, 12))
        SimpleDocTemplate(str(temporary)).build(story)
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)
    return {
        "format": fmt,
        "dataset": "findings",
        "finding_count": len(findings),
        "download_ready": True,
    }


def export_register_or_history(db, job, dataset):
    if dataset == "history":
        columns = ["day", "open_findings", "high_priority", "average_score"]
        records = db.scalars(
            select(Snapshot)
            .where(Snapshot.workspace_id == job.workspace_id)
            .order_by(Snapshot.day)
        ).all()
        title = "Daily risk history — UTC"
        disclaimer = "Only recorded daily snapshots are included. Missing days are not backfilled. Today's values can still change."
    elif dataset == "risks":
        columns = [
            "id",
            "title",
            "treatment",
            "owner_user_id",
            "finding_id",
            "rationale",
            "review_date",
        ]
        records = db.scalars(
            select(RiskEntry)
            .where(RiskEntry.workspace_id == job.workspace_id)
            .order_by(RiskEntry.review_date, RiskEntry.id)
        ).all()
        title = "Risk register"
        disclaimer = "Risk acceptance is a recorded management decision, not proof of remediation or security."
    else:
        raise ValueError("Unsupported report dataset")
    fmt = job.payload["format"]
    path = Path(settings().report_dir) / f"{job.id}.{fmt}"
    temporary = path.with_suffix(".tmp")
    if fmt == "csv":
        with temporary.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(columns)
            for record in records:
                writer.writerow(
                    [safe_cell(getattr(record, column)) for column in columns]
                )
    else:
        styles = getSampleStyleSheet()
        story = [
            Paragraph(escape("CyberRisk Compass — " + title), styles["Title"]),
            Paragraph(
                escape(disclaimer + " A low score is not proof of security."),
                styles["BodyText"],
            ),
            Spacer(1, 16),
        ]
        for record in records:
            for column in columns:
                value = getattr(record, column)
                story.append(
                    Paragraph(
                        escape(
                            f"{column}: {value if value is not None else 'Unassigned'}"
                        ),
                        styles["BodyText"],
                    )
                )
            story.append(Spacer(1, 12))
        if not records:
            story.append(
                Paragraph("No recorded data for this workspace.", styles["BodyText"])
            )
        SimpleDocTemplate(str(temporary)).build(story)
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)
    return {
        "format": fmt,
        "dataset": dataset,
        "record_count": len(records),
        "download_ready": True,
    }
