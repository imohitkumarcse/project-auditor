import argparse, getpass, os, json
from pathlib import Path
from sqlalchemy import select
from .db import SessionLocal
from .models import User, Organisation, Workspace, Membership, Asset, Job
from .auth import hash_password
from .services import audit
from .importer import parse
from .worker import run_one


def main():
    parser = argparse.ArgumentParser(
        description="Offline provisioning; never scans systems"
    )
    parser.add_argument("command", choices=["seed", "create-admin"])
    parser.add_argument("--email", default="admin@example.test")
    parser.add_argument("--organisation", default="Synthetic Example Ltd")
    parser.add_argument("--workspace", default="Synthetic Security")
    args = parser.parse_args()
    password = os.environ.get("BOOTSTRAP_PASSWORD") or getpass.getpass(
        "Initial password (12+ characters): "
    )
    if not 12 <= len(password) <= 256:
        raise SystemExit("Password must contain 12 to 256 characters")
    with SessionLocal() as db:
        if db.scalar(select(User).where(User.email == args.email.lower())):
            raise SystemExit(
                "Account already exists. Provisioning is intentionally not a password reset."
            )
        user = User(email=args.email.lower(), password_hash=hash_password(password))
        db.add(user)
        db.flush()
        org = Organisation(name=args.organisation)
        db.add(org)
        db.flush()
        ws = Workspace(organisation_id=org.id, name=args.workspace)
        db.add(ws)
        db.flush()
        db.add(Membership(workspace_id=ws.id, user_id=user.id, role="admin"))
        audit(db, ws.id, user.id, "bootstrap.completed", user.id)
        if args.command == "seed":
            for a in [
                dict(
                    external_id="demo-web",
                    name="Synthetic Customer Portal",
                    owner="Example Web Team",
                    criticality=5,
                    internet_exposed=True,
                ),
                dict(
                    external_id="demo-db",
                    name="Synthetic Finance Database",
                    owner="Example Data Team",
                    criticality=5,
                    internet_exposed=False,
                ),
                dict(
                    external_id="demo-dev",
                    name="Synthetic Development Workstation",
                    owner="Example Engineering",
                    criticality=2,
                    internet_exposed=False,
                ),
            ]:
                db.add(Asset(workspace_id=ws.id, **a))
            db.flush()
            fixture = Path(__file__).resolve().parents[2] / "fixtures/findings.json"
            # In Docker fixtures are mounted/copied alongside backend.
            if not fixture.exists():
                fixture = Path("/fixtures/findings.json")
            rows = parse(fixture.read_bytes(), "findings.json")
            db.add(
                Job(
                    workspace_id=ws.id,
                    actor_id=user.id,
                    kind="import",
                    payload={"rows": rows},
                )
            )
        db.commit()
        print("Workspace ID:", ws.id)
        print("Account:", user.email)
    if args.command == "seed":
        run_one()
        print(
            "Synthetic import submitted/processed. Run the worker for any pending jobs. No external systems contacted."
        )


if __name__ == "__main__":
    main()
