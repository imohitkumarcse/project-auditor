import csv, io, json
from pydantic import (
    BaseModel,
    Field,
    ConfigDict,
    ValidationError,
    model_validator,
    field_validator,
)
from .config import settings


class ImportRow(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    asset_external_id: str = Field(min_length=1, max_length=120)
    source: str = Field(min_length=1, max_length=120)
    source_id: str = Field(min_length=1, max_length=200)
    source_severity: str = Field(min_length=1, max_length=80)
    title: str = Field(min_length=1, max_length=300)
    description: str = Field(default="", max_length=10000)
    vulnerability_id: str | None = Field(default=None, max_length=100)
    exploitation_reported: bool = False
    exploitation_evidence: str = Field(default="", max_length=2000)

    @field_validator("exploitation_reported", mode="before")
    @classmethod
    def boolean(cls, value):
        if type(value) is bool:
            return value
        if isinstance(value, str) and value.strip().lower() in ("true", "false"):
            return value.strip().lower() == "true"
        raise ValueError("Use true or false")

    @model_validator(mode="after")
    def evidence(self):
        if self.exploitation_reported and not self.exploitation_evidence:
            raise ValueError("Reported exploitation requires supplied evidence")
        if self.vulnerability_id == "":
            self.vulnerability_id = None
        return self


class ImportErrorSafe(ValueError):
    pass


def parse(content: bytes, filename: str):
    if len(content) > settings().max_upload_bytes:
        raise ImportErrorSafe("File exceeds upload limit")
    try:
        text = content.decode("utf-8-sig")
        if "\x00" in text:
            raise ImportErrorSafe("NUL bytes are not permitted")
        if filename.lower().endswith(".json"):

            def unique_pairs(pairs):
                d = {}
                for key, value in pairs:
                    if key in d:
                        raise ImportErrorSafe("Duplicate JSON keys")
                    d[key] = value
                return d

            rows = json.loads(text, object_pairs_hook=unique_pairs)
            if not isinstance(rows, list):
                raise ImportErrorSafe("JSON must be an array of records")
        elif filename.lower().endswith(".csv"):
            reader = csv.DictReader(io.StringIO(text), strict=True)
            if not reader.fieldnames or len(set(reader.fieldnames)) != len(
                reader.fieldnames
            ):
                raise ImportErrorSafe("Missing or duplicate CSV headers")
            rows = list(reader)
        else:
            raise ImportErrorSafe(
                "Only documented UTF-8 .csv and .json formats are accepted"
            )
        if not rows or len(rows) > settings().max_import_rows:
            raise ImportErrorSafe("Import must contain 1 to configured maximum rows")
        validated = []
        for index, row in enumerate(rows, 1):
            try:
                validated.append(ImportRow.model_validate(row).model_dump())
            except (ValidationError, TypeError):
                raise ImportErrorSafe(
                    f"Invalid row {index}: check required fields, lengths, booleans and exploitation evidence"
                )
        return validated
    except ImportErrorSafe:
        raise
    except (UnicodeError, ValueError, csv.Error, RecursionError, OverflowError):
        raise ImportErrorSafe("Malformed UTF-8, CSV or JSON input")
