from datetime import date, timedelta
from sqlalchemy import select
from .models import Finding, Asset, Audit, Snapshot, Task, now
from .risk import calculate, normalize_severity, fingerprint, effective


def audit(db, workspace_id, actor_id, action, target_id, details=None):
    # Only curated IDs/counts/roles; never passwords, session tokens or report text.
    db.add(
        Audit(
            workspace_id=workspace_id,
            actor_id=actor_id,
            action=action,
            target_id=target_id,
            details=details or {},
        )
    )


def rescore(finding, asset):
    finding.normalized_severity = normalize_severity(finding.source_severity)
    finding.score, finding.factors = calculate(
        finding.normalized_severity,
        asset.criticality,
        asset.internet_exposed,
        finding.exploitation_reported,
    )


def snapshot(db, workspace_id):
    db.flush()
    findings = db.scalars(
        select(Finding).where(
            Finding.workspace_id == workspace_id, Finding.status == "open"
        )
    ).all()
    day = now().date().isoformat()
    record = db.scalar(
        select(Snapshot).where(
            Snapshot.workspace_id == workspace_id, Snapshot.day == day
        )
    )
    if record is None:
        record = Snapshot(workspace_id=workspace_id, day=day)
        db.add(record)
    record.open_findings = len(findings)
    record.high_priority = sum(effective(x) >= 60 for x in findings)
    record.average_score = (
        round(sum(effective(x) for x in findings) / len(findings), 2) if findings else 0
    )


def import_rows(db, job):
    created = updated = 0
    seen = set()
    for row in job.payload["rows"]:
        asset = db.scalar(
            select(Asset).where(
                Asset.workspace_id == job.workspace_id,
                Asset.external_id == row["asset_external_id"],
            )
        )
        if asset is None:
            raise ValueError("An asset no longer exists; import was not applied")
        fp = fingerprint(row["source"], row["source_id"], asset.id)
        if fp in seen:
            continue
        seen.add(fp)
        finding = db.scalar(
            select(Finding).where(
                Finding.workspace_id == job.workspace_id, Finding.fingerprint == fp
            )
        )
        if finding is None:
            finding = Finding(
                workspace_id=job.workspace_id, asset_id=asset.id, fingerprint=fp
            )
            db.add(finding)
            created += 1
        else:
            updated += 1
        for key in (
            "source",
            "source_id",
            "source_severity",
            "vulnerability_id",
            "title",
            "description",
            "exploitation_reported",
            "exploitation_evidence",
        ):
            setattr(finding, key, row[key])
        finding.last_seen = now()
        # Reappearance reopens a resolved finding, but preserves historical evidence.
        if finding.status == "resolved":
            finding.status = "open"
            task = db.scalar(
                select(Task).where(
                    Task.workspace_id == job.workspace_id, Task.finding_id == finding.id
                )
            )
            if task:
                task.status = "in_progress"
                task.updated_at = now()
        rescore(finding, asset)
        db.flush()
    audit(
        db,
        job.workspace_id,
        job.actor_id,
        "import.completed",
        job.id,
        {"created": created, "updated": updated},
    )
    snapshot(db, job.workspace_id)
    return {
        "created": created,
        "updated": updated,
        "duplicates_in_file": len(job.payload["rows"]) - len(seen),
    }
