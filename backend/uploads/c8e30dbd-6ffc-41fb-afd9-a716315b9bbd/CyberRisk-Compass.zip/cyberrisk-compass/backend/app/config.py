from functools import lru_cache
from pathlib import Path
from typing import Literal
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import model_validator, Field


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    environment: Literal["development", "production"] = "development"
    database_url: str = "sqlite:///./compass.db"
    session_secret: str = "local-only-change-this-secret-at-least-32-characters"
    allowed_origins: str = "http://localhost:3000"
    allowed_hosts: str = "localhost,127.0.0.1,testserver,api"
    secure_cookies: bool = False
    report_dir: str = "./private-reports"
    session_hours: int = Field(default=8, ge=1, le=72)
    max_upload_bytes: int = Field(default=2_000_000, ge=1024, le=20_000_000)
    max_import_rows: int = Field(default=5000, ge=1, le=10000)
    job_retention_days: int = Field(default=7, ge=1, le=90)

    @model_validator(mode="after")
    def check(self):
        if len(self.session_secret) < 32:
            raise ValueError("SESSION_SECRET must contain at least 32 characters")
        if self.environment == "production":
            if (
                self.session_secret.startswith(
                    ("local-only", "replace-this", "choose-")
                )
                or not self.secure_cookies
            ):
                raise ValueError("Production requires a new secret and secure cookies")
            if not self.database_url.startswith("postgresql"):
                raise ValueError("Production requires PostgreSQL")
            if any(
                not x.strip().startswith("https://")
                for x in self.allowed_origins.split(",")
            ):
                raise ValueError("Production origins must be HTTPS")
            if "*" in self.allowed_hosts or "testserver" in self.allowed_hosts:
                raise ValueError(
                    "Production requires explicit approved hosts without testserver"
                )
        Path(self.report_dir).mkdir(mode=0o700, parents=True, exist_ok=True)
        return self


@lru_cache
def settings():
    return Settings()
