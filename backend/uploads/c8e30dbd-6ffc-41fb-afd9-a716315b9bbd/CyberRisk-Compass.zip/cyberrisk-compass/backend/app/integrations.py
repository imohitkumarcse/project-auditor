"""Contract for future approved report adapters. Not an enabled network client."""

from typing import Protocol
from .importer import ImportRow


class ApprovedReportAdapter(Protocol):
    name: str

    def normalize_authorised_report(self, content: bytes) -> list[ImportRow]: ...


# Future adapters must pass the same validation, tenant context, audit and queue
# pipeline. Never accept tenant IDs from an upstream report as authoritative.
# No connector credentials, network requests or scanning are implemented here.
