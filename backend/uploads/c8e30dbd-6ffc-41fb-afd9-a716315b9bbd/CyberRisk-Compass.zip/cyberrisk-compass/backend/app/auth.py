import hashlib, hmac, secrets
from datetime import timedelta
from fastapi import Depends, HTTPException, Request
from sqlalchemy import select
from .config import settings
from .db import get_db
from .models import User, AuthSession, Membership, now

ITERATIONS = 600000
DUMMY_SALT = "b65527dfe30fcaeef10d225d2c661c52"


def digest(value):
    return hmac.new(
        settings().session_secret.encode(), value.encode(), hashlib.sha256
    ).hexdigest()


def hash_password(password):
    salt = secrets.token_hex(16)
    out = hashlib.pbkdf2_hmac(
        "sha256", password.encode(), salt.encode(), ITERATIONS
    ).hex()
    return f"pbkdf2_sha256${ITERATIONS}${salt}${out}"


def verify_password(password, stored):
    _, iterations, salt, expected = stored.split("$")
    out = hashlib.pbkdf2_hmac(
        "sha256", password.encode(), salt.encode(), int(iterations)
    ).hex()
    return hmac.compare_digest(out, expected)


def dummy_verify(password):
    hashlib.pbkdf2_hmac("sha256", password.encode(), DUMMY_SALT.encode(), ITERATIONS)


def current_user(request: Request, db=Depends(get_db)):
    token = request.cookies.get("compass_session")
    auth = db.get(AuthSession, digest(token)) if token else None
    if not auth or auth.expires_at <= now():
        raise HTTPException(401, "Sign in required")
    user = db.get(User, auth.user_id)
    if not user or not user.active:
        raise HTTPException(401, "Sign in required")
    if request.method not in ("GET", "HEAD", "OPTIONS"):
        csrf = request.headers.get("X-CSRF-Token", "")
        if not csrf or not hmac.compare_digest(digest(csrf), auth.csrf_hash):
            raise HTTPException(403, "CSRF token required")
    return user


def access(roles=("admin", "manager", "analyst", "viewer")):
    def dependency(workspace_id: str, user=Depends(current_user), db=Depends(get_db)):
        membership = db.scalar(
            select(Membership).where(
                Membership.workspace_id == workspace_id, Membership.user_id == user.id
            )
        )
        if not membership:
            raise HTTPException(404, "Workspace not found")
        if membership.role not in roles:
            raise HTTPException(403, "Role does not permit this action")
        return user

    return dependency


READ = access()
WRITE = access(("admin", "manager", "analyst"))
MANAGE = access(("admin", "manager"))
ADMIN = access(("admin",))
