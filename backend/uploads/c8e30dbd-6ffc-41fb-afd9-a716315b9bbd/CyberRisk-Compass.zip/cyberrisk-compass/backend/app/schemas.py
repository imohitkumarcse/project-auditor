from typing import Literal
from datetime import date
from pydantic import BaseModel, Field, ConfigDict, field_validator


class Input(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class Login(Input):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)
    email: str = Field(min_length=3, max_length=254)
    password: str = Field(
        min_length=1,
        max_length=256,
        repr=False,
        json_schema_extra={"format": "password"},
    )

    @field_validator("email")
    @classmethod
    def trim_email(cls, value):
        return value.strip()


class PasswordChange(Input):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)
    current_password: str = Field(
        min_length=1,
        max_length=256,
        repr=False,
        json_schema_extra={"format": "password"},
    )
    new_password: str = Field(
        min_length=12,
        max_length=256,
        repr=False,
        json_schema_extra={"format": "password"},
    )


class AssetInput(Input):
    external_id: str = Field(min_length=1, max_length=120)
    name: str = Field(min_length=1, max_length=200)
    owner: str = Field(default="Unassigned", max_length=200)
    criticality: int = Field(default=3, ge=1, le=5, strict=True)
    internet_exposed: bool = False


class AssetUpdate(Input):
    name: str = Field(min_length=1, max_length=200)
    owner: str = Field(max_length=200)
    criticality: int = Field(ge=1, le=5, strict=True)
    internet_exposed: bool


class OverrideInput(Input):
    score: int | None = Field(default=None, ge=0, le=100, strict=True)
    reason: str = Field(min_length=10, max_length=2000)


class TaskInput(Input):
    finding_id: str = Field(max_length=36)
    owner_user_id: str | None = None
    deadline: date


class TaskUpdate(Input):
    owner_user_id: str | None = None
    deadline: date
    status: Literal["todo", "in_progress", "blocked", "done"]
    evidence: str = Field(default="", max_length=10000)


class RiskInput(Input):
    title: str = Field(min_length=1, max_length=300)
    owner_user_id: str | None = None
    finding_id: str | None = None
    treatment: Literal["mitigate", "accept", "avoid", "transfer"]
    rationale: str = Field(min_length=10, max_length=5000)
    review_date: date


class MemberInput(Input):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)
    email: str = Field(min_length=3, max_length=254)
    password: str | None = Field(
        default=None,
        min_length=12,
        max_length=256,
        repr=False,
        json_schema_extra={"format": "password"},
    )
    role: Literal["admin", "manager", "analyst", "viewer"]

    @field_validator("email")
    @classmethod
    def trim_email(cls, value):
        return value.strip()


class RoleInput(Input):
    role: Literal["admin", "manager", "analyst", "viewer"]


class OrganisationInput(Input):
    name: str = Field(min_length=1, max_length=120)
    workspace_name: str = Field(min_length=1, max_length=120)


class WorkspaceInput(Input):
    name: str = Field(min_length=1, max_length=120)


class ReportInput(Input):
    format: Literal["csv", "pdf"]
    dataset: Literal["findings", "history", "risks"] = "findings"
