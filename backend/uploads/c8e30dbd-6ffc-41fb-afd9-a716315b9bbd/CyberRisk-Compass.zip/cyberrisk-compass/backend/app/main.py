import secrets
from datetime import timedelta, date
from pathlib import Path
from fastapi import (
    FastAPI,
    Depends,
    HTTPException,
    Request,
    Response,
    UploadFile,
    File,
    Query,
)
from fastapi.responses import JSONResponse, FileResponse
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select, func
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from starlette.middleware.trustedhost import TrustedHostMiddleware
from .config import settings
from .db import get_db
from .models import (
    User,
    Organisation,
    Workspace,
    Membership,
    AuthSession,
    LoginThrottle,
    Asset,
    Finding,
    Task,
    RiskEntry,
    Audit,
    Job,
    Snapshot,
    ScoreReview,
    now,
)
from .auth import (
    current_user,
    READ,
    WRITE,
    MANAGE,
    ADMIN,
    digest,
    hash_password,
    verify_password,
    dummy_verify,
)
from .schemas import (
    Login,
    PasswordChange,
    AssetInput,
    AssetUpdate,
    OverrideInput,
    TaskInput,
    TaskUpdate,
    RiskInput,
    MemberInput,
    RoleInput,
    OrganisationInput,
    WorkspaceInput,
    ReportInput,
)
from .importer import parse, ImportErrorSafe
from .risk import effective, priority, fingerprint
from .services import audit, rescore, snapshot

app = FastAPI(
    title="CyberRisk Compass",
    version="1.0.0",
    description="Defensive authorised-report management. No external scanning or enrichment.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in settings().allowed_origins.split(",")],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH"],
    allow_headers=["Content-Type", "X-CSRF-Token"],
)
app.add_middleware(
    TrustedHostMiddleware, allowed_hosts=settings().allowed_hosts.split(",")
)


class RequestLimit:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope["method"] in ("GET", "HEAD", "OPTIONS"):
            return await self.app(scope, receive, send)
        limit = (
            settings().max_upload_bytes + 65536
            if scope["path"].endswith("/imports")
            else 32768
        )
        body = bytearray()
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            body.extend(message.get("body", b""))
            if len(body) > limit:
                return await JSONResponse(
                    {"detail": "Request body too large"}, status_code=413
                )(scope, receive, send)
            if not message.get("more_body"):
                break
        sent = False

        async def replay():
            nonlocal sent
            if not sent:
                sent = True
                return {"type": "http.request", "body": bytes(body), "more_body": False}
            return await receive()

        await self.app(scope, replay, send)


app.add_middleware(RequestLimit)


@app.middleware("http")
async def security_headers(request, call_next):
    origin = request.headers.get("origin")
    if (
        request.method not in ("GET", "HEAD", "OPTIONS")
        and origin
        and origin not in [x.strip() for x in settings().allowed_origins.split(",")]
    ):
        return JSONResponse({"detail": "Origin not permitted"}, status_code=403)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Cache-Control"] = "no-store"
    if settings().secure_cookies:
        response.headers["Strict-Transport-Security"] = "max-age=31536000"
    return response


@app.exception_handler(IntegrityError)
async def conflicts(request, exc):
    return JSONResponse(
        {"detail": "Conflicting record; refresh and retry"}, status_code=409
    )


@app.exception_handler(SQLAlchemyError)
async def database_unavailable(request, exc):
    # SQLAlchemy exceptions can carry SQL parameters containing sensitive data.
    # Do not propagate them into framework tracebacks or client responses.
    return JSONResponse(
        {"detail": "Database operation unavailable; retry later"}, status_code=503
    )


@app.exception_handler(RequestValidationError)
async def validation_error(request, exc):
    # Default validation errors may echo password or report-field values.
    return JSONResponse(
        {
            "detail": "Invalid input; check required fields, lengths and allowed values",
            "fields": [
                {"location": list(e["loc"]), "type": e["type"]} for e in exc.errors()
            ],
        },
        status_code=422,
    )


def scoped(db, model, workspace_id, id):
    value = db.scalar(
        select(model).where(model.workspace_id == workspace_id, model.id == id)
    )
    if value is None:
        raise HTTPException(404, "Record not found")
    return value


def check_owner(db, workspace_id, user_id):
    if user_id and not db.scalar(
        select(Membership).where(
            Membership.workspace_id == workspace_id, Membership.user_id == user_id
        )
    ):
        raise HTTPException(422, "Owner must belong to this workspace")


def data(record):
    return {c.name: getattr(record, c.name) for c in record.__table__.columns}


def finding_data(f):
    return {
        **data(f),
        "effective_score": effective(f),
        "priority": priority(effective(f)),
    }


def paged(db, model, workspace_id, limit, offset):
    return db.scalars(
        select(model)
        .where(model.workspace_id == workspace_id)
        .order_by(model.id)
        .limit(limit)
        .offset(offset)
    ).all()


@app.get("/health")
def health():
    return {"status": "ok", "external_scanning": False}


@app.post("/auth/login")
def login(payload: Login, request: Request, response: Response, db=Depends(get_db)):
    email = payload.email.lower()
    key = digest(email + "|" + (request.client.host if request.client else "unknown"))
    throttle = db.get(LoginThrottle, key)
    if (
        throttle
        and now() - throttle.window_start < timedelta(minutes=15)
        and throttle.failures >= 5
    ):
        raise HTTPException(429, "Too many attempts; retry after 15 minutes")
    user = db.scalar(select(User).where(User.email == email))
    valid = (
        verify_password(payload.password, user.password_hash)
        if user
        else (dummy_verify(payload.password) or False)
    )
    if not valid or not user or not user.active:
        if throttle is None:
            throttle = LoginThrottle(key=key, failures=0, window_start=now())
            db.add(throttle)
        if now() - throttle.window_start >= timedelta(minutes=15):
            throttle.window_start = now()
            throttle.failures = 0
        throttle.failures += 1
        db.commit()
        raise HTTPException(401, "Invalid credentials")
    if throttle:
        db.delete(throttle)
    token = secrets.token_urlsafe(32)
    csrf = digest("csrf:" + token)
    db.add(
        AuthSession(
            token_hash=digest(token),
            csrf_hash=digest(csrf),
            user_id=user.id,
            expires_at=now() + timedelta(hours=settings().session_hours),
        )
    )
    # Limit active sessions and remove expired ones for this account.
    sessions = db.scalars(
        select(AuthSession)
        .where(AuthSession.user_id == user.id)
        .order_by(AuthSession.expires_at.desc())
    ).all()
    for session in sessions[4:]:
        db.delete(session)
    db.commit()
    response.set_cookie(
        "compass_session",
        token,
        httponly=True,
        secure=settings().secure_cookies,
        samesite="lax",
        max_age=settings().session_hours * 3600,
        path="/",
    )
    return {"user": {"id": user.id, "email": user.email}, "csrf_token": csrf}


@app.get("/auth/me")
def me(request: Request, user=Depends(current_user), db=Depends(get_db)):
    # Stable session-bound token avoids invalidating other browser tabs.
    csrf = digest("csrf:" + request.cookies["compass_session"])
    return {"user": {"id": user.id, "email": user.email}, "csrf_token": csrf}


@app.post("/auth/logout")
def logout(
    request: Request, response: Response, user=Depends(current_user), db=Depends(get_db)
):
    session = db.get(AuthSession, digest(request.cookies["compass_session"]))
    db.delete(session)
    db.commit()
    response.delete_cookie("compass_session", path="/")
    return {"ok": True}


@app.post("/auth/password")
def change_password(
    payload: PasswordChange,
    response: Response,
    user=Depends(current_user),
    db=Depends(get_db),
):
    if not verify_password(payload.current_password, user.password_hash):
        raise HTTPException(400, "Current password is incorrect")
    if payload.current_password == payload.new_password:
        raise HTTPException(422, "Choose a different password")
    user.password_hash = hash_password(payload.new_password)
    for session in db.scalars(
        select(AuthSession).where(AuthSession.user_id == user.id)
    ):
        db.delete(session)
    for membership in db.scalars(
        select(Membership).where(Membership.user_id == user.id)
    ):
        audit(db, membership.workspace_id, user.id, "account.password_changed", user.id)
    db.commit()
    response.delete_cookie("compass_session", path="/")
    return {"ok": True, "sign_in_required": True}


@app.get("/workspaces")
def workspaces(user=Depends(current_user), db=Depends(get_db)):
    rows = db.execute(
        select(Workspace, Membership.role, Organisation.name)
        .join(Membership, Membership.workspace_id == Workspace.id)
        .join(Organisation, Organisation.id == Workspace.organisation_id)
        .where(Membership.user_id == user.id)
    ).all()
    return [
        {**data(w), "role": role, "organisation_name": name} for w, role, name in rows
    ]


@app.post("/organisations", status_code=201)
def create_organisation(
    payload: OrganisationInput, user=Depends(current_user), db=Depends(get_db)
):
    # Authenticated creation does not grant access to any existing organisation.
    org = Organisation(name=payload.name)
    db.add(org)
    db.flush()
    workspace = Workspace(organisation_id=org.id, name=payload.workspace_name)
    db.add(workspace)
    db.flush()
    db.add(Membership(workspace_id=workspace.id, user_id=user.id, role="admin"))
    audit(db, workspace.id, user.id, "organisation.created", org.id)
    db.commit()
    return data(workspace)


@app.post("/workspaces/{workspace_id}/siblings", status_code=201)
def create_workspace(
    workspace_id: str, payload: WorkspaceInput, user=Depends(ADMIN), db=Depends(get_db)
):
    parent = db.get(Workspace, workspace_id)
    workspace = Workspace(organisation_id=parent.organisation_id, name=payload.name)
    db.add(workspace)
    db.flush()
    db.add(Membership(workspace_id=workspace.id, user_id=user.id, role="admin"))
    audit(db, workspace.id, user.id, "workspace.created", workspace.id)
    db.commit()
    return data(workspace)


@app.get("/workspaces/{workspace_id}/members")
def members(workspace_id: str, user=Depends(READ), db=Depends(get_db)):
    rows = db.execute(
        select(Membership, User.email)
        .join(User, User.id == Membership.user_id)
        .where(Membership.workspace_id == workspace_id)
    ).all()
    return [{**data(m), "email": email} for m, email in rows]


@app.post("/workspaces/{workspace_id}/members", status_code=201)
def add_member(
    workspace_id: str, payload: MemberInput, user=Depends(ADMIN), db=Depends(get_db)
):
    member = db.scalar(select(User).where(User.email == payload.email.lower()))
    if member is None:
        if not payload.password:
            raise HTTPException(422, "Initial password required for a new user")
        member = User(
            email=payload.email.lower(), password_hash=hash_password(payload.password)
        )
        db.add(member)
        db.flush()
    elif payload.password:
        raise HTTPException(422, "Cannot reset an existing account password here")
    membership = Membership(
        workspace_id=workspace_id, user_id=member.id, role=payload.role
    )
    db.add(membership)
    db.flush()
    audit(db, workspace_id, user.id, "member.added", member.id, {"role": payload.role})
    db.commit()
    return data(membership)


@app.patch("/workspaces/{workspace_id}/members/{membership_id}")
def change_role(
    workspace_id: str,
    membership_id: str,
    payload: RoleInput,
    user=Depends(ADMIN),
    db=Depends(get_db),
):
    # Lock workspace to serialize last-administrator checks on PostgreSQL.
    db.scalar(select(Workspace).where(Workspace.id == workspace_id).with_for_update())
    member = scoped(db, Membership, workspace_id, membership_id)
    if member.role == "admin" and payload.role != "admin":
        admins = db.scalar(
            select(func.count())
            .select_from(Membership)
            .where(Membership.workspace_id == workspace_id, Membership.role == "admin")
        )
        if admins <= 1:
            raise HTTPException(409, "Cannot remove the last administrator")
    member.role = payload.role
    audit(
        db,
        workspace_id,
        user.id,
        "member.role_changed",
        member.user_id,
        {"role": payload.role},
    )
    db.commit()
    return data(member)


@app.get("/workspaces/{workspace_id}/assets")
def assets(
    workspace_id: str,
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    user=Depends(READ),
    db=Depends(get_db),
):
    return [data(x) for x in paged(db, Asset, workspace_id, limit, offset)]


@app.post("/workspaces/{workspace_id}/assets", status_code=201)
def create_asset(
    workspace_id: str, payload: AssetInput, user=Depends(WRITE), db=Depends(get_db)
):
    asset = Asset(workspace_id=workspace_id, **payload.model_dump())
    db.add(asset)
    db.flush()
    audit(db, workspace_id, user.id, "asset.created", asset.id)
    db.commit()
    return data(asset)


@app.patch("/workspaces/{workspace_id}/assets/{asset_id}")
def update_asset(
    workspace_id: str,
    asset_id: str,
    payload: AssetUpdate,
    user=Depends(WRITE),
    db=Depends(get_db),
):
    asset = scoped(db, Asset, workspace_id, asset_id)
    for key, value in payload.model_dump().items():
        setattr(asset, key, value)
    findings = db.scalars(
        select(Finding).where(
            Finding.workspace_id == workspace_id, Finding.asset_id == asset.id
        )
    ).all()
    for finding in findings:
        rescore(finding, asset)
    audit(
        db,
        workspace_id,
        user.id,
        "asset.updated",
        asset.id,
        {"rescored": len(findings)},
    )
    snapshot(db, workspace_id)
    db.commit()
    return data(asset)


@app.post("/workspaces/{workspace_id}/imports", status_code=202)
async def upload(
    workspace_id: str,
    file: UploadFile = File(...),
    user=Depends(WRITE),
    db=Depends(get_db),
):
    content = await file.read(settings().max_upload_bytes + 1)
    await file.close()
    try:
        rows = parse(content, file.filename or "")
    except ImportErrorSafe as exc:
        raise HTTPException(422, str(exc))
    assets = {
        a.external_id: a
        for a in db.scalars(select(Asset).where(Asset.workspace_id == workspace_id))
    }
    identities = {}
    for i, row in enumerate(rows, 1):
        if row["asset_external_id"] not in assets:
            raise HTTPException(
                422, f"Row {i}: asset does not exist in this workspace; create it first"
            )
        fp = fingerprint(
            row["source"], row["source_id"], assets[row["asset_external_id"]].id
        )
        if fp in identities and identities[fp] != row:
            raise HTTPException(422, f"Row {i}: conflicting duplicate identity")
        identities[fp] = row
    job = Job(
        workspace_id=workspace_id,
        actor_id=user.id,
        kind="import",
        payload={"rows": rows},
    )
    db.add(job)
    db.flush()
    audit(db, workspace_id, user.id, "import.queued", job.id, {"rows": len(rows)})
    db.commit()
    return {"id": job.id, "status": job.status}


@app.get("/workspaces/{workspace_id}/findings")
def findings(
    workspace_id: str,
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    user=Depends(READ),
    db=Depends(get_db),
):
    # Query orders policy/override score in database before paging.
    q = (
        select(Finding)
        .where(Finding.workspace_id == workspace_id)
        .order_by(
            func.coalesce(Finding.override_score, Finding.score).desc(), Finding.id
        )
        .limit(limit)
        .offset(offset)
    )
    return [finding_data(f) for f in db.scalars(q)]


@app.get("/workspaces/{workspace_id}/findings/{finding_id}")
def finding(workspace_id: str, finding_id: str, user=Depends(READ), db=Depends(get_db)):
    return finding_data(scoped(db, Finding, workspace_id, finding_id))


@app.patch("/workspaces/{workspace_id}/findings/{finding_id}/override")
def override(
    workspace_id: str,
    finding_id: str,
    payload: OverrideInput,
    user=Depends(MANAGE),
    db=Depends(get_db),
):
    finding = scoped(db, Finding, workspace_id, finding_id)
    finding.override_score = payload.score
    finding.override_reason = payload.reason
    db.add(
        ScoreReview(
            workspace_id=workspace_id,
            finding_id=finding.id,
            actor_id=user.id,
            score=payload.score,
            reason=payload.reason,
        )
    )
    audit(
        db,
        workspace_id,
        user.id,
        "finding.override_changed",
        finding.id,
        {"score": payload.score},
    )
    snapshot(db, workspace_id)
    db.commit()
    return finding_data(finding)


@app.get("/workspaces/{workspace_id}/tasks")
def tasks(
    workspace_id: str,
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    user=Depends(READ),
    db=Depends(get_db),
):
    return [data(x) for x in paged(db, Task, workspace_id, limit, offset)]


@app.post("/workspaces/{workspace_id}/tasks", status_code=201)
def create_task(
    workspace_id: str, payload: TaskInput, user=Depends(WRITE), db=Depends(get_db)
):
    scoped(db, Finding, workspace_id, payload.finding_id)
    check_owner(db, workspace_id, payload.owner_user_id)
    task = Task(
        workspace_id=workspace_id,
        finding_id=payload.finding_id,
        owner_user_id=payload.owner_user_id,
        deadline=payload.deadline.isoformat(),
    )
    db.add(task)
    db.flush()
    audit(db, workspace_id, user.id, "task.created", task.id)
    db.commit()
    return data(task)


@app.patch("/workspaces/{workspace_id}/tasks/{task_id}")
def update_task(
    workspace_id: str,
    task_id: str,
    payload: TaskUpdate,
    user=Depends(WRITE),
    db=Depends(get_db),
):
    task = scoped(db, Task, workspace_id, task_id)
    check_owner(db, workspace_id, payload.owner_user_id)
    if payload.status == "done" and len(payload.evidence.strip()) < 10:
        raise HTTPException(
            422, "Resolution requires at least 10 characters of evidence"
        )
    for key, value in payload.model_dump().items():
        setattr(task, key, value.isoformat() if key == "deadline" else value)
    task.updated_at = now()
    f = scoped(db, Finding, workspace_id, task.finding_id)
    f.status = "resolved" if task.status == "done" else "open"
    audit(db, workspace_id, user.id, "task.updated", task.id, {"status": task.status})
    snapshot(db, workspace_id)
    db.commit()
    return data(task)


@app.get("/workspaces/{workspace_id}/risks")
def risks(
    workspace_id: str,
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    user=Depends(READ),
    db=Depends(get_db),
):
    return [data(x) for x in paged(db, RiskEntry, workspace_id, limit, offset)]


def apply_risk(db, workspace_id, payload, risk):
    check_owner(db, workspace_id, payload.owner_user_id)
    if payload.finding_id:
        scoped(db, Finding, workspace_id, payload.finding_id)
    for key, value in payload.model_dump().items():
        setattr(risk, key, value.isoformat() if key == "review_date" else value)


@app.post("/workspaces/{workspace_id}/risks", status_code=201)
def create_risk(
    workspace_id: str, payload: RiskInput, user=Depends(MANAGE), db=Depends(get_db)
):
    risk = RiskEntry(workspace_id=workspace_id)
    apply_risk(db, workspace_id, payload, risk)
    db.add(risk)
    db.flush()
    audit(db, workspace_id, user.id, "risk.created", risk.id)
    db.commit()
    return data(risk)


@app.patch("/workspaces/{workspace_id}/risks/{risk_id}")
def update_risk(
    workspace_id: str,
    risk_id: str,
    payload: RiskInput,
    user=Depends(MANAGE),
    db=Depends(get_db),
):
    risk = scoped(db, RiskEntry, workspace_id, risk_id)
    apply_risk(db, workspace_id, payload, risk)
    audit(db, workspace_id, user.id, "risk.updated", risk.id)
    db.commit()
    return data(risk)


@app.get("/workspaces/{workspace_id}/dashboard")
def dashboard(workspace_id: str, user=Depends(READ), db=Depends(get_db)):
    findings = db.scalars(
        select(Finding).where(
            Finding.workspace_id == workspace_id, Finding.status == "open"
        )
    ).all()
    tasks = db.scalars(select(Task).where(Task.workspace_id == workspace_id)).all()
    return {
        "assets": db.scalar(
            select(func.count())
            .select_from(Asset)
            .where(Asset.workspace_id == workspace_id)
        ),
        "open_findings": len(findings),
        "high_priority": sum(effective(f) >= 60 for f in findings),
        "overdue_tasks": sum(
            t.status != "done" and t.deadline < now().date().isoformat() for t in tasks
        ),
        "average_score": round(sum(effective(f) for f in findings) / len(findings), 2)
        if findings
        else 0,
        "priority_counts": {
            p: sum(priority(effective(f)) == p for f in findings)
            for p in ["P1", "P2", "P3", "P4"]
        },
        "warning": "Low priority is not proof that a system is secure.",
    }


@app.get("/workspaces/{workspace_id}/history")
def history(workspace_id: str, user=Depends(READ), db=Depends(get_db)):
    rows = db.scalars(
        select(Snapshot)
        .where(Snapshot.workspace_id == workspace_id)
        .order_by(Snapshot.day.desc())
        .limit(366)
    ).all()
    return [data(x) for x in reversed(rows)]


@app.get("/workspaces/{workspace_id}/audit")
def audit_logs(
    workspace_id: str,
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    user=Depends(MANAGE),
    db=Depends(get_db),
):
    return [
        data(x)
        for x in db.scalars(
            select(Audit)
            .where(Audit.workspace_id == workspace_id)
            .order_by(Audit.created_at.desc(), Audit.id)
            .limit(limit)
            .offset(offset)
        )
    ]


@app.post("/workspaces/{workspace_id}/reports", status_code=202)
def report(
    workspace_id: str, payload: ReportInput, user=Depends(READ), db=Depends(get_db)
):
    job = Job(
        workspace_id=workspace_id,
        actor_id=user.id,
        kind="report",
        payload=payload.model_dump(),
    )
    db.add(job)
    db.flush()
    audit(
        db,
        workspace_id,
        user.id,
        "report.queued",
        job.id,
        {"format": payload.format, "dataset": payload.dataset},
    )
    db.commit()
    return {"id": job.id, "status": job.status}


@app.get("/workspaces/{workspace_id}/jobs")
def jobs(
    workspace_id: str,
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    user=Depends(READ),
    db=Depends(get_db),
):
    rows = db.scalars(
        select(Job)
        .where(Job.workspace_id == workspace_id)
        .order_by(Job.created_at.desc())
        .limit(limit)
        .offset(offset)
    )
    return [
        {
            "id": j.id,
            "kind": j.kind,
            "status": j.status,
            "result": j.result,
            "created_at": j.created_at,
            "attempts": j.attempts,
        }
        for j in rows
    ]


@app.get("/workspaces/{workspace_id}/jobs/{job_id}")
def job_status(workspace_id: str, job_id: str, user=Depends(READ), db=Depends(get_db)):
    j = scoped(db, Job, workspace_id, job_id)
    return {
        "id": j.id,
        "kind": j.kind,
        "status": j.status,
        "result": j.result,
        "attempts": j.attempts,
    }


@app.get("/workspaces/{workspace_id}/reports/{job_id}/download")
def download(workspace_id: str, job_id: str, user=Depends(READ), db=Depends(get_db)):
    job = scoped(db, Job, workspace_id, job_id)
    if job.kind != "report" or job.status != "succeeded":
        raise HTTPException(404, "Report not ready")
    fmt = job.result.get("format")
    if fmt not in ("csv", "pdf"):
        raise HTTPException(404, "Report unavailable")
    path = Path(settings().report_dir) / f"{job.id}.{fmt}"
    if not path.is_file():
        raise HTTPException(410, "Report expired")
    audit(db, workspace_id, user.id, "report.downloaded", job.id)
    db.commit()
    return FileResponse(
        path,
        filename=f"cyberrisk-report.{fmt}",
        media_type="text/csv" if fmt == "csv" else "application/pdf",
    )


@app.get("/workspaces/{workspace_id}/findings/{finding_id}/reviews")
def reviews(workspace_id: str, finding_id: str, user=Depends(READ), db=Depends(get_db)):
    scoped(db, Finding, workspace_id, finding_id)
    return [
        data(r)
        for r in db.scalars(
            select(ScoreReview)
            .where(
                ScoreReview.workspace_id == workspace_id,
                ScoreReview.finding_id == finding_id,
            )
            .order_by(ScoreReview.created_at)
        )
    ]
