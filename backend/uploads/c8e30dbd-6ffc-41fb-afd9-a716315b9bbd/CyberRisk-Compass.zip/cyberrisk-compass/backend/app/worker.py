"""Database-backed durable queue. Run one worker for SQLite; PostgreSQL permits multiple."""

import argparse, time, os
from pathlib import Path
from datetime import timedelta
from sqlalchemy import select, update, or_, and_
from .db import SessionLocal
from .models import (
    Job,
    Membership,
    User,
    Workspace,
    AuthSession,
    LoginThrottle,
    now,
    uid,
)
from .services import import_rows, snapshot, audit
from .reports import export_report
from .config import settings


def run_one():
    claim = uid()
    with SessionLocal() as db:
        eligible = or_(
            Job.status == "queued",
            and_(Job.status == "running", Job.lease_until < now()),
        )
        job = db.scalar(select(Job).where(eligible).order_by(Job.created_at).limit(1))
        if not job:
            return False
        job_id = job.id
        changed = db.execute(
            update(Job)
            .where(Job.id == job_id, eligible)
            .values(
                status="running",
                claim_token=claim,
                lease_until=now() + timedelta(minutes=15),
                attempts=Job.attempts + 1,
            )
        ).rowcount
        db.commit()
        if not changed:
            return True
    try:
        with SessionLocal() as db:
            # Lock through processing to prevent stale lease takeover on PostgreSQL.
            job = db.scalar(
                select(Job)
                .where(Job.id == job_id, Job.claim_token == claim)
                .with_for_update()
            )
            if not job:
                return True
            membership = db.scalar(
                select(Membership).where(
                    Membership.workspace_id == job.workspace_id,
                    Membership.user_id == job.actor_id,
                )
            )
            user = db.get(User, job.actor_id)
            allowed = (
                ("admin", "manager", "analyst")
                if job.kind == "import"
                else ("admin", "manager", "analyst", "viewer")
            )
            if (
                not membership
                or membership.role not in allowed
                or not user
                or not user.active
            ):
                job.status = "failed"
                job.result = {"error": "Permission revoked before execution"}
                job.payload = {}
            elif job.attempts > 3:
                job.status = "failed"
                job.result = {"error": "Retry limit exceeded"}
                job.payload = {}
            else:
                job.result = (
                    import_rows(db, job)
                    if job.kind == "import"
                    else export_report(db, job)
                )
                job.status = "succeeded"
                job.payload = {}
                if job.kind == "report":
                    audit(
                        db, job.workspace_id, job.actor_id, "report.completed", job.id
                    )
            job.lease_until = None
            db.commit()
    except Exception:
        # No exception text: DB errors can contain sensitive report values.
        with SessionLocal() as db:
            job = db.scalar(
                select(Job)
                .where(Job.id == job_id, Job.claim_token == claim)
                .with_for_update()
            )
            if job:
                job.status = "queued" if job.attempts < 3 else "failed"
                job.result = {
                    "error": "Processing failed; check worker/database configuration without exposing report contents"
                }
                if job.status == "failed":
                    job.payload = {}
                job.lease_until = None
                audit(
                    db,
                    job.workspace_id,
                    job.actor_id,
                    "job.processing_failed",
                    job.id,
                    {"attempt": job.attempts},
                )
                db.commit()
    return True


def maintenance():
    with SessionLocal() as db:
        for session in db.scalars(
            select(AuthSession).where(AuthSession.expires_at < now())
        ):
            db.delete(session)
        for throttle in db.scalars(
            select(LoginThrottle).where(
                LoginThrottle.window_start < now() - timedelta(days=1)
            )
        ):
            db.delete(throttle)
        for workspace in db.scalars(select(Workspace)):
            snapshot(db, workspace.id)
        cutoff = now() - timedelta(days=settings().job_retention_days)
        for job in db.scalars(
            select(Job).where(
                Job.created_at < cutoff, Job.status.in_(["succeeded", "failed"])
            )
        ):
            for suffix in ("csv", "pdf", "tmp"):
                path = Path(settings().report_dir) / f"{job.id}.{suffix}"
                path.unlink(missing_ok=True)
        db.commit()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    if args.once:
        run_one()
        return
    last_maintenance = 0
    while True:
        try:
            if time.monotonic() - last_maintenance > 3600:
                maintenance()
                last_maintenance = time.monotonic()
            if not run_one():
                time.sleep(2)
        except Exception:
            print(
                "Worker maintenance/queue unavailable; retrying (sensitive details suppressed)",
                flush=True,
            )
            time.sleep(5)


if __name__ == "__main__":
    main()
