"""Deterministic policy; no scanners or threat-intelligence lookups."""

import hashlib, json

POLICY = "compass-v1"
SEVERITY = {
    "critical": 40,
    "high": 30,
    "medium": 20,
    "low": 10,
    "informational": 0,
    "unknown": 30,
}
ALIASES = {"info": "informational", "moderate": "medium"}


def normalize_severity(value):
    label = value.strip().lower()
    return (
        ALIASES.get(label, label)
        if ALIASES.get(label, label) in SEVERITY
        else "unknown"
    )


def fingerprint(source, source_id, asset_id):
    # IDs are case-sensitive. Titles and descriptions are not identity.
    return hashlib.sha256(
        json.dumps(
            [source.strip(), source_id.strip(), asset_id], separators=(",", ":")
        ).encode()
    ).hexdigest()


def calculate(severity, criticality, internet_exposed, exploitation_reported):
    factors = [
        {
            "factor": "source_severity",
            "input": severity,
            "points": SEVERITY[severity],
            "max": 40,
        },
        {
            "factor": "asset_criticality",
            "input": criticality,
            "points": criticality * 5,
            "max": 25,
        },
        {
            "factor": "internet_exposure",
            "input": internet_exposed,
            "points": 20 if internet_exposed else 0,
            "max": 20,
        },
        {
            "factor": "reported_exploitation",
            "input": exploitation_reported,
            "points": 15 if exploitation_reported else 0,
            "max": 15,
        },
    ]
    score = sum(x["points"] for x in factors)
    return score, {
        "policy": POLICY,
        "factors": factors,
        "score": score,
        "warning": "Priority is not proof of security. Exploitation is source/user supplied, not independently verified.",
    }


def effective(finding):
    return (
        finding.override_score if finding.override_score is not None else finding.score
    )


def priority(score):
    return (
        "P1" if score >= 80 else "P2" if score >= 60 else "P3" if score >= 35 else "P4"
    )
