import itertools
import pytest
from app.risk import calculate, normalize_severity, fingerprint, priority


@pytest.mark.parametrize(
    "severity,criticality,exposed,exploitation",
    list(
        itertools.product(
            ["critical", "high", "medium", "low", "informational", "unknown"],
            range(1, 6),
            [False, True],
            [False, True],
        )
    ),
)
def test_factor_matrix(severity, criticality, exposed, exploitation):
    points = {
        "critical": 40,
        "high": 30,
        "medium": 20,
        "low": 10,
        "informational": 0,
        "unknown": 30,
    }
    expected = points[severity] + criticality * 5 + 20 * exposed + 15 * exploitation
    score, explanation = calculate(severity, criticality, exposed, exploitation)
    assert score == expected and 0 <= score <= 100
    assert explanation["score"] == score
    assert sum(f["points"] for f in explanation["factors"]) == score
    assert calculate(severity, criticality, exposed, exploitation) == (
        score,
        explanation,
    )


def test_normalization_and_identity():
    assert normalize_severity(" Critical ") == "critical"
    assert normalize_severity("info") == "informational"
    assert normalize_severity("Unrated vendor label") == "unknown"
    assert fingerprint("source", "ID", "asset") != fingerprint("source", "id", "asset")
    assert fingerprint("source", "ID", "asset") != fingerprint("source", "ID", "other")


def test_boundaries():
    assert [priority(s) for s in [34, 35, 59, 60, 79, 80]] == [
        "P4",
        "P3",
        "P3",
        "P2",
        "P2",
        "P1",
    ]


def test_monotonicity():
    for criticality in range(1, 5):
        assert (
            calculate("high", criticality + 1, False, False)[0]
            > calculate("high", criticality, False, False)[0]
        )
        assert (
            calculate("high", criticality, True, False)[0]
            > calculate("high", criticality, False, False)[0]
        )
