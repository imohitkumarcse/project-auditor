import pytest
from app.config import Settings


def test_production_requires_secure_configuration(tmp_path):
    baseline = dict(
        _env_file=None,
        environment="production",
        database_url="postgresql+psycopg://unused:unused@localhost/unused",
        session_secret="synthetic-production-config-check-secret-123456789",
        allowed_origins="https://compass.example.test",
        allowed_hosts="compass.example.test",
        secure_cookies=True,
        report_dir=str(tmp_path),
    )
    assert Settings(**baseline).environment == "production"
    for changes in [
        {"secure_cookies": False},
        {"database_url": "sqlite:///ignored.db"},
        {"allowed_origins": "http://localhost:3000"},
        {"allowed_hosts": "*"},
        {"session_secret": "local-only-change-this-secret-at-least-32-characters"},
        {
            "session_secret": "replace-this-with-a-random-secret-of-at-least-48-characters"
        },
    ]:
        with pytest.raises(ValueError):
            Settings(**{**baseline, **changes})
