"""In-process API checks. No requests are made to external systems."""

import json
from datetime import timedelta
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from app.main import app
from app.db import SessionLocal
from app.models import Asset, Finding, Membership, AuthSession, Job, now
from app.worker import run_one, maintenance
from app.auth import digest


def asset(client, workspace, external="demo-web"):
    response = client.post(
        f"/workspaces/{workspace}/assets",
        json={
            "external_id": external,
            "name": "Synthetic asset",
            "owner": "Example team",
            "criticality": 5,
            "internet_exposed": True,
        },
    )
    assert response.status_code == 201, response.text
    return response.json()


def row(external="demo-web", source_id="SYN-1"):
    return dict(
        asset_external_id=external,
        source="synthetic",
        source_id=source_id,
        source_severity="High",
        title="Synthetic finding",
    )


def submit(client, workspace, rows):
    return client.post(
        f"/workspaces/{workspace}/imports",
        files={"file": ("r.json", json.dumps(rows).encode(), "application/json")},
    )


def finding(client, workspace):
    asset(client, workspace)
    response = submit(client, workspace, [row()])
    assert response.status_code == 202, response.text
    assert run_one()
    return client.get(f"/workspaces/{workspace}/findings").json()[0]


def test_end_to_end_and_dedup(system):
    client, workspace = system["client"], system["wa"]
    base = f"/workspaces/{workspace}"
    record = finding(client, workspace)
    assert record["score"] == 75 and record["source_severity"] == "High"
    first_seen = record["first_seen"]
    queued = submit(client, workspace, [row(), row()])
    assert queued.status_code == 202
    run_one()
    records = client.get(base + "/findings").json()
    assert len(records) == 1 and records[0]["first_seen"] == first_seen
    job = client.get(base + "/jobs/" + queued.json()["id"]).json()
    assert job["result"]["duplicates_in_file"] == 1
    response = client.post(
        base + "/tasks",
        json={
            "finding_id": record["id"],
            "owner_user_id": system["a"],
            "deadline": "2026-01-01",
        },
    )
    assert response.status_code == 201
    task = response.json()
    update = dict(
        owner_user_id=system["a"], deadline="2026-01-01", status="done", evidence=""
    )
    assert client.patch(base + "/tasks/" + task["id"], json=update).status_code == 422
    update["evidence"] = "Synthetic remediation reviewed and confirmed."
    assert client.patch(base + "/tasks/" + task["id"], json=update).status_code == 200
    assert client.get(base + "/findings/" + record["id"]).json()["status"] == "resolved"
    assert client.get(base + "/dashboard").json()["open_findings"] == 0
    assert submit(client, workspace, [row()]).status_code == 202
    run_one()
    assert client.get(base + "/findings/" + record["id"]).json()["status"] == "open"
    task = client.get(base + "/tasks").json()[0]
    assert task["status"] == "in_progress" and task["evidence"]
    assert client.get(base + "/history").json()[0]["open_findings"] == 1
    assert "password" not in client.get(base + "/audit").text.lower()


def test_override_preserves_source_and_history(system):
    client, workspace = system["client"], system["wa"]
    record = finding(client, workspace)
    path = f"/workspaces/{workspace}/findings/{record['id']}"
    response = client.patch(
        path + "/override",
        json={
            "score": 20,
            "reason": "Synthetic compensating control reviewed",
        },
    )
    assert response.status_code == 200
    assert response.json()["score"] == 75 and response.json()["effective_score"] == 20
    assert response.json()["source_severity"] == "High"
    assert (
        client.patch(
            path + "/override",
            json={
                "score": None,
                "reason": "Synthetic control no longer applicable",
            },
        ).status_code
        == 200
    )
    assert len(client.get(path + "/reviews").json()) == 2
    assert client.get(path).json()["effective_score"] == 75


@pytest.mark.parametrize(
    "suffix",
    [
        "assets",
        "findings",
        "tasks",
        "risks",
        "dashboard",
        "history",
        "audit",
        "jobs",
        "members",
    ],
)
def test_other_tenant_lists_denied(system, suffix):
    assert (
        system["client"].get(f"/workspaces/{system['wb']}/{suffix}").status_code == 404
    )


@pytest.mark.parametrize(
    "suffix,payload",
    [
        ("assets", {"external_id": "x", "name": "x"}),
        ("reports", {"format": "csv"}),
        ("tasks", {"finding_id": "x", "deadline": "2026-10-13"}),
        (
            "members",
            {
                "email": "new@example.test",
                "password": "Example-test-123",
                "role": "viewer",
            },
        ),
        (
            "risks",
            {
                "title": "x",
                "treatment": "accept",
                "rationale": "Synthetic test reason",
                "review_date": "2026-10-13",
            },
        ),
        ("siblings", {"name": "x"}),
    ],
)
def test_other_tenant_mutations_denied(system, suffix, payload):
    assert (
        system["client"]
        .post(f"/workspaces/{system['wb']}/{suffix}", json=payload)
        .status_code
        == 404
    )


def test_other_tenant_ids_and_owner_denied(system):
    client, wa, wb = system["client"], system["wa"], system["wb"]
    other = system["login"]("b@example.test")
    record_b = finding(other, wb)
    assert client.get(f"/workspaces/{wa}/findings/{record_b['id']}").status_code == 404
    assert (
        client.patch(
            f"/workspaces/{wa}/findings/{record_b['id']}/override",
            json={
                "score": 1,
                "reason": "Synthetic review reason",
            },
        ).status_code
        == 404
    )
    assert (
        client.post(
            f"/workspaces/{wa}/tasks",
            json={
                "finding_id": record_b["id"],
                "deadline": "2026-10-13",
            },
        ).status_code
        == 404
    )
    asset(client, wa)
    assert submit(client, wa, [row()]).status_code == 202
    run_one()
    record = client.get(f"/workspaces/{wa}/findings").json()[0]
    assert (
        client.post(
            f"/workspaces/{wa}/tasks",
            json={
                "finding_id": record["id"],
                "owner_user_id": system["b"],
                "deadline": "2026-10-13",
            },
        ).status_code
        == 422
    )
    report = other.post(f"/workspaces/{wb}/reports", json={"format": "csv"}).json()
    run_one()
    assert client.get(f"/workspaces/{wa}/jobs/{report['id']}").status_code == 404
    assert (
        client.get(f"/workspaces/{wa}/reports/{report['id']}/download").status_code
        == 404
    )
    assert (
        client.get(f"/workspaces/{wb}/reports/{report['id']}/download").status_code
        == 404
    )


def test_database_rejects_cross_tenant_relationship(system):
    with SessionLocal() as db:
        record = Asset(
            workspace_id=system["wb"], external_id="B", name="B", criticality=5
        )
        db.add(record)
        db.commit()
        db.add(
            Finding(
                workspace_id=system["wa"],
                asset_id=record.id,
                fingerprint="x" * 64,
                source="synthetic",
                source_id="id",
                source_severity="High",
                normalized_severity="high",
                title="Mismatch",
                score=30,
                factors={},
            )
        )
        with pytest.raises(IntegrityError):
            db.commit()


def test_import_validation_is_atomic(system):
    client, workspace = system["client"], system["wa"]
    asset(client, workspace)
    assert submit(client, workspace, [row(), row("unknown")]).status_code == 422
    assert client.get(f"/workspaces/{workspace}/jobs").json() == []
    assert client.get(f"/workspaces/{workspace}/findings").json() == []
    conflicting = row()
    conflicting["title"] = "Different title for the same identity"
    assert submit(client, workspace, [row(), conflicting]).status_code == 422


def test_csrf_origin_roles_and_session_expiry(system):
    client, workspace = system["client"], system["wa"]
    csrf = client.headers.pop("X-CSRF-Token")
    assert (
        client.post(
            f"/workspaces/{workspace}/reports", json={"format": "csv"}
        ).status_code
        == 403
    )
    client.headers["X-CSRF-Token"] = csrf
    assert (
        client.post(
            f"/workspaces/{workspace}/reports",
            json={"format": "csv"},
            headers={"Origin": "https://unapproved.example.test"},
        ).status_code
        == 403
    )
    viewer = system["login"]("viewer@example.test")
    assert viewer.get(f"/workspaces/{workspace}/assets").status_code == 200
    assert (
        viewer.post(
            f"/workspaces/{workspace}/assets", json={"external_id": "x", "name": "x"}
        ).status_code
        == 403
    )
    assert viewer.get(f"/workspaces/{workspace}/audit").status_code == 403
    with SessionLocal() as db:
        session = db.get(AuthSession, digest(client.cookies.get("compass_session")))
        session.expires_at = now() - timedelta(seconds=1)
        db.commit()
    assert client.get("/workspaces").status_code == 401


def test_csv_pdf_and_export_safety(system):
    client, workspace = system["client"], system["wa"]
    asset(client, workspace)
    record = row()
    record["title"] = "=SUM(1,2)"
    assert submit(client, workspace, [record]).status_code == 202
    run_one()
    for fmt in ["csv", "pdf"]:
        report = client.post(
            f"/workspaces/{workspace}/reports", json={"format": fmt}
        ).json()
        run_one()
        response = client.get(
            f"/workspaces/{workspace}/reports/{report['id']}/download"
        )
        assert response.status_code == 200
        if fmt == "csv":
            assert "'=SUM" in response.text
        else:
            assert response.content.startswith(b"%PDF")
    assert all(
        "payload" not in j for j in client.get(f"/workspaces/{workspace}/jobs").json()
    )


def test_job_permissions_rechecked(system):
    client, workspace = system["client"], system["wa"]
    asset(client, workspace)
    queued = submit(client, workspace, [row()]).json()
    with SessionLocal() as db:
        membership = db.scalar(
            select(Membership).where(
                Membership.user_id == system["a"],
                Membership.workspace_id == workspace,
            )
        )
        membership.role = "viewer"
        db.commit()
    run_one()
    assert (
        client.get(f"/workspaces/{workspace}/jobs/{queued['id']}").json()["status"]
        == "failed"
    )
    assert client.get(f"/workspaces/{workspace}/findings").json() == []


def test_last_admin_and_risk_acceptance(system):
    client, workspace = system["client"], system["wa"]
    record = finding(client, workspace)
    base = f"/workspaces/{workspace}"
    member = next(
        m for m in client.get(base + "/members").json() if m["user_id"] == system["a"]
    )
    assert (
        client.patch(
            base + "/members/" + member["id"], json={"role": "viewer"}
        ).status_code
        == 409
    )
    assert (
        client.post(
            base + "/risks",
            json={
                "title": "Synthetic accepted risk",
                "owner_user_id": system["a"],
                "finding_id": record["id"],
                "treatment": "accept",
                "rationale": "Synthetic acceptance approved for exercise",
                "review_date": "2026-11-01",
            },
        ).status_code
        == 201
    )
    assert client.get(base + "/findings/" + record["id"]).json()["status"] == "open"


def test_throttling_logout_and_body_limit(system):
    anonymous = TestClient(app)
    for _ in range(5):
        assert (
            anonymous.post(
                "/auth/login",
                json={
                    "email": "absent@example.test",
                    "password": "synthetic-invalid",
                },
            ).status_code
            == 401
        )
    assert (
        anonymous.post(
            "/auth/login",
            json={
                "email": "absent@example.test",
                "password": "synthetic-invalid",
            },
        ).status_code
        == 429
    )
    client = system["client"]
    assert (
        client.post(
            "/auth/login",
            content=b"a" * 33000,
            headers={"Content-Type": "application/json"},
        ).status_code
        == 413
    )
    assert client.post("/auth/logout").status_code == 200
    assert client.get("/workspaces").status_code == 401
    assert anonymous.get("/health").json()["external_scanning"] is False


def test_password_change_preserves_spaces_and_revokes_sessions(system):
    from conftest import PASSWORD

    client = system["client"]
    second = system["login"]("a@example.test")
    chosen = "  Synthetic-new-password-123!  "
    assert (
        client.post(
            "/auth/password",
            json={
                "current_password": PASSWORD,
                "new_password": chosen,
            },
        ).status_code
        == 200
    )
    assert client.get("/workspaces").status_code == 401
    assert second.get("/workspaces").status_code == 401
    assert (
        second.post(
            "/auth/login",
            json={
                "email": "a@example.test",
                "password": chosen.strip(),
            },
        ).status_code
        == 401
    )
    assert (
        second.post(
            "/auth/login",
            json={
                "email": "a@example.test",
                "password": chosen,
            },
        ).status_code
        == 200
    )


def test_cross_tenant_upload_and_nested_records(system):
    client, wa, wb = system["client"], system["wa"], system["wb"]
    other = system["login"]("b@example.test")
    record = finding(other, wb)
    assert submit(client, wb, [row()]).status_code == 404
    task = other.post(
        f"/workspaces/{wb}/tasks",
        json={
            "finding_id": record["id"],
            "owner_user_id": system["b"],
            "deadline": "2026-11-01",
        },
    ).json()
    assert (
        client.patch(
            f"/workspaces/{wa}/tasks/{task['id']}",
            json={
                "owner_user_id": system["a"],
                "deadline": "2026-11-01",
                "status": "done",
                "evidence": "Synthetic resolution evidence",
            },
        ).status_code
        == 404
    )
    risk_data = {
        "title": "Synthetic risk",
        "finding_id": record["id"],
        "owner_user_id": system["b"],
        "treatment": "accept",
        "rationale": "Synthetic review rationale",
        "review_date": "2026-11-01",
    }
    risk = other.post(f"/workspaces/{wb}/risks", json=risk_data).json()
    assert (
        client.patch(f"/workspaces/{wa}/risks/{risk['id']}", json=risk_data).status_code
        == 404
    )
    member = other.get(f"/workspaces/{wb}/members").json()[0]
    assert (
        client.patch(
            f"/workspaces/{wa}/members/{member['id']}", json={"role": "viewer"}
        ).status_code
        == 404
    )
    assert (
        client.get(f"/workspaces/{wa}/findings/{record['id']}/reviews").status_code
        == 404
    )
    assert (
        client.patch(
            f"/workspaces/{wa}/assets/{record['asset_id']}",
            json={
                "name": "Attempted change",
                "owner": "Synthetic",
                "criticality": 1,
                "internet_exposed": False,
            },
        ).status_code
        == 404
    )


def test_asset_rescoring_and_report_expiry(system):
    from pathlib import Path
    from app.config import settings

    client, workspace = system["client"], system["wa"]
    record = finding(client, workspace)
    base = f"/workspaces/{workspace}"
    assert (
        client.patch(
            base + "/assets/" + record["asset_id"],
            json={
                "name": "Synthetic asset",
                "owner": "Example team",
                "criticality": 2,
                "internet_exposed": False,
            },
        ).status_code
        == 200
    )
    assert client.get(base + "/findings/" + record["id"]).json()["score"] == 40
    report = client.post(base + "/reports", json={"format": "csv"}).json()
    run_one()
    path = Path(settings().report_dir) / (report["id"] + ".csv")
    assert path.is_file()
    with SessionLocal() as db:
        db.get(Job, report["id"]).created_at = now() - timedelta(days=8)
        db.commit()
    maintenance()
    assert not path.exists()
    assert (
        client.get(base + "/reports/" + report["id"] + "/download").status_code == 410
    )


def test_schema_baseline_matches_runtime():
    from migrations.schema_v1 import metadata
    from app.db import Base

    assert set(metadata.tables) == set(Base.metadata.tables)
    for name in metadata.tables:
        assert set(metadata.tables[name].columns.keys()) == set(
            Base.metadata.tables[name].columns.keys()
        )


def test_validation_never_echoes_secret_values(system):
    secret = "synthetic-sensitive-" + "x" * 300
    response = system["client"].post(
        "/auth/login",
        json={
            "email": "a@example.test",
            "password": secret,
        },
    )
    assert response.status_code == 422
    assert secret not in response.text


def test_role_privileges_and_member_provisioning(system):
    client, workspace = system["client"], system["wa"]
    record = finding(client, workspace)
    base = f"/workspaces/{workspace}"
    initial = "Synthetic-member-password-123!"
    response = client.post(
        base + "/members",
        json={
            "email": "new@example.test",
            "password": initial,
            "role": "analyst",
        },
    )
    assert response.status_code == 201 and initial not in response.text
    member = response.json()
    new_client = TestClient(app)
    auth = new_client.post(
        "/auth/login",
        json={
            "email": "new@example.test",
            "password": initial,
        },
    )
    assert auth.status_code == 200
    new_client.headers["X-CSRF-Token"] = auth.json()["csrf_token"]
    override = base + "/findings/" + record["id"] + "/override"
    assert (
        new_client.patch(
            override,
            json={
                "score": 50,
                "reason": "Synthetic analyst review",
            },
        ).status_code
        == 403
    )
    assert (
        client.patch(
            base + "/members/" + member["id"], json={"role": "manager"}
        ).status_code
        == 200
    )
    assert (
        new_client.patch(
            override,
            json={
                "score": 50,
                "reason": "Synthetic manager review",
            },
        ).status_code
        == 200
    )
    assert (
        new_client.post(
            base + "/members",
            json={
                "email": "other@example.test",
                "password": initial,
                "role": "viewer",
            },
        ).status_code
        == 403
    )
    assert (
        client.post(
            base + "/members",
            json={
                "email": "new@example.test",
                "password": initial,
                "role": "viewer",
            },
        ).status_code
        == 422
    )
    new_client.close()


def test_cookie_flags_and_anonymous_report_denial(system):
    from conftest import PASSWORD

    client, workspace = system["client"], system["wa"]
    response = TestClient(app).post(
        "/auth/login",
        json={
            "email": "a@example.test",
            "password": PASSWORD,
        },
    )
    cookie = response.headers["set-cookie"].lower()
    assert "httponly" in cookie and "samesite=lax" in cookie and "max-age=" in cookie
    queued = client.post(
        f"/workspaces/{workspace}/reports", json={"format": "csv"}
    ).json()
    run_one()
    assert (
        TestClient(app)
        .get(f"/workspaces/{workspace}/reports/{queued['id']}/download")
        .status_code
        == 401
    )
