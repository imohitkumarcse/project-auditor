import pytest
from test_api import finding
from app.worker import run_one


@pytest.mark.parametrize("dataset", ["history", "risks"])
@pytest.mark.parametrize("fmt", ["csv", "pdf"])
def test_history_and_register_exports(system, dataset, fmt):
    client, workspace = system["client"], system["wa"]
    record = finding(client, workspace)
    base = f"/workspaces/{workspace}"
    assert (
        client.post(
            base + "/risks",
            json={
                "title": "Synthetic accepted risk",
                "finding_id": record["id"],
                "treatment": "accept",
                "rationale": "Synthetic test-only rationale",
                "review_date": "2026-11-01",
            },
        ).status_code
        == 201
    )
    queued = client.post(
        base + "/reports", json={"format": fmt, "dataset": dataset}
    ).json()
    run_one()
    status = client.get(base + "/jobs/" + queued["id"]).json()
    assert status["status"] == "succeeded" and status["result"]["record_count"] == 1
    response = client.get(base + "/reports/" + queued["id"] + "/download")
    assert response.status_code == 200
    if fmt == "csv":
        assert (
            "open_findings" if dataset == "history" else "rationale"
        ) in response.text
    else:
        assert response.content.startswith(b"%PDF")
