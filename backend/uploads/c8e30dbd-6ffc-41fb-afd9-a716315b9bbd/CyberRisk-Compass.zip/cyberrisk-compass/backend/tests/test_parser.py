import json
from pathlib import Path
import pytest
from app.importer import parse, ImportErrorSafe

FIXTURES = Path(__file__).resolve().parents[2] / "fixtures"


def fixture(name):
    path = FIXTURES / name
    return path if path.exists() else Path("/fixtures") / name


def test_golden_csv_json():
    records = parse(fixture("findings.json").read_bytes(), "findings.json")
    csv_records = parse(fixture("findings.csv").read_bytes(), "findings.csv")
    assert len(records) == 4 and len(csv_records) == 3
    for a, b in zip(records, csv_records):
        for key in [
            "asset_external_id",
            "source",
            "source_id",
            "source_severity",
            "title",
            "vulnerability_id",
            "exploitation_reported",
        ]:
            assert a[key] == b[key]
    assert all(record["vulnerability_id"] is None for record in records)


@pytest.mark.parametrize(
    "content,name",
    [
        (b"{bad", "r.json"),
        (b"{}", "r.json"),
        (b"[]", "r.json"),
        (b"\xff", "r.csv"),
        (b"x,x\na,b", "r.csv"),
        (b"hello", "r.exe"),
        (b"\x00", "r.csv"),
        (b'[{"source":"a","source":"b"}]', "r.json"),
        (b'[{"exploitation_reported":true}]', "r.json"),
        (b'asset_external_id,source\n"unfinished', "r.csv"),
        (b"asset_external_id,source\none,two,three", "r.csv"),
    ],
)
def test_bad_inputs(content, name):
    with pytest.raises(ImportErrorSafe):
        parse(content, name)


def test_size_and_rows():
    with pytest.raises(ImportErrorSafe):
        parse(b"a" * 2_000_001, "r.csv")
    record = parse(fixture("findings.json").read_bytes(), "r.json")[0]
    with pytest.raises(ImportErrorSafe):
        parse(json.dumps([record] * 5001).encode(), "r.json")


def test_exploitation_requires_evidence():
    record = parse(fixture("findings.json").read_bytes(), "r.json")[0]
    record["exploitation_reported"] = True
    with pytest.raises(ImportErrorSafe):
        parse(json.dumps([record]).encode(), "r.json")
    record["exploitation_evidence"] = "Synthetic exercise assertion only"
    assert parse(json.dumps([record]).encode(), "r.json")[0]["exploitation_reported"]
    record["exploitation_reported"] = "yes"
    with pytest.raises(ImportErrorSafe):
        parse(json.dumps([record]).encode(), "r.json")


def test_unknown_fields_and_source_identifier_are_not_invented():
    record = parse(fixture("findings.json").read_bytes(), "r.json")[0]
    record["tenant_id"] = "untrusted-upstream-value"
    with pytest.raises(ImportErrorSafe):
        parse(json.dumps([record]).encode(), "r.json")
    del record["tenant_id"]
    del record["source_id"]
    with pytest.raises(ImportErrorSafe):
        parse(json.dumps([record]).encode(), "r.json")
