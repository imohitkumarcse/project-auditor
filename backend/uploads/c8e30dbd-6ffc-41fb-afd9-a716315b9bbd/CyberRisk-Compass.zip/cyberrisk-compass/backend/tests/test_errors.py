from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session


def test_database_errors_do_not_echo_parameters_and_roll_back(system, monkeypatch):
    def unavailable(self):
        raise SQLAlchemyError("synthetic-sensitive-report-parameter")

    monkeypatch.setattr(Session, "commit", unavailable)
    base = f"/workspaces/{system['wa']}"
    response = system["client"].post(
        base + "/assets",
        json={
            "external_id": "example-error",
            "name": "Synthetic secret report title",
        },
    )
    assert response.status_code == 503
    assert "synthetic-sensitive-report-parameter" not in response.text
    assert "Synthetic secret report title" not in response.text
    assert system["client"].get(base + "/assets").json() == []
