"""All test records are synthetic. TEST_DATABASE_URL must be disposable."""

import os
import tempfile
from pathlib import Path

if os.environ.get("TEST_DATABASE_URL"):
    from sqlalchemy.engine import make_url

    test_url = make_url(os.environ["TEST_DATABASE_URL"])
    if not test_url.database or not test_url.database.endswith("_test"):
        raise RuntimeError("Explicit test databases must have a name ending in _test")
    os.environ["DATABASE_URL"] = os.environ["TEST_DATABASE_URL"]
else:
    os.environ["DATABASE_URL"] = "sqlite:///" + str(
        Path(tempfile.mkdtemp()) / "compass.db"
    )
os.environ["REPORT_DIR"] = tempfile.mkdtemp()
os.environ["SESSION_SECRET"] = "test-only-secret-12345678901234567890123456789"
os.environ["ENVIRONMENT"] = "development"
os.environ["SECURE_COOKIES"] = "false"
os.environ["ALLOWED_HOSTS"] = "testserver,localhost,127.0.0.1"

import pytest
from fastapi.testclient import TestClient
from app.db import Base, engine, SessionLocal
from app.models import User, Organisation, Workspace, Membership
from app.auth import hash_password
from app.main import app

PASSWORD = "Synthetic-test-password-123!"
PASSWORD_HASH = hash_password(PASSWORD)


@pytest.fixture
def system():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        a = User(email="a@example.test", password_hash=PASSWORD_HASH)
        b = User(email="b@example.test", password_hash=PASSWORD_HASH)
        viewer = User(email="viewer@example.test", password_hash=PASSWORD_HASH)
        db.add_all([a, b, viewer])
        db.flush()
        oa, ob = Organisation(name="Synthetic A"), Organisation(name="Synthetic B")
        db.add_all([oa, ob])
        db.flush()
        wa = Workspace(name="A", organisation_id=oa.id)
        wb = Workspace(name="B", organisation_id=ob.id)
        db.add_all([wa, wb])
        db.flush()
        db.add_all(
            [
                Membership(workspace_id=wa.id, user_id=a.id, role="admin"),
                Membership(workspace_id=wb.id, user_id=b.id, role="admin"),
                Membership(workspace_id=wa.id, user_id=viewer.id, role="viewer"),
            ]
        )
        db.commit()
        result = {"a": a.id, "b": b.id, "viewer": viewer.id, "wa": wa.id, "wb": wb.id}
    clients = []

    def login(email):
        client = TestClient(app)
        clients.append(client)
        response = client.post(
            "/auth/login", json={"email": email, "password": PASSWORD}
        )
        assert response.status_code == 200
        client.headers["X-CSRF-Token"] = response.json()["csrf_token"]
        return client

    result["login"] = login
    result["client"] = login("a@example.test")
    yield result
    for client in clients:
        client.close()
    Base.metadata.drop_all(engine)
