"""Initial schema. Freeze this migration; future changes require explicit revisions."""

from alembic import op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


# This baseline imports a frozen copy, not evolving application models.
def upgrade():
    from migrations.schema_v1 import metadata

    metadata.create_all(op.get_bind())


def downgrade():
    from migrations.schema_v1 import metadata

    metadata.drop_all(op.get_bind())
