import uuid
from datetime import datetime, timezone
from sqlalchemy import (
    String,
    Text,
    Integer,
    Boolean,
    Float,
    ForeignKey,
    UniqueConstraint,
    CheckConstraint,
    ForeignKeyConstraint,
    JSON,
)
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


def uid():
    return str(uuid.uuid4())


def now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    email: Mapped[str] = mapped_column(String(254), unique=True)
    password_hash: Mapped[str] = mapped_column(Text)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Organisation(Base):
    __tablename__ = "organisations"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    name: Mapped[str] = mapped_column(String(120))


class Workspace(Base):
    __tablename__ = "workspaces"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    organisation_id: Mapped[str] = mapped_column(ForeignKey("organisations.id"))
    name: Mapped[str] = mapped_column(String(120))


class Membership(Base):
    __tablename__ = "memberships"
    __table_args__ = (
        UniqueConstraint("workspace_id", "user_id"),
        CheckConstraint("role IN ('admin','manager','analyst','viewer')"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    role: Mapped[str] = mapped_column(String(20))


class AuthSession(Base):
    __tablename__ = "auth_sessions"
    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    csrf_hash: Mapped[str] = mapped_column(String(64))
    expires_at: Mapped[datetime] = mapped_column()


class LoginThrottle(Base):
    __tablename__ = "login_throttles"
    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    failures: Mapped[int] = mapped_column(Integer, default=0)
    window_start: Mapped[datetime] = mapped_column(default=now)


class Asset(Base):
    __tablename__ = "assets"
    __table_args__ = (
        UniqueConstraint("workspace_id", "external_id"),
        UniqueConstraint("workspace_id", "id"),
        CheckConstraint("criticality BETWEEN 1 AND 5"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    external_id: Mapped[str] = mapped_column(String(120))
    name: Mapped[str] = mapped_column(String(200))
    owner: Mapped[str] = mapped_column(String(200), default="Unassigned")
    criticality: Mapped[int] = mapped_column(Integer, default=3)
    internet_exposed: Mapped[bool] = mapped_column(Boolean, default=False)


class Finding(Base):
    __tablename__ = "findings"
    __table_args__ = (
        UniqueConstraint("workspace_id", "fingerprint"),
        UniqueConstraint("workspace_id", "id"),
        ForeignKeyConstraint(
            ["workspace_id", "asset_id"], ["assets.workspace_id", "assets.id"]
        ),
        CheckConstraint("score BETWEEN 0 AND 100"),
        CheckConstraint("override_score IS NULL OR override_score BETWEEN 0 AND 100"),
        CheckConstraint("status IN ('open','resolved')"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.id"))
    fingerprint: Mapped[str] = mapped_column(String(64))
    source: Mapped[str] = mapped_column(String(120))
    source_id: Mapped[str] = mapped_column(String(200))
    source_severity: Mapped[str] = mapped_column(String(80))
    normalized_severity: Mapped[str] = mapped_column(String(20))
    vulnerability_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    title: Mapped[str] = mapped_column(String(300))
    description: Mapped[str] = mapped_column(Text, default="")
    exploitation_reported: Mapped[bool] = mapped_column(Boolean, default=False)
    exploitation_evidence: Mapped[str] = mapped_column(Text, default="")
    score: Mapped[int] = mapped_column(Integer)
    factors: Mapped[dict] = mapped_column(JSON)
    override_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    override_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="open")
    first_seen: Mapped[datetime] = mapped_column(default=now)
    last_seen: Mapped[datetime] = mapped_column(default=now)


class Task(Base):
    __tablename__ = "tasks"
    __table_args__ = (
        ForeignKeyConstraint(
            ["workspace_id", "finding_id"], ["findings.workspace_id", "findings.id"]
        ),
        ForeignKeyConstraint(
            ["workspace_id", "owner_user_id"],
            ["memberships.workspace_id", "memberships.user_id"],
        ),
        CheckConstraint("status IN ('todo','in_progress','blocked','done')"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    finding_id: Mapped[str] = mapped_column(ForeignKey("findings.id"), unique=True)
    owner_user_id: Mapped[str | None] = mapped_column(
        ForeignKey("users.id"), nullable=True
    )
    deadline: Mapped[str] = mapped_column(String(10))
    status: Mapped[str] = mapped_column(String(20), default="todo")
    evidence: Mapped[str] = mapped_column(Text, default="")
    updated_at: Mapped[datetime] = mapped_column(default=now)


class RiskEntry(Base):
    __tablename__ = "risk_register"
    __table_args__ = (
        ForeignKeyConstraint(
            ["workspace_id", "finding_id"], ["findings.workspace_id", "findings.id"]
        ),
        ForeignKeyConstraint(
            ["workspace_id", "owner_user_id"],
            ["memberships.workspace_id", "memberships.user_id"],
        ),
        CheckConstraint("treatment IN ('mitigate','accept','avoid','transfer')"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    title: Mapped[str] = mapped_column(String(300))
    owner_user_id: Mapped[str | None] = mapped_column(
        ForeignKey("users.id"), nullable=True
    )
    finding_id: Mapped[str | None] = mapped_column(
        ForeignKey("findings.id"), nullable=True
    )
    treatment: Mapped[str] = mapped_column(String(20))
    rationale: Mapped[str] = mapped_column(Text)
    review_date: Mapped[str] = mapped_column(String(10))


class Audit(Base):
    __tablename__ = "audit_logs"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    actor_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    action: Mapped[str] = mapped_column(String(100))
    target_id: Mapped[str] = mapped_column(String(100))
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(default=now)


class Job(Base):
    __tablename__ = "jobs"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    actor_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    kind: Mapped[str] = mapped_column(String(20))
    status: Mapped[str] = mapped_column(String(20), default="queued", index=True)
    payload: Mapped[dict] = mapped_column(JSON)
    result: Mapped[dict] = mapped_column(JSON, default=dict)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    lease_until: Mapped[datetime | None] = mapped_column(nullable=True)
    claim_token: Mapped[str | None] = mapped_column(String(36), nullable=True)
    created_at: Mapped[datetime] = mapped_column(default=now)


class Snapshot(Base):
    __tablename__ = "risk_snapshots"
    __table_args__ = (UniqueConstraint("workspace_id", "day"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    day: Mapped[str] = mapped_column(String(10))
    open_findings: Mapped[int] = mapped_column(Integer)
    high_priority: Mapped[int] = mapped_column(Integer)
    average_score: Mapped[float] = mapped_column(Float)


class ScoreReview(Base):
    __tablename__ = "score_reviews"
    __table_args__ = (
        ForeignKeyConstraint(
            ["workspace_id", "finding_id"], ["findings.workspace_id", "findings.id"]
        ),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    finding_id: Mapped[str] = mapped_column(ForeignKey("findings.id"))
    actor_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    reason: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(default=now)


metadata = Base.metadata
