# Deployment guide

## Local Docker / PostgreSQL (not production)

Docker Desktop must be running. From repository root:

```powershell
Copy-Item .env.example .env
```

Edit `.env` with a new URL-safe database password and a new random session secret. Generate a secret without storing it in chat:

```powershell
py -3.13 -c "import secrets; print(secrets.token_urlsafe(48))"
```

The database password is interpolated into a connection URL; use URL-safe characters or explicitly URL-encode it when defining a custom DATABASE_URL. Do not keep the example values.

```powershell
docker compose up --build -d
docker compose exec api python -m app.cli seed
```

Provisioning prompts for the administrative account password (12+ characters). The separate worker can also process the queued synthetic import. Open http://localhost:3000 and sign in as admin@example.test. PostgreSQL and reports persist in named volumes. Run `docker compose logs --tail=50 api worker` for operational status, without enabling body/credential logging.

Stop services with `docker compose down`; this preserves volumes. **Do not use `down -v` unless you intend to destroy the demo database/report volumes.** Docker config is intentionally bound to localhost, development cookies and a database owner account; it is not a production manifest.

## Production checklist

1. Deploy PostgreSQL on protected infrastructure with TLS, encryption, backups and a tested restore procedure. SQLite is refused when ENVIRONMENT=production.
2. Use separate migration and runtime DB users. Run `alembic upgrade head` once before rolling out API/worker instances. Runtime role needs table CRUD plus SELECT/INSERT on audit and review tables, but no DDL or audit/review UPDATE/DELETE. Do not use the Docker sample owner role for production runtime.
3. Run API and worker under unprivileged service accounts, sharing a protected report volume. Configure the same DATABASE_URL, SESSION_SECRET and REPORT_DIR. Only worker produces files; API must be able to read files. Report storage must not be served by nginx/static hosting.
4. Set `ENVIRONMENT=production`, `SECURE_COOKIES=true`, a secret-managed random SESSION_SECRET, exact HTTPS ALLOWED_ORIGINS and exact ALLOWED_HOSTS. Refuse shared demo values. Secrets must not be included in frontend build args.
5. Host UI/API under the same registrable HTTPS domain (e.g., compass.example.com and api.example.com) or route `/api` through the same origin. Cross-site domains conflict with SameSite=Lax and third-party cookie restrictions. Set NEXT_PUBLIC_API_URL to the public API origin or proxy prefix **at build time**, then rebuild the frontend.
6. Terminate TLS at a maintained reverse proxy, restrict upstream connectivity and configure trusted forwarded-header peers explicitly. Add edge request/body limits, timeouts and account-independent rate limiting. The app caps request/file sizes, but edge limits avoid excessive transport/memory pressure from simultaneous requests.
7. Run `uvicorn app.main:app --host 0.0.0.0 --port 8000` behind that proxy; use supervised API/worker processes. With PostgreSQL, evaluate multi-worker crash recovery before scaling. Do not deploy multiple SQLite workers.
8. Add structured monitoring for queue age/failure, worker heartbeat, snapshot freshness, report storage usage, DB connection saturation and API errors. No credential/report content should enter logs.
9. Enable secure backups/retention for findings/evidence/audits and report files. Cleanup only expires generated completed-report files, not DB backups or audit data. Establish a separate policy for retained job metadata, failed-job records and orphan temporary files after crashes.
10. Complete the security checklist in SECURITY.md, run disposable PostgreSQL tests and independent isolation/penetration/load assessments. Add SSO/MFA and account lifecycle workflows before enterprise rollout.

Recommended gateway limits: request body ≤2.1 MB (aligned with configured 2 MB file cap), finite header size/read/write timeouts and explicit allowed origins/hosts. Do not expose the PostgreSQL port publicly. The frontend's CSP includes inline scripts/styles for Next.js compatibility; a production nonce-based CSP is recommended if your policy requires eliminating unsafe-inline.

## Operational notes

- Secret rotation invalidates sessions; users sign in again.
- Stop worker before planned database migrations that alter job/schema semantics.
- Imports are transactional and fingerprinted; restart resumes queued/expired-lease jobs, within retry limits.
- Workers use a 15-minute claim lease. Long-running PostgreSQL processing also holds a job row lock. Keep workloads bounded and measure this under concurrency.
- Baseline downgrade drops application tables. Never use downgrade on live data without a reviewed rollback/backup plan.
- SQLite local data is a file relative to the backend working directory. Run API/worker/provisioning from the same backend directory so they use the same file/config.
- CLI bootstrap reads an optional BOOTSTRAP_PASSWORD environment variable for controlled automation; interactive getpass is preferable. Remove the variable immediately after provisioning and never commit/log it.
