# Security model and deployment boundaries

## Default behaviour

- No external scanning, asset connectivity, threat enrichment, network integrations or fetching links from imported text.
- Synthetic fixtures only. Asset names/external IDs are labels, not network targets.
- Authentication protects every operational resource. `health`, OpenAPI and login are the intentional public routes.
- Session cookies are HttpOnly, SameSite=Lax and Secure when configured for production; raw session tokens are not stored in the database.
- Passwords are salted PBKDF2-HMAC-SHA256 (600,000 iterations). Minimum new-account password length is 12 characters. No default administrative password.
- Session-bound CSRF header required for mutations; exact allowed-origin checks reject unapproved browser mutation origins; no wildcard credentialled CORS.
- Production startup refuses the demo secret, non-HTTPS origins, insecure cookies or SQLite.
- TrustedHost middleware restricts Host headers. Explicitly configure approved hosts in deployment.

## Role matrix

| Capability | Viewer | Analyst | Manager | Admin |
|---|---|---|---|---|
| View inventory/findings/tasks/risks/history/members | Yes | Yes | Yes | Yes |
| Queue/download reports | Yes | Yes | Yes | Yes |
| Create/update assets, import findings, manage remediation | No | Yes | Yes | Yes |
| Record overrides / manage risk register / read audit | No | No | Yes | Yes |
| Add members / change roles / create sibling workspace | No | No | No | Yes |

Authenticated accounts can create a **new isolated organisation**, receiving access only to its new workspace. Existing organisations are not discoverable through that endpoint. Organisation creation is not a global administration privilege. The last administrator cannot be demoted through the API.

## Tenant isolation

- Authenticated user identity derives from a valid session, never a submitted actor ID.
- Every tenant route first checks workspace membership and role.
- Record lookups always include the workspace ID; owner and finding links are verified within it.
- Composite foreign keys additionally prohibit cross-workspace linked records in findings, remediation and the register.
- Jobs are workspace-owned and revalidate the submitting account/membership before execution.
- Report IDs do not bypass workspace checks. The private report directory is never mounted as public static content.
- Global account and session tables are not exposed by generic row endpoints.

This is application-layer isolation plus relational integrity, **not PostgreSQL row-level security**. Run the dedicated tenant-isolation evaluation before real use. A future RLS design must safely set/clear tenant context for pooled connections and worker transactions; do not claim RLS from foreign keys alone.

## Files and report safety

ASGI body limits are applied before multipart parsing; file/row/field caps, strict schemas and parser errors reject malformed inputs without echoing values. No archive or executable extraction is implemented. Files are parsed as text; MIME type alone is never trusted.

CSV formula-like strings are prefixed with an apostrophe. PDF text is XML-escaped before ReportLab processing. PDF/CSV output paths are generated from internal job UUIDs, not upload filenames. Files are written privately and atomically renamed. Host/container filesystems, database volumes and backups need encryption; the application does not implement its own at-rest cryptography. Completed report files expire after seven days by default; cleanup runs hourly while the worker is active. Job metadata and audits are retained separately.

## Secrets and logging

Set a unique high-entropy `SESSION_SECRET` using a secret manager. Rotating it invalidates existing sessions. Do not commit `.env`, account passwords, imported sensitive reports, production DB files or private report directories. Public frontend environment variables must never contain secrets.

Audit fields are curated identifiers, counts, roles and status. Review reasons are sensitive domain content in `score_reviews`, not credentials; secure that table like reports. Processing failures do not echo SQL/traceback messages that may contain imported fields. Do not enable SQL echo/debug logs or reverse-proxy body/header logging. Keep passwords and tokens out of URLs.

The included app does not offer arbitrary SQL or audit modification endpoints. Use separate migration and runtime database roles. Runtime role should have INSERT/SELECT (not UPDATE/DELETE) for `audit_logs` and `score_reviews`; migrations need additional DDL permissions. Audit is not cryptographically tamper-evident; send curated events to protected append-only retention if required.

## Before enterprise use

- Add a supported SSO/MFA solution, invitation/consent, password recovery and lifecycle management; current local provisioning is intentionally minimal.
- Add proxy-level/account-independent throttling; the application failure limiter is per email/peer pair and is not a distributed anti-abuse system. Test behaviour under concurrent failures and trusted reverse-proxy IP handling.
- Use TLS, same-site UI/API domains, secret-managed credentials, least-privilege DB access, encrypted storage, backups and tested restore.
- Restrict/disable API docs at the gateway if required by policy.
- Apply resource quotas/timeouts and worker monitoring; validate large reports and concurrent worker recovery.
- Consider PostgreSQL RLS, service-level ownership policies, change approval and independent resolution review.
- Perform dependency scanning, accessibility/UX review, penetration testing and load testing. Passing bundled tests does not prove security.
- Establish retention for jobs, report payloads/backups, audit events and sensitive remediation evidence. Backup copies outlive application file cleanup unless separately governed.

The local settings are **not safe for public exposure**. Secure cookies are false only to enable local HTTP demonstrations.
