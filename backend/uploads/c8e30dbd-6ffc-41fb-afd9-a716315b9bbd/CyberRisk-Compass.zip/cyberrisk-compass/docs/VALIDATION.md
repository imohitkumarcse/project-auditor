# Delivery validation

Executed in the Linux delivery environment using Python 3.13.14, Node.js 24.14.1 and disposable SQLite databases. No external assets were scanned or accessed.

| Check | Observed result |
|---|---|
| Backend unit/API suite | **176 passed**, zero failures |
| Deterministic risk matrix | 120 combinations matched independently calculated expected scores |
| Parser / malformed inputs | Golden CSV/JSON fields, missing/extra fields, malformed encoding/structure, byte/row limits, duplicate identities and evidence requirements passed |
| Tenant isolation / RBAC | Cross-workspace collection, nested ID, upload, mutation, owner and report denial checks passed; composite FK protection passed |
| Remediation / overrides | Evidence required, completion/reopening, preserved evidence/source data and retained review reasons passed |
| Authentication | CSRF/origin checks, session expiry/logout, password rotation/revocation, role changes and last-admin protection passed |
| Sensitive error handling | Validation and database errors do not echo tested sensitive values; failed writes roll back |
| Reporting | Findings/history/register CSV and PDF generation and private download/retention checks passed |
| Alembic provisioning | Initial migration and synthetic seeding succeeded on a fresh SQLite database |
| SQL references | PostgreSQL and SQLite DDL generated for all 14 application tables; baseline/runtime column sets matched |
| Frontend type check | TypeScript noEmit passed |
| Next.js production build | Compiled and generated static frontend successfully |
| Local Chromium acceptance | Login, seed scores, asset/factor views, task completion, re-import, findings CSV/PDF, daily-history CSV, history/audit, mobile overflow and logout passed |
| PDF readback | Source IDs, original severity, policy score and factor labels verified with text extraction |
| Dependency advisory checks | pip-audit: no known vulnerabilities found; npm audit: zero reported advisories |
| Deployment configuration | Compose and CI YAML parsed successfully |

The backend suite emitted one non-failing dependency deprecation warning: current Starlette recommends httpx2 instead of httpx for TestClient. The pinned httpx test dependency remained supported for this execution; review this before future dependency upgrades.

## Not executed here

- PostgreSQL runtime tests: no PostgreSQL service/binary was available in this environment. A disposable PostgreSQL CI job and local test commands are included.
- Docker image/Compose startup: Docker was unavailable. Manifests and image recipes are supplied but not advertised as runtime-verified here.
- Native Windows execution: commands were written for PowerShell but this delivery environment is Linux.
- Competing-worker crash recovery, enterprise-scale load, SSO/MFA, production penetration testing and an independent security audit.

These results verify the tested reference implementation, not that an organisation is secure or that the application is production-certified. Advisory databases and dependencies change over time. Re-run all checks and complete the deployment/security checklist before processing real sensitive findings.
