# Supported authorised report formats

The application imports the **Compass interchange format version 1**, not arbitrary vendor exports. Convert approved tool exports to this documented schema offline, preserving source identifiers/severity. Only `.csv` and `.json` filenames are allowed; names are used for format selection only and never as filesystem paths. Content is parsed and validated rather than trusting MIME headers.

## Record fields

| Field | Required | Type / constraint |
|---|---|---|
| asset_external_id | Yes | Existing asset ID in selected workspace; 1–120 characters |
| source | Yes | Source product/report name; 1–120 characters |
| source_id | Yes | Source-provided record ID; 1–200 characters; case-sensitive |
| source_severity | Yes | Original severity label; 1–80 characters; case preserved |
| title | Yes | Finding title; 1–300 characters |
| description | No | Text, at most 10,000 characters; default empty |
| vulnerability_id | No | Optional source-supplied identifier, at most 100 characters; missing/blank becomes null |
| exploitation_reported | No | Boolean; default false; CSV uses `true` or `false` |
| exploitation_evidence | If exploitation_reported=true | Source/user-supplied supporting text, at most 2,000 characters |

Strings are whitespace-trimmed during normalisation. No vulnerability IDs are generated or guessed, and no external lookup verifies a supplied ID. `source_id` is always required: missing IDs are a validation error rather than a generated vulnerability identifier. Internet exposure and criticality come from the selected workspace asset, never from an imported tenant ID.

Source severity can be an unknown vendor value; it is stored while `normalized_severity` becomes `unknown`, conservatively adding 30 severity points. Numeric/vendor-specific scores are not guessed into CVSS bands. Convert them to a documented label in an approved adapter if needed.

JSON must be a top-level array of objects. Unknown fields and duplicate keys are rejected. CSV must use unique exact header names and valid row widths. Use UTF-8 (an optional BOM is allowed). A provided CSV boolean column must contain `true` or `false` in every row; omit the entire optional column to use its default. Empty required fields are rejected. NUL bytes, non-UTF-8 files, malformed quoting/JSON and unsupported extensions are rejected safely.

Default limits: 2,000,000 file bytes; 5,000 records. The ASGI request cap includes limited multipart overhead; the file cap is checked again after extraction. All rows and all asset links must validate before a job is queued. No partial imports occur when validation fails. The worker also applies all rows transactionally.

## CSV example

```csv
asset_external_id,source,source_id,source_severity,title,description,vulnerability_id,exploitation_reported,exploitation_evidence
demo-web,synthetic-report,SYN-001,Critical,Synthetic configuration gap,Invented example only,,false,
```

## JSON example

```json
[
  {
    "asset_external_id": "demo-web",
    "source": "synthetic-report",
    "source_id": "SYN-001",
    "source_severity": "Critical",
    "title": "Synthetic configuration gap",
    "description": "Invented example only",
    "vulnerability_id": null,
    "exploitation_reported": false,
    "exploitation_evidence": ""
  }
]
```

Only import data you are authorised to process. Reports may contain sensitive organisational information. Queued payloads live in the database until processing/final failure; backups require encryption and access control. Uploaded originals are not retained separately. Repeated source IDs for the same source and asset update the same finding; conflicting same-identity rows within a single request are rejected.
