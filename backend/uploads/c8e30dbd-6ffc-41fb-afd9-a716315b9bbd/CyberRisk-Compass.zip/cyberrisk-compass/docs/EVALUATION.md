# Evaluation method

Use synthetic data only and disposable databases. **Tests create/drop the complete application schema** in the configured test database. Never set `TEST_DATABASE_URL` to an operational database.

## 1. Parsing correctness

- Golden fixtures: compare CSV and JSON common fields against expected records; confirm required source IDs, original severity labels and null vulnerability IDs remain intact.
- Negative cases: malformed JSON/CSV, duplicate JSON keys/CSV headers, wrong row widths, unsupported extensions, non-UTF-8/NUL input, oversized files/row counts, missing required fields, unknown fields, invalid booleans and exploitation without evidence.
- Semantic checks: unknown workspace assets reject the whole request; duplicate identities collapse only when identical and conflict when values differ.
- Retry/re-import: record count remains stable, first_seen stays stable, last_seen updates, and resolved findings reappear as open without deleting previous evidence.
- Acceptance: **100% golden expected fields match; every negative case is rejected; failed imports leave zero partial findings.**

## 2. Prioritisation consistency

Exhaustively evaluate six normalised severities × five criticality values × two exposure values × two exploitation values = **120 independent combinations**. Expected score is computed from independently declared points, not from the implementation's scoring table. Test repeat determinism, bounded output, factor sum and explanation inputs, monotonicity and priority-band boundaries (34/35, 59/60, 79/80).

- Acceptance: **100% equality**, factor contributions sum exactly to the stored score, correct band on every boundary, no unexplained factor.
- Verify seed expectations in `RISK_POLICY.md`.
- Human override: policy/source fields remain intact, effective score changes, reason is required and history remains when removed.
- These are consistency checks, **not empirical validation of risk prediction**. Calibrate the policy with authorised organisational outcomes before using it for formal decisions.

## 3. Tenant isolation

Provision separate organisations/workspaces A and B with separate users, plus a viewer in A.

- As A: every B collection/dashboard/history/audit/member/job route returns 404.
- As A: all B mutations/imports/report requests are denied.
- Submit a B finding/asset/task/job/report ID under an A path and ensure it is denied even though the A workspace is authorised.
- Attempt a B user as an A remediation/risk owner; reject it.
- Attempt a cross-tenant DB relationship; composite foreign key must reject it.
- A viewer can read/export but cannot import/edit/override/administer.
- A queued job whose submitter loses required access must fail without applying changes.
- A report must not be available through another workspace or without an authenticated session.
- Acceptance: **zero unauthorised successful reads/writes, zero cross-tenant payload bytes, and no partial side effects.**

## 4. Authentication / exports / workflow

Test login failure limits, cookie flags/expiry, missing CSRF, invalid Origin, logout, last-administrator protection, required resolution evidence, risk acceptance not closing findings, safe spreadsheet cells, PDF magic bytes and absence of job payloads/passwords in exposed audit/results.

Build the TypeScript frontend and execute the manual workflow in README. Builds and tests are separate checks: a successful build is not proof of browser behaviour.

## Commands

```powershell
# backend, using a disposable SQLite test database created automatically
..\.venv\Scripts\python.exe -m pytest -q
# frontend
npm ci
npm run typecheck
npm run build
```

For PostgreSQL, create a dedicated temporary database/user, then in the **backend** terminal:

```powershell
$env:TEST_DATABASE_URL = "postgresql+psycopg://test_user:test_password@localhost:5432/compass_test"
..\.venv\Scripts\python.exe -m pytest -q
Remove-Item Env:TEST_DATABASE_URL
```

A real deployment acceptance run should additionally evaluate competing workers, expired leases, process termination mid-import/report, PostgreSQL upgrades/rollback, secret rotation, proxy limits, large datasets and protected report-volume retention. These are not implied by SQLite test results.

## Manual reviewer checklist

1. Start UI/API/worker and provision a password you choose. Confirm health reports external_scanning=false.
2. Inspect seed scores 85/55/20/75 and average 58.75.
3. Change demo-dev criticality from 2 to 4: SYN-003 policy score becomes 30.
4. Apply a reasoned manager override, refresh, remove it and inspect review-history API.
5. Complete a task with evidence; verify open-count reduction. Re-import the identity and verify reopening with retained evidence.
6. Import malformed fixture and verify rejection with no queued job.
7. Queue CSV/PDF, download, inspect factor/source data and ensure reports are not public static assets.
8. Create isolated workspace B, use separate membership credentials, repeat cross-tenant checks.
9. Stop/restart worker: queued jobs wait and then resume. Verify there is no unapproved outbound network activity from app code.

## Validation status

See `VALIDATION.md` for checks actually performed in the delivery environment. Do not substitute planned tests for executed results.


## Optional local browser acceptance test

Use a freshly seeded synthetic workspace and leave the UI/API/worker running. The script is deliberately restricted to loopback hosts. It checks login, seeded scores, inventory, explanations, remediation, re-import, findings CSV/PDF, daily-history CSV, history/audit views, mobile overflow and logout. It modifies the synthetic remediation records.

From `frontend` in PowerShell:

```powershell
npx playwright install chromium
$env:SMOKE_EMAIL = "admin@example.test"
$securePassword = Read-Host "Synthetic demonstration password" -AsSecureString
$env:SMOKE_PASSWORD = [System.Net.NetworkCredential]::new("", $securePassword).Password
try { npm run smoke } finally { Remove-Item Env:SMOKE_PASSWORD }
```

The password goes only to the local sign-in form; it is never printed by the script. Use only a disposable synthetic account. The script expects the default seeded score total and at least one finding without a remediation task. Do not run it against operational data. Linux environments can set CHROMIUM_PATH to an existing Chromium binary. SMOKE_NO_SANDBOX=true is available only for restricted disposable CI environments that cannot launch Chromium's sandbox; do not use that setting for general browsing.

Explicit PostgreSQL test database names must end in `_test`; the suite refuses other names as an additional guard against accidental destructive test setup. This name check does not replace careful database isolation.
