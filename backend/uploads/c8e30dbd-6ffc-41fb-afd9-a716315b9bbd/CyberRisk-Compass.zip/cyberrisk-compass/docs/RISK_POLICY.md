# Transparent prioritisation policy: compass-v1

The score is a deterministic **remediation priority heuristic**, not a probability, proof of exploitation, security certification or replacement for a source's severity/CVSS score.

## Factors and weights

| Factor | Input | Points |
|---|---|---|
| Normalised source severity | Critical / High / Medium / Low / Informational / Unknown | 40 / 30 / 20 / 10 / 0 / 30 |
| Business criticality | Asset value 1–5 | `criticality × 5` (5–25) |
| Internet exposure | Asset flag true / false | 20 / 0 |
| Source-reported exploitation | Explicit supplied flag true / false | 15 / 0 |

**Policy score = sum of the four contributions; range 5–100 with valid asset criticality.** Empty/invalid severity is rejected if missing, otherwise unrecognised labels are stored and conservatively normalised to Unknown. Aliases: `info` → Informational; `moderate` → Medium. Normalisation is case-insensitive; original label case is stored separately.

Each finding stores the policy version, factor names, inputs, contribution points, maximum contribution and sum. The original source name, source identifier, source severity and optional supplied vulnerability identifier are independent fields.

## Priority bands

- P1: 80–100
- P2: 60–79
- P3: 35–59
- P4: 0–34 (0 is possible through a human override)

These bands are suggestions for triage, not mandatory remediation deadlines. The operator chooses the corrective-action deadline; no arbitrary service-level agreement is silently imposed.

## Exploitation and incomplete data

The exploitation flag is **source/user supplied**, not validated threat intelligence. Evidence text is required when true; no network enrichment occurs. False means *not reported in this record*, not proof of no exploitation. An unexposed asset flag means exposure was not reported by the asset owner; it is not a scan result. Criticality defaults to 3 for new assets unless explicitly selected. Review incomplete asset data before relying on the score.

## Overrides and resolution

Managers/admins can set an effective score 0–100 or clear an override, always with a 10–2,000 character reason. The calculated policy score remains unchanged. `score_reviews` stores each decision/removal, actor and timestamp. The effective score and priority use the override only while it is present.

Changing asset criticality/exposure or re-importing a finding recomputes the policy score and factor snapshot. Reviewer overrides are retained and should be periodically reconsidered. Creating an accepted-risk register entry does not automatically change score or finding status.

Only completing a remediation task with resolution evidence closes the finding; reopening its task or seeing the same source record again reopens it. Evidence is supplied by users; the platform does not independently verify remediation or scan systems.

## Synthetic seed expectations

| Source ID | Severity points | Criticality | Exposure | Exploitation | Expected score |
|---|---:|---:|---:|---:|---:|
| SYN-001 | 40 | 25 | 20 | 0 | 85 (P1) |
| SYN-002 | 30 | 25 | 0 | 0 | 55 (P3) |
| SYN-003 | 10 | 10 | 0 | 0 | 20 (P4) |
| SYN-004 | 30 (unknown) | 25 | 20 | 0 | 75 (P2) |

Seed average is 58.75 over four open findings, with two P1/P2 findings. This is a synthetic arithmetic expectation, not a security assessment.

## Changing the policy

Change factor rules only through a reviewed, versioned policy update, add independent golden expectations, write a migration/recalculation job and document impact on outstanding overrides and historical snapshots. Do not reinterpret old aggregate snapshots as though a new policy existed at the time. This release includes only compass-v1.
