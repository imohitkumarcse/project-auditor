# Architecture and data model

## Components

```text
Browser (Next.js React TypeScript)
  | session cookie + X-CSRF-Token; credentials-enabled exact-origin CORS
  v
FastAPI API
  | membership / RBAC -> workspace-scoped services
  v
PostgreSQL (production) / SQLite (local demo)
  | jobs table: queue, lease, attempt counter, claim token
  v
Python worker -> atomic import + risk snapshots
              -> private findings/history/register CSV / PDF storage
```

No scanner, HTTP integration client, external intelligence service or discovery routine is part of this application. Package installation is a development-time dependency download, not product scanning.

## Logical schema

| Table | Purpose / important invariants |
|---|---|
| users | Global account, unique lowercase email, PBKDF2 hash; no plaintext passwords |
| organisations | Organisation label |
| workspaces | Organisation association; workspace is the permission boundary |
| memberships | Unique workspace + user pair, constrained role |
| auth_sessions | HMAC-hashed session/CSRF values, expiry, account reference |
| login_throttles | HMAC-keyed email + peer-address failure window |
| assets | Workspace + external ID unique, 1–5 criticality, exposure and owner |
| findings | Source name/identifier/severity, optional supplied vulnerability ID, fingerprint, policy score, factors, override and observation timestamps |
| tasks | One corrective action per finding, deadline, member owner, status, evidence |
| risk_register | Treatment, rationale, review date, optional finding/member links |
| score_reviews | Append-only through API; override/removal reason, actor and time |
| audit_logs | Curated administrative events; no passwords/tokens/raw upload bodies |
| jobs | Durable import/report request, actor/workspace, retries, lease and result |
| risk_snapshots | One aggregate snapshot per workspace / UTC day |

Tenant-owned relationships use composite foreign keys where useful, including finding-to-asset and task/risk-to-finding and owner-to-membership. This prevents mixing tenant-linked records even if a service attempts an invalid insert. SQL queries and API access checks remain necessary; foreign keys do not themselves prevent unauthorised reads.

`schema-postgresql.sql` and `schema-sqlite.sql` are generated DDL references. Use `alembic upgrade head` to initialise databases. The initial Alembic revision uses a frozen model copy. Do not edit the baseline for future upgrades: add explicit versioned migrations.

## Request lifecycle

1. Bound body size before multipart parsing; allow only exact configured origins for browser mutations.
2. Authenticate session and active account; require session-bound CSRF token for mutations.
3. Resolve workspace membership from the authenticated user, not request-supplied identity.
4. Check the required role and query resources using workspace **and** record identifier.
5. Validate owner/finding/asset links within that workspace.
6. Apply the transaction, curate audit fields and commit. Failed transactions are rolled back on session close.

A member of no workspace receives 404 when addressing it. An authorised workspace viewer receives 403 for disallowed mutations. This avoids exposing another tenant's existence through those resource routes.

## Import lifecycle

- Parse documented UTF-8 CSV or JSON; reject unknown fields, malformed structures, duplicates with conflicting values, invalid booleans, excessive rows/bytes and assertions of exploitation without evidence.
- Require existing workspace assets. Validate the entire request before storing a job.
- Worker rechecks the submitting account and current membership, then applies the import in one transaction.
- Dedupe by SHA-256 of `[source, source_id, internal asset ID]`. Source/record IDs are case-sensitive; whitespace around IDs is normalised. Titles do not define identity. Workspace + fingerprint is unique.
- Exact duplicates within one file collapse. Updates preserve `first_seen`, update `last_seen`, preserve reviewer overrides and rescore policy factors.
- A resolved finding seen again is reopened. Existing remediation evidence is retained, and its task becomes `in_progress`.
- Payloads are cleared on success, final failure or revoked permission. Import errors exposed to clients do not echo report content.

## Queue semantics

A database-backed queue meets the task-queue requirement without additional infrastructure. API commits queued jobs; a separate worker uses an atomic conditional update to claim eligible jobs with a 15-minute lease. Completion uses a claim token and a PostgreSQL row lock. At most three processing attempts are allowed. Atomic import transactions and unique identities make retries idempotent at the finding-identity level. Successful exports are atomically renamed to job-derived private paths.

Use **one worker and one API process with SQLite**. PostgreSQL permits multiple workers; validate crash-recovery and competing-worker behaviour under your deployment workload before enabling that topology. A worker crash leaves the lease to expire. It does not promise exactly-once external side effects; no external side effects are implemented.

Hourly maintenance updates the current UTC daily aggregate and removes expired completed report files. It does not fabricate past days or delete audit history. A snapshot changes throughout its current day; past days remain unchanged. Missing days mean the worker/collection did not record them.

## Approved integration extension

`app/integrations.py` declares an offline normalisation protocol. An approved adapter should accept a user-supplied authorised report and return `ImportRow` values. Route it through the same validation and queue services. Keep the tenant identity server-derived. A future network connector requires explicit approval, allowlisted destinations, a secret manager, read-only credentials, scoped authorisation, content limits, adapter tests and an audit trail. **None are enabled automatically.**

## Audit semantics

Administrative writes, imports, task transitions, overrides and report generation/downloads produce curated events with actor, target, time and counts/roles/status. Review reasons live in `score_reviews`; old reasons remain available at the review-history API even after clearing/replacing an override. Audit entries are append-only through the API, but not cryptographically tamper-evident. Database administrators can modify them unless deployed permissions/external log retention prevent it.
