# API and integration contract

The generated `openapi.json` describes routes and input schemas. This document supplements it with session/CSRF behaviour and output conventions. There are no enabled network-security-tool connectors. All imported tenant context is derived from the authenticated API route and membership, not an upstream report.

## Authentication

1. `POST /auth/login` with `{ "email": "...", "password": "..." }`.
2. A successful response sets the HttpOnly `compass_session` cookie and returns `{ "user": { "id": "...", "email": "..." }, "csrf_token": "..." }`.
3. Retain the cookie and send `X-CSRF-Token` on every POST/PATCH, including logout and password changes. Never put either token in a URL or log.
4. `GET /auth/me` returns the current user and session-bound CSRF token for frontend reloads. CSRF token remains valid across browser tabs in the same session.
5. `POST /auth/logout` revokes that session. `POST /auth/password` requires current_password/new_password and revokes **all** sessions for that account after a successful change.

Browser mutations require an exact allowed Origin. Non-browser API clients still need authentication and CSRF headers. Sessions expire after eight hours by default. Integrators should use approved credentials provisioned by an administrator; API keys, bearer-token automation and SSO are not implemented in this release.

## Operational routes

| Route | Method | Purpose |
|---|---|---|
| /health | GET | Public operational health; reports external_scanning=false |
| /workspaces | GET | Only workspaces the account belongs to |
| /organisations | POST | New isolated organisation and its first workspace |
| /workspaces/{workspace_id}/siblings | POST | New workspace within that organisation, admin only |
| /workspaces/{workspace_id}/members | GET / POST | Read members / admin provisioning |
| /workspaces/{workspace_id}/members/{membership_id} | PATCH | Admin role change; last-admin protection |
| /workspaces/{workspace_id}/assets | GET / POST | Inventory / creation |
| /workspaces/{workspace_id}/assets/{asset_id} | PATCH | Update ownership/criticality/exposure; rescore linked findings |
| /workspaces/{workspace_id}/imports | POST multipart | Validate file and queue an atomic import |
| /workspaces/{workspace_id}/findings | GET | Descending effective-score ordering, then ID |
| /workspaces/{workspace_id}/findings/{finding_id} | GET | Source fields, policy/effective score, factors and status |
| /workspaces/{workspace_id}/findings/{finding_id}/override | PATCH | Manager/admin review score or removal, with reason |
| /workspaces/{workspace_id}/findings/{finding_id}/reviews | GET | Retained review decisions, actors, reasons and times |
| /workspaces/{workspace_id}/tasks | GET / POST | Corrective actions |
| /workspaces/{workspace_id}/tasks/{task_id} | PATCH | Owner/deadline/status/evidence update |
| /workspaces/{workspace_id}/risks | GET / POST | Register listing / manager-approved treatment |
| /workspaces/{workspace_id}/risks/{risk_id} | PATCH | Manager/admin treatment update |
| /workspaces/{workspace_id}/dashboard | GET | Current executive aggregates |
| /workspaces/{workspace_id}/history | GET | Latest 366 recorded daily snapshots, ascending date |
| /workspaces/{workspace_id}/audit | GET | Latest events first; manager/admin only |
| /workspaces/{workspace_id}/reports | POST | Queue CSV/PDF for selected dataset |
| /workspaces/{workspace_id}/jobs | GET | Workspace jobs; no queued payload contents |
| /workspaces/{workspace_id}/jobs/{job_id} | GET | Job status/result |
| /workspaces/{workspace_id}/reports/{job_id}/download | GET | Authenticated download or expired/unavailable response |

Paginated collections accept `limit` (1–500; default 100) and `offset` (nonnegative). Inventory, findings, tasks, risks, audit and jobs return arrays. Members and review history are unpaginated in this reference implementation. Empty collections return `[]`, not a fabricated result. IDs are internal UUID strings; the optional vulnerability_id remains independent of those IDs.

Datetime values are stored/returned as UTC; current database timestamps are timezone-naive ISO strings whose documented interpretation is UTC. Date-only deadlines/review dates use `YYYY-MM-DD`.

## Queue responses

Uploads use the multipart field `file`. Import formats and validation are defined in IMPORT_FORMAT.md. Successful import requests return HTTP 202 and `{ "id": "job-uuid", "status": "queued" }`. Poll the job status endpoint. Statuses: queued, running, succeeded, failed. Import success reports `created`, `updated`, `duplicates_in_file`. A worker is mandatory for queued requests.

Reports accept:

```json
{ "format": "csv", "dataset": "history" }
```

`format` is csv or pdf; `dataset` is findings (default), history or risks. A successful job exposes dataset, format, download_ready and either finding_count or record_count. Downloads re-check workspace membership. Report file retention is seven days by default; GET returns 410 when a previously generated file has expired. Reports reflect database state at execution time, not necessarily the moment the job was queued. Historical exports include only stored daily snapshots.

## Errors

- 401: session/login invalid or expired.
- 403: insufficient role, missing/invalid CSRF or unapproved browser origin.
- 404: inaccessible workspace or a record not found in the authorised workspace.
- 409: uniqueness conflict / protected last-admin change.
- 413: request-body limit exceeded.
- 422: validation failure, invalid file/link/evidence; values are not echoed.
- 429: login failure window exceeded.
- 503: database operation unavailable; sensitive SQL parameters are not echoed.

## Minimal local Python example

Use only an authorised, synthetic demonstration account for this example. It does not scan assets or discover endpoints.

```python
import getpass
import httpx

with httpx.Client(base_url="http://localhost:8000", timeout=30) as client:
    result = client.post("/auth/login", json={
        "email": "admin@example.test",
        "password": getpass.getpass("Synthetic demo password: "),
    })
    result.raise_for_status()
    client.headers["X-CSRF-Token"] = result.json()["csrf_token"]
    response = client.get("/workspaces")
    response.raise_for_status()
    workspace_id = response.json()[0]["id"]
    job = client.post(f"/workspaces/{workspace_id}/reports", json={
        "format": "csv", "dataset": "findings",
    })
    job.raise_for_status()
    # Poll this authorised workspace's job endpoint; never print session tokens.
    print("Report job queued:", job.json()["id"])
```

Future adapters must produce ImportRow values, preserve original source identifiers/severity, avoid guessed vulnerability identifiers/threat intelligence, and pass the same validation, tenant checks and audit/queue pipeline.
