/**
 * Local browser acceptance check using a synthetic seeded workspace only.
 * Start API, UI and worker first. No external targets are allowed.
 */
import { chromium } from "playwright";
import { readFile, mkdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import assert from "node:assert/strict";

const base = process.env.SMOKE_BASE_URL || "http://localhost:3000";
assert(
  ["localhost", "127.0.0.1"].includes(new URL(base).hostname),
  "The smoke test is restricted to loopback hosts.",
);
const credentials = process.env.SMOKE_CREDENTIALS_FILE
  ? JSON.parse(await readFile(process.env.SMOKE_CREDENTIALS_FILE, "utf8"))
  : { email: process.env.SMOKE_EMAIL, password: process.env.SMOKE_PASSWORD };
assert(
  credentials.email && credentials.password,
  "Provide synthetic SMOKE_EMAIL/SMOKE_PASSWORD or a local credentials file.",
);
const browser = await chromium.launch({
  headless: true,
  executablePath: process.env.CHROMIUM_PATH || undefined,
  args: process.env.SMOKE_NO_SANDBOX === "true" ? ["--no-sandbox"] : [],
});
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
page.setDefaultTimeout(15000);
const errors = [];
page.on("pageerror", (error) => errors.push(error.message));
try {
  await page.goto(base);
  await page.getByLabel("Email", { exact: true }).fill(credentials.email);
  await page.getByLabel("Password", { exact: true }).fill(credentials.password);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await page.getByRole("heading", { name: "Overview", exact: true }).waitFor();
  await page.getByText("58.75", { exact: true }).waitFor();
  await page.getByRole("button", { name: /02\s*Assets/ }).click();
  await page.getByRole("heading", { name: "Asset inventory" }).waitFor();
  await page.getByText("demo-web", { exact: true }).waitFor();
  await page.getByRole("button", { name: /03\s*Findings/ }).click();
  await page
    .getByRole("button", { name: "Review", exact: true })
    .first()
    .click();
  await page
    .getByRole("cell", { name: "asset criticality", exact: true })
    .waitFor();
  await page.getByRole("button", { name: /04\s*Remediation/ }).click();
  await page.getByLabel(/^Finding/).selectOption({ index: 0 });
  await page.getByLabel("Deadline", { exact: true }).fill("2026-11-15");
  await page.getByRole("button", { name: "Save action", exact: true }).click();
  await page.getByText("Corrective action saved", { exact: true }).waitFor();
  await page
    .getByRole("button", { name: "Update", exact: true })
    .first()
    .click();
  await page.getByLabel(/^Status/).selectOption("done");
  await page
    .getByLabel("Resolution evidence · required for done")
    .fill("Synthetic remediation reviewed during the local acceptance test.");
  await page.getByRole("button", { name: "Save action", exact: true }).click();
  await page.getByRole("cell", { name: "done", exact: true }).waitFor();
  await page.getByRole("button", { name: /06\s*Imports & reports/ }).click();
  const fixture = fileURLToPath(
    new URL("../../fixtures/findings.json", import.meta.url),
  );
  await page.getByLabel("Report file", { exact: true }).setInputFiles(fixture);
  await page
    .getByRole("button", { name: "Validate & queue import", exact: true })
    .click();
  await page.getByText("Validated import queued", { exact: true }).waitFor();
  await page.getByText("0 created, 4 updated", { exact: true }).waitFor();
  await page.getByRole("button", { name: "CSV export", exact: true }).click();
  await page
    .getByRole("link", { name: "Download csv", exact: true })
    .first()
    .waitFor();
  const csv = await page.request.get(
    await page
      .getByRole("link", { name: "Download csv", exact: true })
      .first()
      .getAttribute("href"),
  );
  assert.equal(csv.status(), 200);
  assert(
    (await csv.text()).includes("source_severity,policy_score,effective_score"),
  );
  await page.getByRole("button", { name: "PDF export", exact: true }).click();
  await page
    .getByRole("link", { name: "Download pdf", exact: true })
    .first()
    .waitFor();
  const pdf = await page.request.get(
    await page
      .getByRole("link", { name: "Download pdf", exact: true })
      .first()
      .getAttribute("href"),
  );
  assert.equal(pdf.status(), 200);
  assert((await pdf.body()).subarray(0, 4).equals(Buffer.from("%PDF")));
  await page.getByLabel(/^Report dataset/).selectOption("history");
  await page.getByRole("button", { name: "CSV export", exact: true }).click();
  const historyReport = page
    .getByRole("row")
    .filter({ hasText: "report · history" })
    .first();
  await historyReport
    .getByRole("link", { name: "Download csv", exact: true })
    .waitFor();
  const historyCsv = await page.request.get(
    await historyReport
      .getByRole("link", { name: "Download csv", exact: true })
      .getAttribute("href"),
  );
  assert.equal(historyCsv.status(), 200);
  assert(
    (await historyCsv.text()).includes(
      "day,open_findings,high_priority,average_score",
    ),
  );
  await page.getByRole("button", { name: /07\s*History/ }).click();
  await page.getByRole("heading", { name: "Daily risk history" }).waitFor();
  await page.getByRole("button", { name: /08\s*Administration/ }).click();
  await page.getByRole("heading", { name: "Workspace membership" }).waitFor();
  await page
    .getByRole("heading", { name: "Administrative audit · latest 100 events" })
    .waitFor();
  await page.getByRole("button", { name: /01\s*Overview/ }).click();
  await page.getByText("58.75", { exact: true }).waitFor();
  if (process.env.SMOKE_SCREENSHOT) {
    await page.screenshot({
      path: process.env.SMOKE_SCREENSHOT,
      fullPage: true,
    });
  }
  await page.setViewportSize({ width: 390, height: 844 });
  assert(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth + 1,
    ),
    "Unexpected mobile page overflow",
  );
  assert.deepEqual(errors, []);
  await page.getByRole("button", { name: "Sign out", exact: true }).click();
  await page.getByRole("button", { name: "Sign in", exact: true }).waitFor();
  console.log(
    "PASS: login, seeded scores, assets, factor review, remediation, reimport, CSV/PDF, history export, audit, mobile layout and logout.",
  );
} finally {
  await browser.close();
}
