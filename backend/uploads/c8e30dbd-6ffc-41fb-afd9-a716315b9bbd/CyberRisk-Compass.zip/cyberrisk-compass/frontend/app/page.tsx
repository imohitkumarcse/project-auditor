"use client";
import { useCallback, useEffect, useState, useRef, FormEvent } from "react";
import {
  api,
  API,
  setCsrf,
  Workspace,
  Asset,
  Finding,
  Task,
  Member,
  Risk,
  Job,
  Audit,
  History,
  Dashboard,
} from "@/lib/api";
const tabs = [
  "Overview",
  "Assets",
  "Findings",
  "Remediation",
  "Risk register",
  "Imports & reports",
  "History",
  "Administration",
];
const today = () => new Date().toISOString().slice(0, 10);
function values(e: FormEvent<HTMLFormElement>) {
  e.preventDefault();
  return new FormData(e.currentTarget);
}
function text(d: FormData, k: string) {
  return String(d.get(k) || "");
}
export default function Home() {
  const [signed, setSigned] = useState(false),
    [checking, setChecking] = useState(true),
    [workspaces, setWorkspaces] = useState<Workspace[]>([]),
    [wid, setWid] = useState(""),
    [tab, setTab] = useState("Overview"),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false);
  const [assets, setAssets] = useState<Asset[]>([]),
    [findings, setFindings] = useState<Finding[]>([]),
    [tasks, setTasks] = useState<Task[]>([]),
    [members, setMembers] = useState<Member[]>([]),
    [risks, setRisks] = useState<Risk[]>([]),
    [jobs, setJobs] = useState<Job[]>([]),
    [logs, setLogs] = useState<Audit[]>([]),
    [history, setHistory] = useState<History[]>([]),
    [dash, setDash] = useState<Dashboard | null>(null);
  const [selected, setSelected] = useState<Finding | null>(null),
    [editAsset, setEditAsset] = useState<Asset | null>(null),
    [editTask, setEditTask] = useState<Task | null>(null),
    [editRisk, setEditRisk] = useState<Risk | null>(null);
  const [reportDataset, setReportDataset] = useState("findings");
  const role = workspaces.find((w) => w.id === wid)?.role,
    canWrite = ["admin", "manager", "analyst"].includes(role || ""),
    canManage = role === "admin" || role === "manager";
  const base = `/workspaces/${wid}`;
  const currentWorkspace = useRef(wid);
  currentWorkspace.current = wid;
  const loadWorkspaces = async () => {
    const ws = await api<Workspace[]>("/workspaces");
    setWorkspaces(ws);
    setWid((old) => (ws.some((w) => w.id === old) ? old : ws[0]?.id || ""));
  };
  useEffect(() => {
    api<{ csrf_token: string }>("/auth/me")
      .then(async (r) => {
        setCsrf(r.csrf_token);
        await loadWorkspaces();
        setSigned(true);
      })
      .catch(() => {})
      .finally(() => setChecking(false));
  }, []);
  // Fetch all pages for this demonstration interface; backend endpoints remain bounded.
  const all = useCallback(async <T,>(path: string): Promise<T[]> => {
    const out: T[] = [];
    for (let offset = 0; ; offset += 500) {
      const page = await api<T[]>(path + `?limit=500&offset=${offset}`);
      out.push(...page);
      if (page.length < 500) return out;
    }
  }, []);
  const refresh = useCallback(async () => {
    if (!wid) return;
    const [a, f, t, m, r, j, h, d, l] = await Promise.all([
      all<Asset>(base + "/assets"),
      all<Finding>(base + "/findings"),
      all<Task>(base + "/tasks"),
      api<Member[]>(base + "/members"),
      all<Risk>(base + "/risks"),
      all<Job>(base + "/jobs"),
      api<History[]>(base + "/history"),
      api<Dashboard>(base + "/dashboard"),
      canManage
        ? api<Audit[]>(base + "/audit")
        : Promise.resolve([] as Audit[]),
    ]);
    if (currentWorkspace.current !== wid) return;
    setAssets(a);
    setFindings(f);
    setTasks(t);
    setMembers(m);
    setRisks(r);
    setJobs(j);
    setHistory(h);
    setDash(d);
    setLogs(l);
  }, [wid, base, canManage, all]);
  useEffect(() => {
    setSelected(null);
    setEditAsset(null);
    setEditTask(null);
    setEditRisk(null);
    setAssets([]);
    setFindings([]);
    setTasks([]);
    setRisks([]);
    setJobs([]);
    setHistory([]);
    setLogs([]);
    setDash(null);
    refresh().catch((e) => setError(e.message));
  }, [refresh]);
  useEffect(() => {
    if (!jobs.some((j) => j.status === "queued" || j.status === "running"))
      return;
    const timer = setInterval(
      () => refresh().catch((e) => setError(e.message)),
      2500,
    );
    return () => clearInterval(timer);
  }, [jobs, refresh]);
  async function act(fn: () => Promise<unknown>, message: string) {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await fn();
      await refresh();
      setNotice(message);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Request failed");
    } finally {
      setBusy(false);
    }
  }
  if (checking)
    return (
      <main className="login">
        <h1>CyberRisk Compass</h1>
        <p>Checking your session…</p>
      </main>
    );
  if (!signed)
    return (
      <main className="login">
        <div className="brandmark">
          C<span>↗</span>
        </div>
        <p className="eyebrow">DEFENSIVE SECURITY OPERATIONS</p>
        <h1>CyberRisk Compass</h1>
        <p>
          Know what matters.
          <br />
          Make remediation accountable.
        </p>
        <form
          onSubmit={async (e) => {
            const d = values(e);
            setBusy(true);
            setError("");
            try {
              const r = await api<{ csrf_token: string }>(
                "/auth/login",
                "POST",
                { email: text(d, "email"), password: text(d, "password") },
              );
              setCsrf(r.csrf_token);
              await loadWorkspaces();
              setSigned(true);
            } catch (e) {
              setError((e as Error).message);
            } finally {
              setBusy(false);
            }
          }}
        >
          <label>
            Email
            <input name="email" type="email" autoComplete="username" required />
          </label>
          <label>
            Password
            <input
              name="password"
              type="password"
              autoComplete="current-password"
              required
            />
          </label>
          <button disabled={busy}>Sign in</button>
        </form>
        {error && (
          <p role="alert" className="error">
            {error}
          </p>
        )}
        {notice && (
          <p role="status" className="notice">
            {notice}
          </p>
        )}
        <small>
          Use an offline-provisioned account. Demo data is synthetic; no
          scanning is performed.
        </small>
      </main>
    );
  return (
    <div className="shell">
      <aside>
        <div className="brand">
          <div className="brandmark">
            C<span>↗</span>
          </div>
          <strong>
            CyberRisk
            <br />
            Compass
          </strong>
        </div>
        <p className="eyebrow">WORKSPACE</p>
        <select
          aria-label="Workspace"
          value={wid}
          onChange={(e) => setWid(e.target.value)}
        >
          {workspaces.map((w) => (
            <option key={w.id} value={w.id}>
              {w.name}
            </option>
          ))}
        </select>
        <p className="role">
          {workspaces.find((w) => w.id === wid)?.organisation_name} · {role}
        </p>
        <nav>
          {tabs.map((t, i) => (
            <button
              key={t}
              className={tab === t ? "active" : ""}
              onClick={() => setTab(t)}
            >
              <span>{String(i + 1).padStart(2, "0")}</span>
              {t}
            </button>
          ))}
        </nav>
        <div className="aside-note">
          Authorised findings only.
          <br />
          No active scanning.
        </div>
        <button
          onClick={() =>
            act(async () => {
              await api("/auth/logout", "POST");
              setSigned(false);
              setWorkspaces([]);
              setWid("");
              setCsrf("");
            }, "Signed out")
          }
        >
          Sign out
        </button>
      </aside>
      <main>
        <header>
          <div>
            <p className="eyebrow">DEFENSIVE RISK MANAGEMENT</p>
            <h1>{tab}</h1>
          </div>
          <button
            className="secondary"
            disabled={busy}
            onClick={() => act(refresh, "Workspace refreshed")}
          >
            Refresh
          </button>
        </header>
        <div className="warning">
          Priority guides remediation. A low score is never proof that a system
          is secure.
        </div>
        {error && (
          <div className="error" role="alert">
            {error}
          </div>
        )}
        {notice && (
          <div className="notice" role="status">
            {notice}
          </div>
        )}
        {tab === "Overview" && (
          <>
            <div className="metrics">
              {[
                ["Assets", dash?.assets],
                ["Open findings", dash?.open_findings],
                ["High priority · P1/P2", dash?.high_priority],
                ["Overdue tasks", dash?.overdue_tasks],
              ].map(([label, value]) => (
                <section key={String(label)}>
                  <small>{label}</small>
                  <strong>{value ?? "—"}</strong>
                </section>
              ))}
            </div>
            <div className="grid">
              <section>
                <h2>Priority distribution</h2>
                <p>Open findings, using effective scores.</p>
                <table>
                  <thead>
                    <tr>
                      <th>Priority</th>
                      <th>Score range</th>
                      <th>Findings</th>
                    </tr>
                  </thead>
                  <tbody>
                    {["P1", "P2", "P3", "P4"].map((p, i) => (
                      <tr key={p}>
                        <td>
                          <span className={`badge ${p}`}>{p}</span>
                        </td>
                        <td>{["80–100", "60–79", "35–59", "0–34"][i]}</td>
                        <td>{dash?.priority_counts[p] ?? 0}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </section>
              <section>
                <h2>Transparent by design</h2>
                <p>
                  Source severity is preserved. Policy severity, business
                  criticality, internet exposure and source-reported
                  exploitation contribute to a 0–100 prioritisation score.
                </p>
                <p>
                  Managers can record reasoned overrides. Every finding exposes
                  the policy version and factor inputs.
                </p>
                <div className="subtle">
                  Average open priority score{" "}
                  <strong>{dash?.average_score ?? "—"}</strong>
                </div>
              </section>
            </div>
            <section>
              <h2>Next actions</h2>
              {findings
                .filter((f) => f.status === "open")
                .slice(0, 5)
                .map((f) => (
                  <button
                    className="finding-row"
                    key={f.id}
                    onClick={() => {
                      setSelected(f);
                      setTab("Findings");
                    }}
                  >
                    <span className={`badge ${f.priority}`}>{f.priority}</span>
                    <span>
                      {f.title}
                      <small>
                        {f.source} · {f.source_id}
                      </small>
                    </span>
                    <strong>{f.effective_score}</strong>
                  </button>
                ))}
            </section>
          </>
        )}
        {tab === "Assets" && (
          <>
            <section>
              <h2>{editAsset ? "Update asset" : "Add an asset"}</h2>
              {canWrite ? (
                <form
                  key={editAsset?.id || "new"}
                  className="form-grid"
                  onSubmit={(e) => {
                    const d = values(e);
                    const body = {
                      name: text(d, "name"),
                      owner: text(d, "owner"),
                      criticality: Number(d.get("criticality")),
                      internet_exposed: d.get("internet_exposed") === "on",
                    };
                    act(async () => {
                      await api(
                        base +
                          "/assets" +
                          (editAsset ? "/" + editAsset.id : ""),
                        editAsset ? "PATCH" : "POST",
                        editAsset
                          ? body
                          : { ...body, external_id: text(d, "external_id") },
                      );
                      setEditAsset(null);
                    }, "Asset saved; linked findings rescored");
                  }}
                >
                  {!editAsset && (
                    <label>
                      External asset ID
                      <input name="external_id" maxLength={120} required />
                    </label>
                  )}
                  <label>
                    Name
                    <input
                      name="name"
                      defaultValue={editAsset?.name}
                      maxLength={200}
                      required
                    />
                  </label>
                  <label>
                    Business owner
                    <input
                      name="owner"
                      defaultValue={editAsset?.owner || "Unassigned"}
                      maxLength={200}
                    />
                  </label>
                  <label>
                    Criticality · 1–5
                    <select
                      name="criticality"
                      defaultValue={editAsset?.criticality || 3}
                    >
                      {[1, 2, 3, 4, 5].map((n) => (
                        <option key={n}>{n}</option>
                      ))}
                    </select>
                  </label>
                  <label className="checkbox">
                    <input
                      name="internet_exposed"
                      type="checkbox"
                      defaultChecked={editAsset?.internet_exposed}
                    />
                    Internet-exposed
                  </label>
                  <button disabled={busy}>Save asset</button>
                  {editAsset && (
                    <button
                      type="button"
                      className="secondary"
                      onClick={() => setEditAsset(null)}
                    >
                      Cancel edit
                    </button>
                  )}
                </form>
              ) : (
                <p>Viewer access: read only.</p>
              )}
            </section>
            <section>
              <h2>Asset inventory</h2>
              <table>
                <thead>
                  <tr>
                    <th>Asset / external ID</th>
                    <th>Owner</th>
                    <th>Criticality</th>
                    <th>Exposure</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {assets.map((a) => (
                    <tr key={a.id}>
                      <td>
                        {a.name}
                        <small>{a.external_id}</small>
                      </td>
                      <td>{a.owner}</td>
                      <td>{a.criticality}/5</td>
                      <td>
                        {a.internet_exposed ? "Internet" : "Not reported"}
                      </td>
                      <td>
                        {canWrite && (
                          <button
                            className="secondary"
                            onClick={() => setEditAsset(a)}
                          >
                            Edit
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>
          </>
        )}
        {tab === "Findings" && (
          <>
            <section>
              <h2>Prioritised findings</h2>
              <table>
                <thead>
                  <tr>
                    <th>Finding</th>
                    <th>Source severity</th>
                    <th>Policy / effective</th>
                    <th>Status</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {findings.map((f) => (
                    <tr key={f.id}>
                      <td>
                        <span className={`badge ${f.priority}`}>
                          {f.priority}
                        </span>{" "}
                        {f.title}
                        <small>
                          {f.source} · {f.source_id} ·{" "}
                          {assets.find((a) => a.id === f.asset_id)?.name}
                        </small>
                      </td>
                      <td>
                        {f.source_severity}
                        {f.normalized_severity === "unknown" && (
                          <small>Unknown → conservative 30 points</small>
                        )}
                      </td>
                      <td>
                        {f.score} / <strong>{f.effective_score}</strong>
                      </td>
                      <td>{f.status}</td>
                      <td>
                        <button
                          className="secondary"
                          onClick={() => setSelected(f)}
                        >
                          Review
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>
            {selected && (
              <section>
                <h2>{selected.title}</h2>
                <p>{selected.description}</p>
                <p>
                  Policy <code>{selected.factors.policy}</code> · source
                  severity <b>{selected.source_severity}</b>
                </p>
                <table>
                  <thead>
                    <tr>
                      <th>Factor</th>
                      <th>Input</th>
                      <th>Points</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selected.factors.factors.map((f) => (
                      <tr key={f.factor}>
                        <td>{f.factor.replaceAll("_", " ")}</td>
                        <td>{String(f.input)}</td>
                        <td>
                          {f.points} / {f.max}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {selected.override_reason && (
                  <p>Review reason: {selected.override_reason}</p>
                )}
                {canManage && (
                  <form
                    className="form-grid"
                    onSubmit={(e) => {
                      const d = values(e);
                      act(async () => {
                        const f = await api<Finding>(
                          base + "/findings/" + selected.id + "/override",
                          "PATCH",
                          {
                            score:
                              text(d, "score") === ""
                                ? null
                                : Number(d.get("score")),
                            reason: text(d, "reason"),
                          },
                        );
                        setSelected(f);
                      }, "Review override recorded");
                    }}
                  >
                    <label>
                      Override score · blank removes override
                      <input name="score" type="number" min={0} max={100} />
                    </label>
                    <label>
                      Recorded reason
                      <input
                        name="reason"
                        minLength={10}
                        maxLength={2000}
                        required
                      />
                    </label>
                    <button disabled={busy}>Record review</button>
                  </form>
                )}
              </section>
            )}
          </>
        )}
        {tab === "Remediation" && (
          <>
            <section>
              <h2>
                {editTask
                  ? "Update corrective action"
                  : "Create corrective action"}
              </h2>
              {canWrite && (
                <form
                  key={editTask?.id || "new"}
                  className="form-grid"
                  onSubmit={(e) => {
                    const d = values(e);
                    const body = {
                      owner_user_id: text(d, "owner") || null,
                      deadline: text(d, "deadline"),
                    };
                    act(async () => {
                      await api(
                        base + "/tasks" + (editTask ? "/" + editTask.id : ""),
                        editTask ? "PATCH" : "POST",
                        editTask
                          ? {
                              ...body,
                              status: text(d, "status"),
                              evidence: text(d, "evidence"),
                            }
                          : { ...body, finding_id: text(d, "finding") },
                      );
                      setEditTask(null);
                    }, "Corrective action saved");
                  }}
                >
                  {!editTask && (
                    <label>
                      Finding
                      <select name="finding" required>
                        {findings
                          .filter(
                            (f) => !tasks.some((t) => t.finding_id === f.id),
                          )
                          .map((f) => (
                            <option key={f.id} value={f.id}>
                              {f.title}
                            </option>
                          ))}
                      </select>
                    </label>
                  )}
                  <label>
                    Owner
                    <select
                      name="owner"
                      defaultValue={editTask?.owner_user_id || ""}
                    >
                      <option value="">Unassigned</option>
                      {members.map((m) => (
                        <option key={m.id} value={m.user_id}>
                          {m.email}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Deadline
                    <input
                      name="deadline"
                      type="date"
                      defaultValue={editTask?.deadline || today()}
                      required
                    />
                  </label>
                  {editTask && (
                    <>
                      <label>
                        Status
                        <select name="status" defaultValue={editTask.status}>
                          {["todo", "in_progress", "blocked", "done"].map(
                            (s) => (
                              <option key={s}>{s}</option>
                            ),
                          )}
                        </select>
                      </label>
                      <label>
                        Resolution evidence · required for done
                        <textarea
                          name="evidence"
                          maxLength={10000}
                          defaultValue={editTask.evidence}
                        />
                      </label>
                    </>
                  )}
                  <button disabled={busy}>Save action</button>
                  {editTask && (
                    <button
                      type="button"
                      className="secondary"
                      onClick={() => setEditTask(null)}
                    >
                      Cancel
                    </button>
                  )}
                </form>
              )}
            </section>
            <section>
              <h2>Remediation queue</h2>
              <table>
                <thead>
                  <tr>
                    <th>Finding</th>
                    <th>Owner</th>
                    <th>Deadline</th>
                    <th>Status</th>
                    <th>Evidence</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {tasks.map((t) => (
                    <tr key={t.id}>
                      <td>
                        {findings.find((f) => f.id === t.finding_id)?.title}
                      </td>
                      <td>
                        {members.find((m) => m.user_id === t.owner_user_id)
                          ?.email || "Unassigned"}
                      </td>
                      <td
                        className={
                          t.deadline < today() && t.status !== "done"
                            ? "late"
                            : ""
                        }
                      >
                        {t.deadline}
                      </td>
                      <td>{t.status}</td>
                      <td className="evidence">{t.evidence || "—"}</td>
                      <td>
                        {canWrite && (
                          <button
                            className="secondary"
                            onClick={() => setEditTask(t)}
                          >
                            Update
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>
          </>
        )}
        {tab === "Risk register" && (
          <>
            <section>
              <h2>
                {editRisk ? "Update risk treatment" : "Record a risk treatment"}
              </h2>
              {canManage && (
                <form
                  key={editRisk?.id || "new"}
                  className="form-grid"
                  onSubmit={(e) => {
                    const d = values(e);
                    act(async () => {
                      await api(
                        base + "/risks" + (editRisk ? "/" + editRisk.id : ""),
                        editRisk ? "PATCH" : "POST",
                        {
                          title: text(d, "title"),
                          owner_user_id: text(d, "owner") || null,
                          finding_id: text(d, "finding") || null,
                          treatment: text(d, "treatment"),
                          rationale: text(d, "rationale"),
                          review_date: text(d, "review_date"),
                        },
                      );
                      setEditRisk(null);
                    }, "Risk treatment recorded");
                  }}
                >
                  <label>
                    Risk title
                    <input
                      name="title"
                      defaultValue={editRisk?.title}
                      maxLength={300}
                      required
                    />
                  </label>
                  <label>
                    Linked finding
                    <select
                      name="finding"
                      defaultValue={editRisk?.finding_id || ""}
                    >
                      <option value="">None</option>
                      {findings.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.title}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Accountable owner
                    <select
                      name="owner"
                      defaultValue={editRisk?.owner_user_id || ""}
                    >
                      <option value="">Unassigned</option>
                      {members.map((m) => (
                        <option key={m.id} value={m.user_id}>
                          {m.email}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Treatment
                    <select
                      name="treatment"
                      defaultValue={editRisk?.treatment || "mitigate"}
                    >
                      {["mitigate", "accept", "avoid", "transfer"].map((s) => (
                        <option key={s}>{s}</option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Review date
                    <input
                      name="review_date"
                      type="date"
                      defaultValue={editRisk?.review_date || today()}
                      required
                    />
                  </label>
                  <label>
                    Decision rationale
                    <textarea
                      name="rationale"
                      defaultValue={editRisk?.rationale}
                      minLength={10}
                      maxLength={5000}
                      required
                    />
                  </label>
                  <button disabled={busy}>Save treatment</button>
                  {editRisk && (
                    <button
                      className="secondary"
                      type="button"
                      onClick={() => setEditRisk(null)}
                    >
                      Cancel
                    </button>
                  )}
                </form>
              )}
              <p>
                Acceptance is a management decision, not proof of remediation.
                It does not close linked findings.
              </p>
            </section>
            <section>
              <h2>Risk register</h2>
              <table>
                <thead>
                  <tr>
                    <th>Risk</th>
                    <th>Treatment</th>
                    <th>Owner</th>
                    <th>Review date</th>
                    <th>Rationale</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {risks.map((r) => (
                    <tr key={r.id}>
                      <td>{r.title}</td>
                      <td>{r.treatment}</td>
                      <td>
                        {members.find((m) => m.user_id === r.owner_user_id)
                          ?.email || "Unassigned"}
                      </td>
                      <td>{r.review_date}</td>
                      <td>{r.rationale}</td>
                      <td>
                        {canManage && (
                          <button
                            className="secondary"
                            onClick={() => setEditRisk(r)}
                          >
                            Edit
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>
          </>
        )}
        {tab === "Imports & reports" && (
          <>
            <div className="grid">
              <section>
                <h2>Import authorised findings</h2>
                <p>
                  UTF-8 CSV or JSON · maximum 2 MB / 5,000 rows by default.
                  Assets must already exist. Use the documented Compass
                  interchange schema; vendor formats require approved adapters.
                </p>
                {canWrite && (
                  <form
                    onSubmit={(e) => {
                      const d = values(e);
                      act(
                        () => api(base + "/imports", "POST", d),
                        "Validated import queued",
                      );
                    }}
                  >
                    <label>
                      Report file
                      <input
                        name="file"
                        type="file"
                        accept=".csv,.json"
                        required
                      />
                    </label>
                    <button disabled={busy}>Validate & queue import</button>
                  </form>
                )}
              </section>
              <section>
                <h2>Export workspace report</h2>
                <p>
                  Exports preserve source identifiers and show policy and
                  effective scores. Downloads require an authenticated workspace
                  session and expire after retention.
                </p>
                <label>
                  Report dataset
                  <select
                    value={reportDataset}
                    onChange={(e) => setReportDataset(e.target.value)}
                  >
                    <option value="findings">
                      Findings and score explanations
                    </option>
                    <option value="history">Daily risk history</option>
                    <option value="risks">Risk register</option>
                  </select>
                </label>
                <div className="actions">
                  {["csv", "pdf"].map((format) => (
                    <button
                      key={format}
                      disabled={busy}
                      onClick={() =>
                        act(
                          () =>
                            api(base + "/reports", "POST", {
                              format,
                              dataset: reportDataset,
                            }),
                          format.toUpperCase() + " report queued",
                        )
                      }
                    >
                      {format.toUpperCase()} export
                    </button>
                  ))}
                </div>
              </section>
            </div>
            <section>
              <h2>Background jobs</h2>
              <table>
                <thead>
                  <tr>
                    <th>Job</th>
                    <th>Status</th>
                    <th>Outcome</th>
                    <th>Download</th>
                  </tr>
                </thead>
                <tbody>
                  {jobs.map((j) => (
                    <tr key={j.id}>
                      <td>
                        {j.kind}
                        {j.result.dataset && ` · ${j.result.dataset}`}
                        <small>{j.id}</small>
                      </td>
                      <td>{j.status}</td>
                      <td>
                        {j.result.error ||
                          (j.kind === "import" && j.status === "succeeded"
                            ? `${j.result.created} created, ${j.result.updated} updated`
                            : "—")}
                      </td>
                      <td>
                        {j.kind === "report" && j.status === "succeeded" && (
                          <a href={`${API}${base}/reports/${j.id}/download`}>
                            Download {j.result.format}
                          </a>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>
          </>
        )}
        {tab === "History" && (
          <section>
            <h2>Daily risk history</h2>
            <p>
              UTC daily snapshots are updated on import, rescoring and task
              changes, plus hourly worker maintenance. No historical values are
              fabricated or backfilled.
            </p>
            <table>
              <thead>
                <tr>
                  <th>Date · UTC</th>
                  <th>Open findings</th>
                  <th>P1 / P2 findings</th>
                  <th>Average effective score</th>
                </tr>
              </thead>
              <tbody>
                {history.map((h) => (
                  <tr key={h.id}>
                    <td>{h.day}</td>
                    <td>{h.open_findings}</td>
                    <td>{h.high_priority}</td>
                    <td>{h.average_score}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!history.length && (
              <p>
                No recorded history yet. Start the worker or import synthetic
                fixtures.
              </p>
            )}
          </section>
        )}
        {tab === "Administration" && (
          <>
            <section>
              <h2>Change your password</h2>
              <p>
                Changing your password ends all account sessions. Sign in again
                with the new password.
              </p>
              <form
                className="form-grid"
                onSubmit={async (e) => {
                  const d = values(e);
                  setBusy(true);
                  setError("");
                  try {
                    await api("/auth/password", "POST", {
                      current_password: text(d, "current_password"),
                      new_password: text(d, "new_password"),
                    });
                    setSigned(false);
                    setWorkspaces([]);
                    setWid("");
                    setCsrf("");
                    setNotice("Password changed; sign in again.");
                  } catch (e) {
                    setError((e as Error).message);
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                <label>
                  Current password
                  <input
                    name="current_password"
                    type="password"
                    autoComplete="current-password"
                    required
                  />
                </label>
                <label>
                  New password
                  <input
                    name="new_password"
                    type="password"
                    autoComplete="new-password"
                    minLength={12}
                    maxLength={256}
                    required
                  />
                </label>
                <button disabled={busy}>Change password</button>
              </form>
            </section>
            <section>
              <h2>Workspace membership</h2>
              <table>
                <thead>
                  <tr>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Change role</th>
                  </tr>
                </thead>
                <tbody>
                  {members.map((m) => (
                    <tr key={m.id}>
                      <td>{m.email}</td>
                      <td>{m.role}</td>
                      <td>
                        {role === "admin" && (
                          <select
                            aria-label={`Role for ${m.email}`}
                            value={m.role}
                            disabled={busy}
                            onChange={(e) =>
                              act(
                                () =>
                                  api(base + "/members/" + m.id, "PATCH", {
                                    role: e.target.value,
                                  }),
                                "Role updated",
                              )
                            }
                          >
                            {["admin", "manager", "analyst", "viewer"].map(
                              (r) => (
                                <option key={r}>{r}</option>
                              ),
                            )}
                          </select>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {role === "admin" && (
                <form
                  className="form-grid"
                  onSubmit={(e) => {
                    const d = values(e);
                    act(
                      () =>
                        api(base + "/members", "POST", {
                          email: text(d, "email"),
                          role: text(d, "role"),
                          ...(text(d, "password")
                            ? { password: text(d, "password") }
                            : {}),
                        }),
                      "Member added",
                    );
                  }}
                >
                  <label>
                    Email
                    <input name="email" type="email" required />
                  </label>
                  <label>
                    Initial password · new users only
                    <input
                      name="password"
                      type="password"
                      autoComplete="new-password"
                      minLength={12}
                    />
                  </label>
                  <label>
                    Role
                    <select name="role">
                      {["viewer", "analyst", "manager", "admin"].map((r) => (
                        <option key={r}>{r}</option>
                      ))}
                    </select>
                  </label>
                  <button disabled={busy}>Add member</button>
                </form>
              )}
            </section>
            {role === "admin" && (
              <section>
                <h2>Create a workspace in this organisation</h2>
                <form
                  className="form-grid"
                  onSubmit={(e) => {
                    const d = values(e);
                    act(async () => {
                      await api(base + "/siblings", "POST", {
                        name: text(d, "name"),
                      });
                      await loadWorkspaces();
                    }, "Workspace created");
                  }}
                >
                  <label>
                    Name
                    <input name="name" maxLength={120} required />
                  </label>
                  <button disabled={busy}>Create workspace</button>
                </form>
              </section>
            )}
            <section>
              <h2>Create a separate organisation</h2>
              <p>
                Creates an isolated organisation and grants you administrator
                access only to its new workspace.
              </p>
              <form
                className="form-grid"
                onSubmit={(e) => {
                  const d = values(e);
                  act(async () => {
                    await api("/organisations", "POST", {
                      name: text(d, "name"),
                      workspace_name: text(d, "workspace_name"),
                    });
                    await loadWorkspaces();
                  }, "Organisation created");
                }}
              >
                <label>
                  Organisation name
                  <input name="name" maxLength={120} required />
                </label>
                <label>
                  First workspace name
                  <input name="workspace_name" maxLength={120} required />
                </label>
                <button disabled={busy}>Create organisation</button>
              </form>
            </section>
            {canManage && (
              <section>
                <h2>Administrative audit · latest 100 events</h2>
                <table>
                  <thead>
                    <tr>
                      <th>Time · UTC</th>
                      <th>Action</th>
                      <th>Target</th>
                      <th>Metadata</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logs.map((l) => (
                      <tr key={l.id}>
                        <td>{l.created_at.replace("T", " ")}</td>
                        <td>{l.action}</td>
                        <td>
                          <small>{l.target_id}</small>
                        </td>
                        <td>
                          <code>{JSON.stringify(l.details)}</code>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </section>
            )}
          </>
        )}
        <footer>
          CyberRisk Compass · policy compass-v1 · report management, not a
          security scanner
        </footer>
      </main>
    </div>
  );
}
