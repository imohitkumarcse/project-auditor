export const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
let csrf = "";
export function setCsrf(token: string) {
  csrf = token;
}
export async function api<T = unknown>(
  path: string,
  method = "GET",
  body?: unknown,
): Promise<T> {
  const headers: Record<string, string> = {};
  if (method !== "GET") headers["X-CSRF-Token"] = csrf;
  const isForm = body instanceof FormData;
  if (body && !isForm) headers["Content-Type"] = "application/json";
  const res = await fetch(API + path, {
    method,
    credentials: "include",
    headers,
    body: body
      ? ((isForm ? body : JSON.stringify(body)) as BodyInit)
      : undefined,
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({ detail: "Request failed" }));
    throw new Error(
      typeof error.detail === "string"
        ? error.detail
        : "Invalid input. Check required fields and allowed values.",
    );
  }
  return res.json() as Promise<T>;
}
export type Workspace = {
  id: string;
  name: string;
  role: string;
  organisation_name: string;
};
export type Asset = {
  id: string;
  external_id: string;
  name: string;
  owner: string;
  criticality: number;
  internet_exposed: boolean;
};
export type Finding = {
  id: string;
  asset_id: string;
  title: string;
  description: string;
  source: string;
  source_id: string;
  source_severity: string;
  normalized_severity: string;
  score: number;
  effective_score: number;
  priority: string;
  status: string;
  override_reason: string | null;
  factors: {
    policy: string;
    factors: {
      factor: string;
      input: string | number | boolean;
      points: number;
      max: number;
    }[];
  };
};
export type Task = {
  id: string;
  finding_id: string;
  owner_user_id: string | null;
  deadline: string;
  status: string;
  evidence: string;
};
export type Member = {
  id: string;
  user_id: string;
  email: string;
  role: string;
};
export type Risk = {
  id: string;
  title: string;
  owner_user_id: string | null;
  finding_id: string | null;
  treatment: string;
  rationale: string;
  review_date: string;
};
export type Job = {
  id: string;
  kind: string;
  status: string;
  result: {
    format?: string;
    dataset?: string;
    created?: number;
    updated?: number;
    error?: string;
  };
};
export type Audit = {
  id: string;
  created_at: string;
  action: string;
  target_id: string;
  details: Record<string, unknown>;
};
export type History = {
  id: string;
  day: string;
  open_findings: number;
  high_priority: number;
  average_score: number;
};
export type Dashboard = {
  assets: number;
  open_findings: number;
  high_priority: number;
  overdue_tasks: number;
  average_score: number;
  priority_counts: Record<string, number>;
};
