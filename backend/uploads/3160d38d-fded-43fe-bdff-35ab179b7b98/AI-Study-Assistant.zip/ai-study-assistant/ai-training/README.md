# EduLlama model workspace

This folder separates training and evaluation from the web application. **No trained EduLlama weights or claimed benchmark scores are included.** The backend never trains a model during a web request.

## Folders
- `data/raw`: educational material you have rights to use.
- `data/processed`: validated instruction/chat JSONL.
- `models`: licensed base/fine-tuned weights and exported GGUF files (not committed).
- `outputs`: real evaluation records and future training logs.
- `scripts`: dataset validation, embedding preparation and actual-response evaluation.

## Customization workflow — future work, not a completed training pipeline
1. Select a specific Llama base model and read its license, acceptable-use terms, distribution requirements, and any access conditions. Preserve required notices. Academic use does not automatically waive license requirements.
2. Collect authorized educational examples, remove personal information, separate training/validation/test sets, and have answers reviewed by subject experts. Avoid putting evaluation cases into training data.
3. Format JSONL rows as `{"messages":[{"role":"user","content":"..."},{"role":"assistant","content":"..."}]}`. Run `validate_dataset.py`.
4. Fine-tune with an appropriate LoRA/QLoRA toolchain on suitable hardware. Training dependencies and hyperparameters depend on the selected base model and are intentionally not bundled or presented as completed work.
5. Merge/export as appropriate, then convert/quantize to an Ollama-compatible GGUF. Place the real result at `models/edullama.gguf`.
6. Copy `Modelfile.example` to `Modelfile`; import with `ollama create edullama -f .\ai-training\Modelfile` from the project root. Setting a system prompt on an untrained base model is not fine-tuning.

## Reproducible evaluation
Use a separate evaluation account. Create your own factual test cases and reference answers; `docs/evaluation-cases.example.jsonl` contains illustrative questions, not benchmark results. Run the same cases with the backend configured first for a licensed base model and then for the actual trained EduLlama. Restart FastAPI between configurations; the browser cannot change inference endpoints or models arbitrarily.

Run direct and RAG evaluations separately. RAG cases require the ID of an uploaded, indexed PDF owned by the evaluation account. The runner appends actual HTTP results, model metadata, measured wall latency, provider token/time metrics when returned, and null human-review fields. Fill correctness/relevance/grounding only after reviewing the evidence. Ollama metrics are not RAM/VRAM measurements; OS/GPU resource instrumentation remains future work. Never relabel a base-model run as a trained-model result.

Embedding preparation downloads model weights from a model repository one time; it does not send documents for remote inference. Normal app inference uses local cached weights with `EMBEDDING_LOCAL_ONLY=true`.
