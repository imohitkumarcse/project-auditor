"""One-time download of model files. Inference remains local thereafter."""

import argparse
from sentence_transformers import SentenceTransformer

parser = argparse.ArgumentParser()
parser.add_argument("--model", default="sentence-transformers/all-MiniLM-L6-v2")
args = parser.parse_args()
model = SentenceTransformer(args.model, trust_remote_code=False)
embedding = model.encode(["Embedding setup validation."], normalize_embeddings=True)
print(f"Prepared {args.model}; local embedding shape: {embedding.shape}.")
print("Keep EMBEDDING_LOCAL_ONLY=true for normal application runs.")
