"""Validate an educational chat JSONL dataset without training any model."""

import argparse, json, hashlib
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("file", type=Path)
args = parser.parse_args()
seen = set()
valid = 0
errors = []
for line_no, line in enumerate(args.file.read_text(encoding="utf-8").splitlines(), 1):
    if not line.strip():
        continue
    try:
        row = json.loads(line)
        messages = row["messages"]
        assert isinstance(messages, list) and len(messages) >= 2, (
            "At least two messages required"
        )
        for message in messages:
            assert message["role"] in {"system", "user", "assistant"}, "Invalid role"
            assert isinstance(message["content"], str) and message["content"].strip(), (
                "Empty content"
            )
        assert any(m["role"] == "user" for m in messages), "Missing user question"
        assert messages[-1]["role"] == "assistant", (
            "Final message must be an assistant answer"
        )
        digest = hashlib.sha256(
            json.dumps(messages, sort_keys=True).encode()
        ).hexdigest()
        assert digest not in seen, "Duplicate example"
        seen.add(digest)
        valid += 1
    except (ValueError, KeyError, TypeError, AssertionError) as e:
        errors.append({"line": line_no, "error": str(e)})
print(json.dumps({"valid_examples": valid, "errors": errors}, indent=2))
raise SystemExit(1 if errors else 0)
