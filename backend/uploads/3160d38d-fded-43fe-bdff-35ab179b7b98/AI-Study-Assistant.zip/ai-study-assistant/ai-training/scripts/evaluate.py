"""Record real app responses and measured latency; does not invent correctness scores."""

import argparse, getpass, json, time
from datetime import datetime, timezone
from pathlib import Path
import httpx

parser = argparse.ArgumentParser()
parser.add_argument("--cases", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument(
    "--label",
    required=True,
    help="Accurate run label, e.g. base-llama or trained-edullama",
)
parser.add_argument("--email", required=True)
parser.add_argument("--mode", choices=["direct", "rag"], default="direct")
parser.add_argument("--backend", default="http://127.0.0.1:8000")
args = parser.parse_args()
if not args.backend.startswith(("http://127.0.0.1:", "http://localhost:")):
    parser.error("Use a loopback backend.")
args.output.parent.mkdir(parents=True, exist_ok=True)
with httpx.Client(base_url=args.backend, timeout=900, trust_env=False) as client:
    response = client.post(
        "/api/auth/login",
        json={
            "email": args.email,
            "password": getpass.getpass("Study account password: "),
        },
    )
    response.raise_for_status()
    model_status = client.get("/api/health/ai").json()
    with args.output.open("a", encoding="utf-8") as out:
        for line in args.cases.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            case = json.loads(line)
            started = time.perf_counter()
            try:
                if args.mode == "rag":
                    if not case.get("document_id"):
                        raise ValueError(
                            "RAG cases require an uploaded document_id owned by this account."
                        )
                    response = client.post(
                        f"/api/documents/{case['document_id']}/ask",
                        json={"question": case["question"]},
                    )
                else:
                    response = client.post(
                        "/api/chat",
                        json={
                            "message": case["question"],
                            "subject": case.get("subject", "General"),
                            "style": "exam",
                        },
                    )
                result = response.json()
                status = response.status_code
            except (httpx.HTTPError, ValueError) as error:
                result = {"error": str(error)}
                status = None
            record = {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "case_id": case["id"],
                "question": case["question"],
                "reference_answer": case.get("reference_answer"),
                "expected_pages": case.get("expected_pages"),
                "label": args.label,
                "mode": args.mode,
                "configured_model": model_status.get("model"),
                "http_status": status,
                "wall_latency_ms": round((time.perf_counter() - started) * 1000),
                "response": result,
                "human_correctness": None,
                "human_relevance": None,
                "human_grounding": None,
            }
            out.write(json.dumps(record, ensure_ascii=False) + "\n")
            out.flush()
            print(f"{case['id']}: HTTP {status}; {record['wall_latency_ms']} ms")
    client.post("/api/auth/logout")
