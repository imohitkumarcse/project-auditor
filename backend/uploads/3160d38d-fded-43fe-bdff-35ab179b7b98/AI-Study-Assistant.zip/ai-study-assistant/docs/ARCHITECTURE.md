# Architecture and implementation plan

## Phase 1 — Inspect
The supplied workspace was empty. No existing framework, routes, dependencies, database models, or working features were available. The user subsequently authorized a new project. No prior code was overwritten.

## Phase 2 — Plan

### Decisions
- React + TypeScript + Vite: a compact, understandable SPA for academic evaluation. React was allowed by the requested stack; Next.js is not required for this authenticated local app.
- Tailwind v4 plus a reusable CSS component system, Lucide, React Router, react-markdown/GFM. No raw model-generated HTML is executed.
- FastAPI + Pydantic + SQLAlchemy + SQLite. Initial schema creation at startup. No migrations are needed for an empty database; future schema changes require an explicit migration tool such as Alembic.
- Opaque, high-entropy sessions in HttpOnly, SameSite=Lax cookies; only SHA-256 token digests are stored. Argon2id password hashes. No browser localStorage bearer tokens.
- Loopback Ollama, configurable model name. No hosted inference integration, no fake fallback. Local embeddings use sentence-transformers; persistent Chroma indexes are isolated per document, with a user filter and SQL ownership checks before retrieval.
- Text extraction is functional without embeddings. `text_ready` is deliberately distinct from `ready` (indexed). Scans without usable text fail with an explicit OCR-unavailable error.
- Non-streaming AI in the first version. The UI never simulates streaming. Long-document summaries use map/reduce calls, not silent clipping.

### Page structure
| Route | Workflow |
|---|---|
| `/login`, `/register` | Secure sign-in and account creation |
| `/` | User-specific dashboard and today's tasks |
| `/tutor` | Conversation history, tutor messages, style/subject controls |
| `/documents` | Upload, metadata, original PDF, delete, retry indexing, grounded Q&A |
| `/summaries` | Short/detailed/sections/concepts/definitions/revision notes |
| `/quizzes` | Generate, saved quizzes, attempt, server-side scoring and review |
| `/planner` | Daily/weekly/all/revision views and CRUD |
| `/notes` | Search, subject filtering, Markdown notes, saved AI material |
| `/settings` | Profile, explanation preference, theme, backend/model status |

### Database
`users`, `sessions`, `conversations`, `messages`, `documents`, `tasks`, `notes`, `quizzes`, `quiz_attempts`.
All study resources contain `user_id`; message ownership is enforced through conversations. Foreign keys are enabled. Documents store page text and metadata in SQLite; files use generated UUID paths outside the frontend. Quiz solutions are stored server-side and returned only after submission.

### API contracts
FastAPI exposes machine-readable contracts at `/openapi.json` and interactive documentation at `/docs`. Routes follow the requested `/api` paths. Extra routes: `PATCH /api/auth/me`, authenticated PDF file endpoint, document reindex endpoint, quiz list/load/submit endpoints. Successful writes return resource JSON (201 on creation) or 204 on deletion. Errors use `{ "error": { "code": "...", "message": "...", "fields": [...] } }`; fields appear on validation errors only. Request errors never echo submitted passwords.

### Implementation order
1. Database, auth, ownership and common validation.
2. Tasks, notes and genuine dashboard data.
3. Ollama boundary and conversation persistence.
4. PDF extraction, local indexing, retrieval, citations and summaries.
5. Structured quizzes, validation, server scoring.
6. Responsive UI and themes.
7. API tests, browser workflows, source documentation.

## Security boundaries
- CORS uses explicit frontend origins. Unsafe browser requests are origin-checked. Loopback-only services are the default.
- Password hashing, session expiry, logout invalidation, restricted session count, sanitized errors.
- Per-IP in-memory write/auth/AI throttling and two concurrent local LLM requests. This is a single-process development control, not a distributed production limiter.
- PDF extension/type/header checks, streamed size limit, 400-page limit, bounded extracted text, random storage paths. Ownership is checked for original PDFs and every AI resource operation.
- Document passages are explicitly treated as untrusted prompt data. Citation IDs are validated against retrieved passages. This does not guarantee that the generated prose is semantically faithful.

## Known architectural limits
No deployment, HTTPS termination, encrypted-at-rest storage, password recovery/email verification, OCR, SSE streaming, background jobs, distributed locks/limiting, production migrations, or training run is supplied. Synchronous indexing and request-bound summaries suit local demonstrations but need a job queue for larger workloads. Lists are unpaginated, documents are capped at 50 per account. Embedding and LLM weights must be prepared separately. AI answer correctness and quiz factual validity are not automatically certified. See VERIFICATION.md for actual tests, not projected scores.
