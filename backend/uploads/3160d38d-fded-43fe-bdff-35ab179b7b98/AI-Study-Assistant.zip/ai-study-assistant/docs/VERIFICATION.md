# Actual verification results

Verified in a Linux sandbox with Python 3.13, Node.js 24, a CPU-only embedding model and Chromium. Windows commands are documented but were not executed on a Windows machine. The app was tested locally, not deployed to a public host.

## Automated backend
Final command: `RUN_LOCAL_RAG=1 .venv/bin/python -m pytest -q`

**Result: 22 passed in 10.89 seconds.** No test failures in the final run.

Coverage includes:
- All protected resource lists deny unauthenticated users.
- Registration, hashed passwords, opaque hashed sessions, wrong-password rejection, login, logout and session expiration.
- Duplicate accounts and validation errors without echoing rejected passwords.
- Planner CRUD, null/value rejection, completion and genuine dashboard aggregation.
- Notes CRUD, literal search and ownership isolation.
- Profile/theme preference persistence.
- Browser-origin checks, auth throttling and request-size limits.
- Genuine unavailable-runtime behavior: no fabricated response or conversation is saved.
- Chat history and conversation deletion/ownership contracts with an explicit model double.
- PDF type/header/text validation, scans without OCR, safe basename handling, text-only state, authenticated original-file access, reindexing and document ownership.
- Valid and invalid RAG citation IDs; summary output contract with model doubles.
- Quiz option/count validation, no saved invalid quizzes, answer withholding before submission, server scoring and quiz ownership.
- Local-only inference configuration and page-preserving overlapping chunks.
- **Actual cached all-MiniLM-L6-v2 embeddings + persistent Chroma + semantic retrieval** with `HF_HUB_OFFLINE=1` and `TRANSFORMERS_OFFLINE=1`. The correct database-transaction source page was returned. The first measured integration run took approximately 5.86 seconds including model loading; this is a smoke-test observation, not an LLM latency benchmark or an accuracy score.

Without `RUN_LOCAL_RAG=1`, the 21 core tests run and the one model-dependent integration test is skipped. Prepare embedding weights first before opting in.

## Frontend checks
- `npm run typecheck`: passed.
- `npm run build`: passed; Vite produced a production bundle.
- `npm run format:check`: passed after fixing one formatting warning.
- `npm audit --omit=dev`: reported **0 vulnerabilities** in the installed production dependency tree at verification time. This is not a guarantee of security.
- Backend Python compilation and formatter checks: passed.

## Browser checks
Portable script: `frontend/tests/e2e.mjs`. Result file: `docs/qa/browser-results.json`.

**10 workflow checks passed**, plus desktop/mobile route-capture and no-horizontal-overflow checks. **0 uncaught browser errors.**

Verified through the actual UI/backend: registration/protected dashboard, planner create/edit/complete, note create/search/read, PDF upload with genuine extraction and local indexing, offline-model tutor/quiz/summary error handling, persisted theme preference, mobile navigation, logout and login. Routes were captured at 1440px and 390px; dialogs, PDF details, empty states and a dark-theme state were also captured and visually inspected. An initial label-accessibility issue and a mobile skip-link capture issue were found and corrected. The final browser run passed.

Screenshots contain explicitly named QA fixtures. The delivered app seeds no fake documents, conversations, scores or student tasks. The runtime test database and cached model files are excluded from the source archive.

The browser script intentionally expects Ollama to be unavailable to verify honest failure states. Stop Ollama for this script, or adapt those assertions before using it in a model-enabled environment. It creates test accounts/resources in the running local development database; do not point it at a real production workspace.

## Not verified / remaining work
- Real Ollama/EduLlama generation: **not run**; Ollama and trained EduLlama weights were not present. Successful tutor/RAG-summary/quiz generation is covered at the API contract boundary using explicit doubles, not represented as real model inference.
- No fabricated evaluation scores. Human factual correctness, answer relevance, semantic source fidelity and quiz truth require real-model runs and review.
- Long-document map/reduce is implemented, but not benchmarked against a real long-document LLM workload.
- No Windows runtime test, public deployment, penetration test, heavy-load test, GPU memory measurements, training run, OCR or streaming verification.
- Production needs HTTPS, secure cookies, migrations, job scheduling, distributed controls, backup policy and a broader security review.

## Re-run on Windows PowerShell
From the project root, after setup and model-file preparation:

```powershell
Set-Location .\backend
$env:RUN_LOCAL_RAG = "1"
.\.venv\Scripts\python.exe -m pytest -q
Remove-Item Env:RUN_LOCAL_RAG
Set-Location ..\frontend
npm run typecheck
npm run build
npm run format:check
npm audit --omit=dev
# With frontend/backend running in other terminals and Ollama stopped:
npx playwright install chromium
npm run test:e2e
```
