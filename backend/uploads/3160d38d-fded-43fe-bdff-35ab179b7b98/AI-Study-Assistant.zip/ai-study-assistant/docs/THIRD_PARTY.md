# Third-party licensing notes

Review dependency and model licenses before distributing or deploying the project. Package inclusion does not grant rights to textbooks, student data or model training material.

- PyMuPDF is offered under AGPL and commercial terms. This project uses the open-source package. Review AGPL obligations for your use/distribution/network service; replace it with a suitably licensed extractor or obtain appropriate licensing if those terms do not fit your intended use.
- Llama models have model/version-specific license and acceptable-use requirements. Preserve required notices, comply with access/distribution restrictions, and accurately identify a base model versus a fine-tuned derivative.
- The configured embedding model is `sentence-transformers/all-MiniLM-L6-v2`; read the model repository's current license and preserve applicable notices when redistributing weights.
- React, Vite, Tailwind, Lucide, FastAPI, SQLAlchemy, Chroma and all transitive packages have their own licenses; inspect the installed package license files and model cards. This note is not a legal opinion or an exhaustive license audit.

No model weights are bundled. The demonstration PDF fixture contains original synthetic QA text and is clearly labeled as a test fixture.
