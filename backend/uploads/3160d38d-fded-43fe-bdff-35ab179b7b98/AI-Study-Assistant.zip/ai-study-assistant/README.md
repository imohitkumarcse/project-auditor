# EduLlama — AI Study Assistant

A local-first college learning platform: React/TypeScript frontend, FastAPI backend, SQLite persistence, Ollama inference, and local PDF retrieval. **No paid or hosted AI inference/embedding APIs.** No trained model weights are bundled.

## What is implemented
- Registration/login/logout, Argon2id password hashing, expiring HttpOnly sessions, protected routes and per-user authorization.
- Genuine dashboard data; daily/weekly study planner, task editing/completion/deletion and revision checklist.
- Notes CRUD, search/subject filters, Markdown reading, save AI responses/summaries/document answers.
- Responsive light/dark/system theme, mobile sidebar, clear empty/loading/error states.
- PDF upload, metadata, authenticated original-file access, extraction with page references, deletion, local Chroma indexing and reindexing.
- Tutor conversations with local Ollama, persistent history/deletion, subject and explanation-style controls, copy and save.
- RAG document Q&A with validated retrieved citation IDs; six summary formats with long-document map/reduce.
- Structured MCQ generation, four-option validation, saved quizzes, server-side scoring and incorrect-answer review.
- API/ownership tests, browser test results and measured-response evaluation tooling.

AI-dependent features require local runtime/model setup. PDF text extraction, accounts, tasks and notes work without Ollama. Missing embeddings produce `text_ready`, **not** an “indexed successfully” message. Missing Ollama produces an explicit error, never a fabricated answer.

## Requirements
- Windows PowerShell, Python 3.12 or 3.13, Node.js 22+ and npm.
- Ollama for generation; a compatible Llama-family model you are licensed to use.
- Enough disk/RAM for model files. CPU embeddings work; LLM performance depends strongly on your hardware. Begin with a small model for development.

## Windows PowerShell — install
Extract the project, then run from the project root:

```powershell
Set-Location "C:\Projects\ai-study-assistant"
py -3.12 -m venv .\backend\.venv
.\backend\.venv\Scripts\python.exe -m pip install --upgrade pip
# CPU-only PyTorch avoids unnecessarily installing CUDA wheels.
.\backend\.venv\Scripts\python.exe -m pip install torch --index-url https://download.pytorch.org/whl/cpu
.\backend\.venv\Scripts\python.exe -m pip install -r .\backend\requirements.txt
Copy-Item .\backend\.env.example .\backend\.env
Set-Location .\frontend
npm ci
Set-Location ..
```

If only Python 3.13 is installed, replace `py -3.12` with `py -3.13`. No virtual-environment activation or execution-policy changes are required. The frontend lockfile fixes the installed dependency tree; backend requirements use compatible ranges, not a cross-platform fully locked environment.

### Prepare local embeddings once
This downloads model files; generation/inference remains local. Internet is needed only for installation/downloads.

```powershell
.\backend\.venv\Scripts\python.exe .\ai-training\scripts\prepare_embeddings.py
```

Keep `EMBEDDING_LOCAL_ONLY=true` in `backend\.env`. If changing `EMBEDDING_MODEL`, prepare that exact model and reindex existing PDFs. Downloads are not performed silently in normal requests.

### Ollama setup
Install Ollama from its official distribution, or use Windows Package Manager:

```powershell
winget install --id Ollama.Ollama -e
# Reopen PowerShell if ollama is not yet on PATH.
ollama --version
ollama list
```

The Windows app may already run Ollama in the background. If not, open a separate terminal and run:

```powershell
$env:OLLAMA_HOST = "127.0.0.1:11434"
ollama serve
```

Do not bind Ollama to `0.0.0.0` or expose it publicly.

For development with a base model you are licensed to use, for example:

```powershell
ollama pull llama3.2:3b
# Set OLLAMA_MODEL=llama3.2:3b in backend\.env, then restart FastAPI.
```

This is **base Llama, not fine-tuned EduLlama**. For the actual customized model, supply a legally usable trained GGUF and follow `ai-training/README.md`:

```powershell
Copy-Item .\ai-training\Modelfile.example .\ai-training\Modelfile
# Place actual trained weights at ai-training\models\edullama.gguf first.
ollama create edullama -f .\ai-training\Modelfile
ollama list
# Set OLLAMA_MODEL=edullama in backend\.env, then restart FastAPI.
```

The default configured model is `edullama`; until installed, generation stays unavailable. The app does not silently fall back to another model.

## Run — two PowerShell terminals

Backend:

```powershell
Set-Location "C:\Projects\ai-study-assistant\backend"
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

Frontend:

```powershell
Set-Location "C:\Projects\ai-study-assistant\frontend"
npm run dev
```

Open `http://localhost:5173`. API documentation: `http://127.0.0.1:8000/docs`. Vite forwards `/api` to FastAPI, allowing HttpOnly cookies without frontend tokens. Use localhost or 127.0.0.1 consistently; they have separate cookies. SQLite tables are created at first startup. `backend/storage/` is generated at runtime and intentionally absent from the source archive.

## Environment variables
All backend paths are relative to the backend working directory.

| Variable | Default | Purpose |
|---|---|---|
| `DATABASE_URL` | `sqlite:///./storage/study.db` | SQLAlchemy database |
| `STORAGE_DIR` | `./storage` | PDFs and local Chroma vectors |
| `FRONTEND_ORIGINS` | localhost + 127.0.0.1 on 5173 | JSON list of allowed browser origins |
| `OLLAMA_BASE_URL` | `http://127.0.0.1:11434` | Loopback-only inference runtime |
| `OLLAMA_MODEL` | `edullama` | Actual installed model name |
| `EMBEDDING_MODEL` | `sentence-transformers/all-MiniLM-L6-v2` | Local embedding model |
| `EMBEDDING_LOCAL_ONLY` | `true` | Require already cached weights |
| `AI_TIMEOUT_SECONDS` | `180` | Timeout per generation call |
| `MAX_UPLOAD_MB` | `20` | Backend upload-size limit; frontend default is also 20 MB |
| `COOKIE_SECURE` | `false` | Local HTTP only; set true behind HTTPS in a real deployment |
| `SESSION_DAYS` | `7` | Session expiration |

No hosted API keys are needed. Never commit `.env`, tokens, user PDFs, model weights, or database files. The UI does not expose session tokens or internal credentials.

## Verify

```powershell
Set-Location "C:\Projects\ai-study-assistant\backend"
.\.venv\Scripts\python.exe -m pytest -q
Set-Location ..\frontend
npm run typecheck
npm run build
```

API tests use an isolated temporary SQLite database. The standard run executes 21 core tests and skips one optional real-embedding integration test; see `docs/VERIFICATION.md` to enable it. Successful AI contract tests use explicit provider doubles, **not real model inference**. Offline-model tests exercise genuine failure behavior. See `docs/VERIFICATION.md` for actual results and limitations.

### Manual feature checklist
1. Create an account; sign out and back in. Wrong passwords must fail. A logged-out dashboard redirects to login.
2. Create/edit/complete/delete planner sessions; test day/week/revision views. Reload and confirm persistence.
3. Write a Markdown note, search it, filter its subject, edit and delete it.
4. Upload a text-based PDF. Verify pages and authenticated original-file access. With missing embeddings it must say text-only; prepare the model, then retry indexing.
5. Upload a scanned/empty/corrupt file. It must reject unusable text and explain missing OCR rather than claiming completion.
6. Start Ollama and install the configured model. Check Settings, then send a tutor prompt, reload its history, copy/save an answer and delete the conversation.
7. Ask an indexed PDF a question. Review retrieved source snippets against the original pages. Ask an unsupported question and scrutinize the insufficient-evidence response.
8. Generate each summary type, then save one to notes. Large documents take multiple local requests.
9. Generate a quiz from topic/subject/indexed PDF. Answer all questions and submit; inspect score and explanations. A malformed model output must fail rather than save a fake quiz.
10. Create a second account. It must never see the first user's documents, notes, tasks, chats or quizzes; direct guessed resource IDs return 404.
11. Stop Ollama. Generation must fail clearly without adding fabricated conversations/quizzes. Planner and notes must remain functional.
12. Test the mobile menu and light/dark/system appearance.

## Academic evaluation
Read `ai-training/README.md`. The actual-response recorder is run from the project root, with a separate test account:

```powershell
.\backend\.venv\Scripts\python.exe .\ai-training\scripts\evaluate.py --cases .\docs\evaluation-cases.example.jsonl --output .\ai-training\outputs\base-direct.jsonl --label base-llama --mode direct --email "your-evaluation-account@example.edu"
```

A password is requested without echo. Configure/restart the backend for each base versus actual fine-tuned model run. RAG cases additionally require an owned indexed `document_id`. Human correctness, relevance and source-grounding fields remain null until reviewed; no evaluation scores are invented.

## Scope and remaining work
This is a tested **local development foundation**, not a certified production deployment. Not included: trained EduLlama weights, actual fine-tuning, OCR, token streaming, password recovery, email verification, cloud deployment, background job queue, Alembic migrations, distributed request limiting, or automatic semantic correctness certification. Initial schema creation is not a migration system. Existing databases will need real migrations after schema changes. Store backups and protect your device; the SQLite database/PDFs are not encrypted at rest.

Source architecture: `docs/ARCHITECTURE.md`. Actual verification: `docs/VERIFICATION.md`. Screenshots contain clearly named QA fixtures created only for testing; the application seeds no fake student data.

Third-party licensing notes, including PyMuPDF AGPL considerations: `docs/THIRD_PARTY.md`.
