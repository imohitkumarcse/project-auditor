import pytest
import fitz
from fastapi import HTTPException
from sqlalchemy import select
from app.core.config import Settings
from app.db.session import SessionLocal
from app.models.entities import User, Session, Conversation, Message, Quiz
from app.services import ollama, documents
from conftest import second_user

TASK = {
    "title": "Practice recursion",
    "subject": "Python",
    "priority": "high",
    "due_date": "2026-10-12",
    "duration": 45,
    "revision": True,
}
NOTE = {
    "title": "Recursion notes",
    "subject": "Python",
    "content": "A recursive function needs a base case.",
}


def pdf_bytes(
    text="A database transaction is atomic, consistent, isolated and durable. ACID properties protect data integrity.",
):
    pdf = fitz.open()
    page = pdf.new_page()
    page.insert_text((72, 72), text)
    data = pdf.tobytes()
    pdf.close()
    return data


def test_protected_routes(client):
    for path in [
        "/api/auth/me",
        "/api/dashboard",
        "/api/tasks",
        "/api/notes",
        "/api/documents",
        "/api/conversations",
        "/api/quizzes",
        "/api/health/ai",
    ]:
        assert client.get(path).status_code == 401


def test_auth_password_hash_logout_and_login(signed_in):
    me = signed_in.get("/api/auth/me")
    assert me.status_code == 200
    assert "password" not in me.text and "token" not in me.text
    with SessionLocal() as db:
        user = db.scalar(select(User))
        assert user.password_hash.startswith("$argon2id$")
        session = db.scalar(select(Session))
        assert len(session.token_hash) == 64
    assert signed_in.post("/api/auth/logout").status_code == 204
    assert signed_in.get("/api/auth/me").status_code == 401
    assert (
        signed_in.post(
            "/api/auth/login",
            json={"email": "student@example.edu", "password": "wrong"},
        ).status_code
        == 401
    )
    assert (
        signed_in.post(
            "/api/auth/login",
            json={"email": "student@example.edu", "password": "study-password-123"},
        ).status_code
        == 200
    )


def test_duplicate_and_validation(client):
    payload = {
        "name": "Student",
        "email": "s@example.edu",
        "password": "safe-password-123",
    }
    assert client.post("/api/auth/register", json=payload).status_code == 201
    assert client.post("/api/auth/register", json=payload).status_code == 409
    payload["password"] = "short"
    response = client.post("/api/auth/register", json=payload)
    assert response.status_code == 422 and "short" not in response.text


def test_task_crud_and_ownership(signed_in):
    created = signed_in.post("/api/tasks", json=TASK)
    assert created.status_code == 201
    id_ = created.json()["id"]
    other = second_user()
    assert other.get("/api/tasks").json() == []
    assert other.patch(f"/api/tasks/{id_}", json={"completed": True}).status_code == 404
    assert other.delete(f"/api/tasks/{id_}").status_code == 404
    assert (
        signed_in.patch(f"/api/tasks/{id_}", json={"completed": True}).json()[
            "completed"
        ]
        is True
    )
    assert signed_in.patch(f"/api/tasks/{id_}", json={"duration": 0}).status_code == 422
    assert signed_in.patch(f"/api/tasks/{id_}", json={"title": None}).status_code == 422
    assert signed_in.get("/api/dashboard").json()["stats"]["completed"] == 1
    assert signed_in.delete(f"/api/tasks/{id_}").status_code == 204
    assert signed_in.get("/api/tasks").json() == []


def test_notes_search_and_ownership(signed_in):
    note = signed_in.post("/api/notes", json=NOTE)
    assert note.status_code == 201
    id_ = note.json()["id"]
    other = second_user()
    assert other.get("/api/notes").json() == []
    assert other.patch(f"/api/notes/{id_}", json=NOTE).status_code == 404
    assert other.delete(f"/api/notes/{id_}").status_code == 404
    assert len(signed_in.get("/api/notes?q=base").json()) == 1
    assert signed_in.get("/api/notes?q=%25").json() == []
    assert (
        signed_in.patch(f"/api/notes/{id_}", json={**NOTE, "title": "Updated"}).json()[
            "title"
        ]
        == "Updated"
    )
    assert signed_in.delete(f"/api/notes/{id_}").status_code == 204


def test_settings(signed_in):
    response = signed_in.patch(
        "/api/auth/me",
        json={
            "name": "New Student",
            "subject": "DBMS",
            "explanation_style": "exam",
            "theme": "dark",
        },
    )
    assert response.status_code == 200 and response.json()["theme"] == "dark"
    assert signed_in.get("/api/auth/me").json()["subject"] == "DBMS"


def test_origin_protection(signed_in):
    assert (
        signed_in.post(
            "/api/tasks", json=TASK, headers={"Origin": "https://evil.example"}
        ).status_code
        == 403
    )
    assert (
        signed_in.post(
            "/api/tasks", json=TASK, headers={"Origin": "http://localhost:5173"}
        ).status_code
        == 201
    )


def test_auth_throttle(client):
    for _ in range(10):
        assert (
            client.post(
                "/api/auth/login", json={"email": "no@example.edu", "password": "bad"}
            ).status_code
            == 401
        )
    response = client.post(
        "/api/auth/login", json={"email": "no@example.edu", "password": "bad"}
    )
    assert response.status_code == 429 and response.headers["Retry-After"] == "60"


def test_ai_unavailable_is_honest(signed_in):
    health = signed_in.get("/api/health/ai").json()
    assert health["available"] is False
    response = signed_in.post("/api/chat", json={"message": "Explain recursion"})
    assert response.status_code == 503
    assert signed_in.get("/api/conversations").json() == []


# These tests simulate the provider boundary; they are NOT real EduLlama inference tests.
def test_chat_contract_and_ownership(signed_in, monkeypatch):
    async def fake_generate(*args, **kwargs):
        return "A base case stops recursion.", {"latency_ms": 1, "model": "test-double"}

    monkeypatch.setattr(ollama, "generate", fake_generate)
    result = signed_in.post("/api/chat", json={"message": "Explain recursion"})
    assert result.status_code == 200
    id_ = result.json()["conversation_id"]
    assert len(signed_in.get(f"/api/conversations/{id_}").json()["messages"]) == 2
    other = second_user()
    assert other.get(f"/api/conversations/{id_}").status_code == 404
    assert (
        other.post(
            "/api/chat", json={"message": "Hello", "conversation_id": id_}
        ).status_code
        == 404
    )
    assert other.delete(f"/api/conversations/{id_}").status_code == 404
    assert signed_in.delete(f"/api/conversations/{id_}").status_code == 204
    with SessionLocal() as db:
        assert db.scalar(select(Message)) is None


def test_document_validation(signed_in):
    assert (
        signed_in.post(
            "/api/documents/upload", files={"file": ("bad.txt", b"text", "text/plain")}
        ).status_code
        == 415
    )
    assert (
        signed_in.post(
            "/api/documents/upload",
            files={"file": ("fake.pdf", b"not-pdf", "application/pdf")},
        ).status_code
        == 415
    )
    pdf = fitz.open()
    pdf.new_page()
    scanned = pdf.tobytes()
    pdf.close()
    result = signed_in.post(
        "/api/documents/upload",
        files={"file": ("scanned.pdf", scanned, "application/pdf")},
    )
    assert result.status_code == 422 and "OCR" in result.json()["error"]["message"]
    assert signed_in.get("/api/documents").json() == []


def test_document_text_only_ownership_and_reindex(signed_in, monkeypatch):
    def unavailable(*args):
        raise HTTPException(503, "Local embeddings unavailable in test.")

    monkeypatch.setattr(documents, "index_document", unavailable)
    result = signed_in.post(
        "/api/documents/upload",
        files={"file": ("../../chapter.pdf", pdf_bytes(), "application/pdf")},
    )
    assert result.status_code == 201
    doc = result.json()
    assert (
        doc["name"] == "chapter.pdf"
        and doc["status"] == "text_ready"
        and "page_texts" not in doc
    )
    id_ = doc["id"]
    other = second_user()
    for path in [f"/api/documents/{id_}", f"/api/documents/{id_}/file"]:
        assert other.get(path).status_code == 404
    for suffix, body in [
        ("ask", {"question": "What is ACID?"}),
        ("summarize", {"mode": "short"}),
        ("index", {}),
    ]:
        assert (
            other.post(f"/api/documents/{id_}/{suffix}", json=body).status_code == 404
        )
    assert other.delete(f"/api/documents/{id_}").status_code == 404
    assert (
        signed_in.post(
            f"/api/documents/{id_}/ask", json={"question": "What is ACID?"}
        ).status_code
        == 409
    )
    assert (
        signed_in.get(f"/api/documents/{id_}/file").headers["content-type"]
        == "application/pdf"
    )
    assert signed_in.post(f"/api/documents/{id_}/index").status_code == 503
    monkeypatch.setattr(documents, "index_document", lambda *a: None)
    assert signed_in.post(f"/api/documents/{id_}/index").json()["status"] == "ready"
    monkeypatch.setattr(documents, "delete_index", lambda *a: None)
    assert signed_in.delete(f"/api/documents/{id_}").status_code == 204


def test_rag_citation_contract(signed_in, monkeypatch):
    monkeypatch.setattr(documents, "index_document", lambda *a: None)
    doc = signed_in.post(
        "/api/documents/upload",
        files={"file": ("chapter.pdf", pdf_bytes(), "application/pdf")},
    ).json()
    monkeypatch.setattr(
        "app.services.study_ai.retrieve",
        lambda *a: [{"id": "p1-c1", "page": 1, "text": "Transactions follow ACID."}],
    )

    async def valid(*a, **k):
        return '{"answer":"Transactions follow ACID.","source_ids":["p1-c1"]}', {}

    monkeypatch.setattr(ollama, "generate", valid)
    result = signed_in.post(
        f"/api/documents/{doc['id']}/ask",
        json={"question": "What protects a transaction?"},
    )
    assert result.status_code == 200 and result.json()["sources"][0]["page"] == 1

    async def invalid(*a, **k):
        return '{"answer":"Something","source_ids":["made-up-source"]}', {}

    monkeypatch.setattr(ollama, "generate", invalid)
    assert (
        signed_in.post(
            f"/api/documents/{doc['id']}/ask",
            json={"question": "What protects a transaction?"},
        ).status_code
        == 502
    )


def test_summary_contract(signed_in, monkeypatch):
    monkeypatch.setattr(documents, "index_document", lambda *a: None)
    doc = signed_in.post(
        "/api/documents/upload",
        files={"file": ("chapter.pdf", pdf_bytes(), "application/pdf")},
    ).json()

    async def summary(*a, **k):
        return "## Transactions\nACID preserves integrity. (Page 1)", {"latency_ms": 1}

    monkeypatch.setattr(ollama, "generate", summary)
    result = signed_in.post(
        f"/api/documents/{doc['id']}/summarize", json={"mode": "revision"}
    )
    assert result.status_code == 200 and result.json()["batches_processed"] == 1


def test_quiz_validation_score_and_ownership(signed_in, monkeypatch):
    async def quiz(*a, **k):
        return (
            '{"questions":[{"question":"Which keyword defines a Python function?","options":["def","class","import","return"],"correct_index":0,"explanation":"The def keyword defines a function."}]}',
            {},
        )

    monkeypatch.setattr(ollama, "generate", quiz)
    result = signed_in.post(
        "/api/quizzes/generate",
        json={"source": "topic", "topic": "Python functions", "count": 1},
    )
    assert result.status_code == 201
    q = result.json()
    assert "correct_index" not in str(q["questions"])
    id_ = q["id"]
    other = second_user()
    assert other.get(f"/api/quizzes/{id_}").status_code == 404
    assert (
        other.post(f"/api/quizzes/{id_}/submit", json={"answers": [0]}).status_code
        == 404
    )
    assert (
        signed_in.post(f"/api/quizzes/{id_}/submit", json={"answers": [5]}).status_code
        == 422
    )
    review = signed_in.post(f"/api/quizzes/{id_}/submit", json={"answers": [0]}).json()
    assert review["score"] == 1 and review["questions"][0]["correct_index"] == 0

    async def invalid(*a, **k):
        return (
            '{"questions":[{"question":"Invalid question?","options":["same","same","x","y"],"correct_index":9,"explanation":"Invalid answer"}]}',
            {},
        )

    monkeypatch.setattr(ollama, "generate", invalid)
    assert (
        signed_in.post(
            "/api/quizzes/generate",
            json={"source": "subject", "subject": "Python", "count": 1},
        ).status_code
        == 502
    )
    assert len(signed_in.get("/api/quizzes").json()) == 1


def test_local_only_inference_config():
    with pytest.raises(ValueError):
        Settings(ollama_base_url="https://hosted.example")


def test_chunk_page_metadata():
    chunks = documents.chunks(["x" * 2500, "Second page content"])
    assert chunks[0]["page"] == 1 and chunks[-1]["page"] == 2
    assert chunks[0]["text"][-200:] == chunks[1]["text"][:200]


def test_expired_session_is_denied(signed_in):
    from datetime import datetime, timedelta, timezone

    with SessionLocal() as db:
        session = db.scalar(select(Session))
        session.expires_at = datetime.now(timezone.utc) - timedelta(days=1)
        db.commit()
    assert signed_in.get("/api/auth/me").status_code == 401


def test_upload_request_size_limit(signed_in):
    response = signed_in.post(
        "/api/documents/upload",
        content=b"x",
        headers={
            "Content-Length": str(25 * 1024 * 1024),
            "Content-Type": "application/pdf",
        },
    )
    assert response.status_code == 413


def test_empty_dashboard_is_not_demo(signed_in):
    dashboard = signed_in.get("/api/dashboard").json()
    assert dashboard["demo"] is False and dashboard["stats"] == {
        "tasks": 0,
        "completed": 0,
        "documents": 0,
        "notes": 0,
    }


def test_document_quiz_ownership(signed_in, monkeypatch):
    monkeypatch.setattr(documents, "index_document", lambda *a: None)
    doc = signed_in.post(
        "/api/documents/upload",
        files={"file": ("chapter.pdf", pdf_bytes(), "application/pdf")},
    ).json()
    other = second_user()
    assert (
        other.post(
            "/api/quizzes/generate",
            json={"source": "document", "document_id": doc["id"], "count": 1},
        ).status_code
        == 404
    )
