import os
import tempfile
from pathlib import Path

ROOT = Path(tempfile.mkdtemp(prefix="edullama-tests-"))
os.environ["STORAGE_DIR"] = str(ROOT / "storage")
os.environ["DATABASE_URL"] = "sqlite:///" + str(ROOT / "test.db")
os.environ["OLLAMA_BASE_URL"] = "http://127.0.0.1:1"

import pytest
from fastapi.testclient import TestClient
from app.main import app, throttle
from app.db.session import Base, engine


@pytest.fixture(autouse=True)
def clean_database():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    throttle.requests.clear()
    yield


@pytest.fixture
def client():
    with TestClient(app) as client:
        yield client


@pytest.fixture
def signed_in(client):
    response = client.post(
        "/api/auth/register",
        json={
            "name": "Test Student",
            "email": "student@example.edu",
            "password": "study-password-123",
        },
    )
    assert response.status_code == 201
    return client


def second_user():
    client = TestClient(app)
    response = client.post(
        "/api/auth/register",
        json={
            "name": "Other Student",
            "email": "other@example.edu",
            "password": "other-password-123",
        },
    )
    assert response.status_code == 201
    return client
