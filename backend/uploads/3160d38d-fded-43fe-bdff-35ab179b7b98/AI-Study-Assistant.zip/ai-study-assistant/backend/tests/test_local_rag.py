"""Opt-in integration test with actual cached embeddings and Chroma, not a double."""

import os
import time
import pytest
from app.models.entities import Document
from app.services import documents


@pytest.mark.skipif(
    os.getenv("RUN_LOCAL_RAG") != "1",
    reason="Set RUN_LOCAL_RAG=1 after preparing actual local embedding weights.",
)
def test_actual_offline_embeddings_chroma_and_retrieval(monkeypatch):
    monkeypatch.setenv("HF_HUB_OFFLINE", "1")
    monkeypatch.setenv("TRANSFORMERS_OFFLINE", "1")
    doc = Document(
        id="11111111-1111-1111-1111-111111111111",
        user_id="local-rag-test-owner",
        name="integration.pdf",
        size=100,
        page_texts=[
            "Database transactions follow ACID. Atomicity means all or nothing. Isolation separates concurrent transactions.",
            "A digital multiplexer selects one input signal using selection lines.",
        ],
        status="ready",
    )
    started = time.perf_counter()
    documents.index_document(doc)
    result = documents.retrieve(
        doc, "What does atomicity mean for a database transaction?", limit=1
    )
    assert result and result[0]["page"] == 1 and "Atomicity" in result[0]["text"]
    print(
        f"Actual offline embedding + Chroma + retrieval: {(time.perf_counter() - started) * 1000:.0f} ms"
    )
    documents.delete_index(doc)
