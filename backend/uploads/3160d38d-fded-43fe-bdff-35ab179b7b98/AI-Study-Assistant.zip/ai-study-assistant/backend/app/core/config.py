from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, field_validator


class Settings(BaseSettings):
    database_url: str = "sqlite:///./storage/study.db"
    storage_dir: Path = Path("./storage")
    frontend_origins: list[str] = ["http://localhost:5173", "http://127.0.0.1:5173"]
    ollama_base_url: str = "http://127.0.0.1:11434"
    ollama_model: str = "edullama"
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    embedding_local_only: bool = True
    ai_timeout_seconds: int = Field(180, ge=1, le=900)
    max_upload_mb: int = Field(20, ge=1, le=100)
    cookie_secure: bool = False
    session_days: int = Field(7, ge=1, le=30)
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @field_validator("ollama_base_url")
    @classmethod
    def local_ollama(cls, value):
        from urllib.parse import urlparse

        parsed = urlparse(value)
        if parsed.scheme != "http" or parsed.hostname not in {
            "localhost",
            "127.0.0.1",
            "::1",
        }:
            raise ValueError(
                "Ollama must use a loopback HTTP address; hosted inference is not supported."
            )
        return value.rstrip("/")


settings = Settings()
settings.storage_dir.mkdir(parents=True, exist_ok=True)
