import hashlib, secrets
from datetime import datetime, timezone
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHashError, VerificationError
from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session as DBSession
from app.db.session import get_db
from app.models.entities import User, Session

hasher = PasswordHasher()
DUMMY_HASH = hasher.hash("not-a-real-user-password")


def token_hash(value: str):
    return hashlib.sha256(value.encode()).hexdigest()


def new_token():
    return secrets.token_urlsafe(48)


def verify_password(password, hashed):
    try:
        return hasher.verify(hashed, password)
    except (VerifyMismatchError, InvalidHashError, VerificationError):
        return False


def current_user(request: Request, db: DBSession = Depends(get_db)):
    token = request.cookies.get("study_session")
    session = db.get(Session, token_hash(token)) if token else None
    if not session or session.expires_at.replace(tzinfo=timezone.utc) <= datetime.now(
        timezone.utc
    ):
        raise HTTPException(401, "Sign in to continue.")
    user = db.get(User, session.user_id)
    if not user:
        raise HTTPException(401, "Sign in to continue.")
    return user


def owned(db, model, resource_id, user):
    item = db.get(model, resource_id)
    if item is None or item.user_id != user.id:
        raise HTTPException(404, "Resource not found.")
    return item
