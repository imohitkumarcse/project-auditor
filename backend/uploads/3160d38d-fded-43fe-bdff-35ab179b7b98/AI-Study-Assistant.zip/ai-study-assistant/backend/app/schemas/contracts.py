from datetime import date
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, EmailStr, model_validator

Subject = Literal[
    "Python",
    "Data Structures",
    "DBMS",
    "Computer Organization",
    "Digital Electronics",
    "Discrete Structures",
    "General",
]
Style = Literal["beginner", "step-by-step", "example", "exam", "practice"]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class Register(StrictModel):
    name: str = Field(min_length=2, max_length=80)
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)


class Login(StrictModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)


class ProfileUpdate(StrictModel):
    name: str = Field(min_length=2, max_length=80)
    subject: Subject
    explanation_style: Style
    theme: Literal["system", "light", "dark"]


class ChatInput(StrictModel):
    message: str = Field(min_length=1, max_length=6000)
    conversation_id: str | None = None
    subject: Subject = "Python"
    style: Style = "beginner"


class AskInput(StrictModel):
    question: str = Field(min_length=1, max_length=2000)


class SummaryInput(StrictModel):
    mode: Literal[
        "short", "detailed", "sections", "concepts", "definitions", "revision"
    ] = "short"


class TaskInput(StrictModel):
    title: str = Field(min_length=1, max_length=200)
    subject: str = Field(min_length=1, max_length=80)
    priority: Literal["low", "medium", "high"] = "medium"
    due_date: date
    duration: int = Field(30, ge=5, le=600)
    revision: bool = False


class TaskPatch(StrictModel):
    title: str | None = Field(None, min_length=1, max_length=200)
    subject: str | None = Field(None, min_length=1, max_length=80)
    priority: Literal["low", "medium", "high"] | None = None
    due_date: date | None = None
    duration: int | None = Field(None, ge=5, le=600)
    completed: bool | None = None
    revision: bool | None = None

    @model_validator(mode="after")
    def no_nulls(self):
        if any(getattr(self, key) is None for key in self.model_fields_set):
            raise ValueError("Provided fields cannot be null")
        return self


class NoteInput(StrictModel):
    title: str = Field(min_length=1, max_length=200)
    subject: str = Field(min_length=1, max_length=80)
    content: str = Field(min_length=1, max_length=50000)


class QuizInput(StrictModel):
    source: Literal["topic", "subject", "document"]
    topic: str = Field("", max_length=500)
    subject: Subject = "Python"
    document_id: str | None = None
    count: int = Field(5, ge=1, le=15)
    difficulty: Literal["easy", "medium", "hard"] = "medium"

    @model_validator(mode="after")
    def source_required(self):
        if self.source == "document" and not self.document_id:
            raise ValueError("Select a document")
        if self.source == "topic" and not self.topic:
            raise ValueError("Enter a topic")
        return self


class Question(StrictModel):
    question: str = Field(min_length=8, max_length=2000)
    options: list[str] = Field(min_length=4, max_length=4)
    correct_index: int = Field(ge=0, le=3)
    explanation: str = Field(min_length=8, max_length=3000)

    @model_validator(mode="after")
    def valid_options(self):
        if (
            any(not x.strip() for x in self.options)
            or len(set(x.strip().casefold() for x in self.options)) != 4
        ):
            raise ValueError("Four distinct, nonempty options are required")
        return self


class GeneratedQuiz(StrictModel):
    questions: list[Question] = Field(min_length=1, max_length=15)


class AttemptInput(StrictModel):
    answers: list[int] = Field(min_length=1, max_length=15)


class GroundedAnswer(StrictModel):
    answer: str = Field(min_length=1, max_length=20000)
    source_ids: list[str]
