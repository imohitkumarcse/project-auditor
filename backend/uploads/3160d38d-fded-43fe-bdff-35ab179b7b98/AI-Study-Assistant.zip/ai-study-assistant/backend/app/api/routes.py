import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from uuid import uuid4
from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Request,
    Response,
    UploadFile,
    File,
)
from fastapi.responses import FileResponse
from sqlalchemy import select, delete, func
from sqlalchemy.orm import Session as DBSession
from sqlalchemy.exc import IntegrityError
from starlette.concurrency import run_in_threadpool
from app.core.config import settings
from app.core.security import (
    current_user,
    owned,
    hasher,
    verify_password,
    token_hash,
    new_token,
    DUMMY_HASH,
)
from app.db.session import get_db
from app.models.entities import (
    User,
    Session,
    Conversation,
    Message,
    Document,
    Task,
    Note,
    Quiz,
    QuizAttempt,
)
from app.schemas.contracts import (
    Register,
    Login,
    ProfileUpdate,
    ChatInput,
    AskInput,
    SummaryInput,
    TaskInput,
    TaskPatch,
    NoteInput,
    QuizInput,
    AttemptInput,
)
from app.services import ollama, documents, study_ai

router = APIRouter(prefix="/api")
logger = logging.getLogger(__name__)


def user_view(u):
    return {
        "id": u.id,
        "name": u.name,
        "email": u.email,
        "subject": u.subject,
        "explanation_style": u.explanation_style,
        "theme": u.theme,
    }


def row_view(row, exclude=()):
    return {
        c.name: getattr(row, c.name)
        for c in row.__table__.columns
        if c.name not in {"user_id", *exclude}
    }


def doc_view(d):
    return row_view(d, ("page_texts",))


def user_rows(db, model, user):
    return db.scalars(
        select(model).where(model.user_id == user.id).order_by(model.created_at.desc())
    ).all()


def start_session(db, user, response):
    # Remove expired sessions and cap each user's active sessions.
    db.execute(delete(Session).where(Session.expires_at < datetime.now(timezone.utc)))
    active = db.scalars(
        select(Session)
        .where(Session.user_id == user.id)
        .order_by(Session.expires_at.desc())
    ).all()
    for old in active[9:]:
        db.delete(old)
    token = new_token()
    db.add(
        Session(
            token_hash=token_hash(token),
            user_id=user.id,
            expires_at=datetime.now(timezone.utc)
            + timedelta(days=settings.session_days),
        )
    )
    db.commit()
    response.set_cookie(
        "study_session",
        token,
        httponly=True,
        secure=settings.cookie_secure,
        samesite="lax",
        max_age=settings.session_days * 86400,
        path="/",
    )


@router.post("/auth/register", status_code=201)
def register(data: Register, response: Response, db: DBSession = Depends(get_db)):
    email = str(data.email).lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "An account already exists for this email.")
    user = User(name=data.name, email=email, password_hash=hasher.hash(data.password))
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "An account already exists for this email.")
    start_session(db, user, response)
    return user_view(user)


@router.post("/auth/login")
def login(data: Login, response: Response, db: DBSession = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == str(data.email).lower()))
    valid = verify_password(data.password, user.password_hash if user else DUMMY_HASH)
    if not user or not valid:
        raise HTTPException(401, "Email or password is incorrect.")
    start_session(db, user, response)
    return user_view(user)


@router.post("/auth/logout", status_code=204)
def logout(request: Request, response: Response, db: DBSession = Depends(get_db)):
    token = request.cookies.get("study_session")
    if token:
        session = db.get(Session, token_hash(token))
        if session:
            db.delete(session)
            db.commit()
    response.delete_cookie("study_session", path="/")


@router.get("/auth/me")
def me(user: User = Depends(current_user)):
    return user_view(user)


@router.patch("/auth/me")
def profile(
    data: ProfileUpdate,
    user: User = Depends(current_user),
    db: DBSession = Depends(get_db),
):
    for key, value in data.model_dump().items():
        setattr(user, key, value)
    db.commit()
    return user_view(user)


@router.get("/health")
def health():
    return {
        "status": "ok",
        "service": "AI Study Assistant",
        "inference": "local Ollama only",
    }


@router.get("/health/ai")
async def ai_health(user: User = Depends(current_user)):
    return await ollama.status()


@router.get("/dashboard")
def dashboard(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    tasks = user_rows(db, Task, user)
    total = len(tasks)
    complete = sum(t.completed for t in tasks)
    return {
        "user": user_view(user),
        "tasks": [row_view(t) for t in tasks],
        "documents": [doc_view(d) for d in user_rows(db, Document, user)[:4]],
        "conversations": [row_view(c) for c in user_rows(db, Conversation, user)[:4]],
        "stats": {
            "tasks": total,
            "completed": complete,
            "documents": db.scalar(
                select(func.count())
                .select_from(Document)
                .where(Document.user_id == user.id)
            ),
            "notes": db.scalar(
                select(func.count()).select_from(Note).where(Note.user_id == user.id)
            ),
        },
        "demo": False,
    }


@router.get("/conversations")
def conversations(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    return [row_view(c) for c in user_rows(db, Conversation, user)]


@router.get("/conversations/{id}")
def conversation(
    id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    c = owned(db, Conversation, id, user)
    return {
        **row_view(c),
        "messages": [
            row_view(m)
            for m in db.scalars(
                select(Message)
                .where(Message.conversation_id == id)
                .order_by(Message.created_at, Message.id)
            ).all()
        ],
    }


@router.delete("/conversations/{id}", status_code=204)
def delete_conversation(
    id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    c = owned(db, Conversation, id, user)
    db.execute(delete(Message).where(Message.conversation_id == id))
    db.delete(c)
    db.commit()


@router.post("/chat")
async def chat(
    data: ChatInput, user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    c = (
        owned(db, Conversation, data.conversation_id, user)
        if data.conversation_id
        else None
    )
    history = []
    if c:
        recent = db.scalars(
            select(Message)
            .where(Message.conversation_id == c.id)
            .order_by(Message.created_at.desc())
            .limit(12)
        ).all()
        history = [
            {"role": m.role, "content": m.content[:5000]} for m in reversed(recent)
        ]
    # Keep a bounded recent context. Persisted history remains intact.
    while sum(len(m["content"]) for m in history) > 18000:
        history.pop(0)
    history.append({"role": "user", "content": data.message})
    text, metrics = await ollama.tutor(history, data.subject, data.style)
    # Persist both messages only after a real model response succeeds.
    if c and db.get(Conversation, c.id) is None:
        raise HTTPException(409, "Conversation was deleted. Start a new conversation.")
    if not c:
        c = Conversation(user_id=user.id, title=data.message[:80], subject=data.subject)
        db.add(c)
        db.flush()
    a = Message(conversation_id=c.id, role="user", content=data.message)
    b = Message(conversation_id=c.id, role="assistant", content=text)
    db.add_all([a, b])
    db.commit()
    return {"conversation_id": c.id, "message": row_view(b), "metrics": metrics}


@router.post("/documents/upload", status_code=201)
async def upload(
    file: UploadFile = File(...),
    user: User = Depends(current_user),
    db: DBSession = Depends(get_db),
):
    if (
        not file.filename
        or not file.filename.lower().endswith(".pdf")
        or file.content_type not in {"application/pdf", "application/octet-stream"}
    ):
        raise HTTPException(415, "Upload a PDF file.")
    if (
        db.scalar(
            select(func.count())
            .select_from(Document)
            .where(Document.user_id == user.id)
        )
        >= 50
    ):
        raise HTTPException(
            409,
            "The local development limit is 50 documents per account. Delete an unused document first.",
        )
    id_ = str(uuid4())
    directory = settings.storage_dir / "pdfs"
    directory.mkdir(exist_ok=True)
    path = directory / f"{id_}.pdf"
    size = 0
    try:
        with path.open("wb") as output:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > settings.max_upload_mb * 1024 * 1024:
                    raise HTTPException(
                        413, f"PDF must be smaller than {settings.max_upload_mb} MB."
                    )
                output.write(chunk)
        with path.open("rb") as source:
            if b"%PDF-" not in source.read(1024):
                raise HTTPException(
                    415, "The uploaded file does not contain a PDF header."
                )
        texts = await run_in_threadpool(documents.extract, path)
        doc = Document(
            id=id_,
            user_id=user.id,
            name=Path(file.filename.replace("\\", "/")).name[:200],
            size=size,
            pages=len(texts),
            page_texts=texts,
            status="text_ready",
            processing_message="Text extracted. Local embedding index is not ready.",
        )
        try:
            await run_in_threadpool(documents.index_document, doc)
            doc.status = "ready"
            doc.processing_message = "Text extracted and local retrieval index ready."
        except HTTPException as error:
            doc.processing_message = error.detail
        except Exception:
            logger.exception("Local indexing failed")
            doc.processing_message = "Text extracted; local indexing failed. Check dependencies and retry indexing."
        db.add(doc)
        db.commit()
        return doc_view(doc)
    except Exception:
        path.unlink(missing_ok=True)
        raise
    finally:
        await file.close()


@router.get("/documents")
def list_documents(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    return [doc_view(d) for d in user_rows(db, Document, user)]


@router.get("/documents/{id}")
def document_detail(
    id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    return doc_view(owned(db, Document, id, user))


@router.get("/documents/{id}/file")
def document_file(
    id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    doc = owned(db, Document, id, user)
    path = settings.storage_dir / "pdfs" / f"{doc.id}.pdf"
    if not path.is_file():
        raise HTTPException(404, "The stored PDF is missing.")
    return FileResponse(
        path,
        media_type="application/pdf",
        filename=doc.name,
        content_disposition_type="inline",
        headers={"X-Content-Type-Options": "nosniff"},
    )


@router.post("/documents/{id}/index")
async def reindex(
    id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    doc = owned(db, Document, id, user)
    await run_in_threadpool(documents.index_document, doc)
    doc.status = "ready"
    doc.processing_message = "Local retrieval index ready."
    db.commit()
    return doc_view(doc)


@router.delete("/documents/{id}", status_code=204)
def delete_document(
    id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    doc = owned(db, Document, id, user)
    documents.delete_index(doc)
    (settings.storage_dir / "pdfs" / f"{doc.id}.pdf").unlink(missing_ok=True)
    db.delete(doc)
    db.commit()


@router.post("/documents/{id}/ask")
async def ask_document(
    id: str,
    data: AskInput,
    user: User = Depends(current_user),
    db: DBSession = Depends(get_db),
):
    return await study_ai.ask(owned(db, Document, id, user), data.question)


@router.post("/documents/{id}/summarize")
async def summarize_document(
    id: str,
    data: SummaryInput,
    user: User = Depends(current_user),
    db: DBSession = Depends(get_db),
):
    return await study_ai.summarize(owned(db, Document, id, user), data.mode)


@router.get("/tasks")
def tasks(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    return [row_view(t) for t in user_rows(db, Task, user)]


@router.post("/tasks", status_code=201)
def create_task(
    data: TaskInput, user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    values = data.model_dump()
    values["due_date"] = data.due_date.isoformat()
    t = Task(user_id=user.id, **values)
    db.add(t)
    db.commit()
    return row_view(t)


@router.patch("/tasks/{id}")
def update_task(
    id: str,
    data: TaskPatch,
    user: User = Depends(current_user),
    db: DBSession = Depends(get_db),
):
    t = owned(db, Task, id, user)
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(t, key, value.isoformat() if key == "due_date" else value)
    db.commit()
    return row_view(t)


@router.delete("/tasks/{id}", status_code=204)
def delete_task(
    id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    db.delete(owned(db, Task, id, user))
    db.commit()


@router.get("/notes")
def notes(
    q: str = "", user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    query = select(Note).where(Note.user_id == user.id).order_by(Note.created_at.desc())
    if q:
        query = query.where(
            Note.title.contains(q, autoescape=True)
            | Note.content.contains(q, autoescape=True)
            | Note.subject.contains(q, autoescape=True)
        )
    return [row_view(n) for n in db.scalars(query).all()]


@router.post("/notes", status_code=201)
def create_note(
    data: NoteInput, user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    n = Note(user_id=user.id, **data.model_dump())
    db.add(n)
    db.commit()
    return row_view(n)


@router.patch("/notes/{id}")
def update_note(
    id: str,
    data: NoteInput,
    user: User = Depends(current_user),
    db: DBSession = Depends(get_db),
):
    n = owned(db, Note, id, user)
    for k, v in data.model_dump().items():
        setattr(n, k, v)
    db.commit()
    return row_view(n)


@router.delete("/notes/{id}", status_code=204)
def delete_note(
    id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    db.delete(owned(db, Note, id, user))
    db.commit()


def public_quiz(quiz):
    return {
        **row_view(quiz, ("questions",)),
        "questions": [
            {"question": q["question"], "options": q["options"]} for q in quiz.questions
        ],
    }


@router.post("/quizzes/generate", status_code=201)
async def generate_quiz(
    data: QuizInput, user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    document = (
        owned(db, Document, data.document_id, user)
        if data.source == "document"
        else None
    )
    questions, metrics = await study_ai.generate_quiz(data, document)
    quiz = Quiz(
        user_id=user.id,
        title=(document.name if document else data.topic or data.subject)[:200],
        questions=questions,
    )
    db.add(quiz)
    db.commit()
    return {
        **public_quiz(quiz),
        "metrics": metrics,
        "validation": "Schema and option structure validated. AI correctness requires review.",
    }


@router.get("/quizzes")
def list_quizzes(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    return [
        row_view(q, ("questions",)) | {"count": len(q.questions)}
        for q in user_rows(db, Quiz, user)
    ]


@router.get("/quizzes/{id}")
def get_quiz(
    id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)
):
    return public_quiz(owned(db, Quiz, id, user))


@router.post("/quizzes/{id}/submit")
def submit_quiz(
    id: str,
    data: AttemptInput,
    user: User = Depends(current_user),
    db: DBSession = Depends(get_db),
):
    quiz = owned(db, Quiz, id, user)
    if len(data.answers) != len(quiz.questions) or any(
        a < 0 or a > 3 for a in data.answers
    ):
        raise HTTPException(422, "Select one valid option for every question.")
    score = sum(
        answer == question["correct_index"]
        for answer, question in zip(data.answers, quiz.questions)
    )
    attempt = QuizAttempt(
        user_id=user.id, quiz_id=quiz.id, answers=data.answers, score=score
    )
    db.add(attempt)
    db.commit()
    return {
        "attempt_id": attempt.id,
        "score": score,
        "total": len(quiz.questions),
        "questions": quiz.questions,
        "answers": data.answers,
    }
