import logging, time
from collections import defaultdict, deque
from threading import Lock
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import event
from app.core.config import settings
from app.db.session import Base, engine
from app.models import entities
from app.api.routes import router

logging.basicConfig(level=logging.INFO)

if settings.database_url.startswith("sqlite"):

    @event.listens_for(engine, "connect")
    def sqlite_settings(connection, _):
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA journal_mode=WAL")


@asynccontextmanager
async def lifespan(app):
    Base.metadata.create_all(engine)
    yield


app = FastAPI(title="AI Study Assistant", version="1.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.frontend_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type"],
)
app.include_router(router)


class Throttle:
    def __init__(self):
        self.requests = defaultdict(deque)
        self.lock = Lock()

    def allow(self, key, limit, window=60):
        with self.lock:
            now = time.monotonic()
            # Bound storage and remove inactive buckets.
            for old in list(self.requests):
                if not self.requests[old] or self.requests[old][-1] < now - window:
                    del self.requests[old]
            queue = self.requests[key]
            while queue and queue[0] < now - window:
                queue.popleft()
            if len(queue) >= limit:
                return False
            queue.append(now)
            return True


throttle = Throttle()


@app.middleware("http")
async def safeguards(request: Request, call_next):
    if request.method in {"POST", "PATCH", "DELETE"}:
        origin = request.headers.get("origin")
        if origin and origin not in settings.frontend_origins:
            return JSONResponse(
                status_code=403,
                content={
                    "error": {
                        "code": "origin_denied",
                        "message": "Request origin is not allowed.",
                    }
                },
            )
        if request.headers.get("sec-fetch-site") == "cross-site" and not origin:
            return JSONResponse(
                status_code=403,
                content={
                    "error": {
                        "code": "origin_denied",
                        "message": "Cross-site request denied.",
                    }
                },
            )
        length = request.headers.get("content-length", "0")
        if not length.isdigit() or int(length) > (
            settings.max_upload_mb * 1024 * 1024 + 1024 * 1024
        ):
            return JSONResponse(
                status_code=413,
                content={
                    "error": {
                        "code": "upload_limit",
                        "message": "Request exceeds the upload limit.",
                    }
                },
            )
        ip = request.client.host if request.client else "unknown"
        path = request.url.path
        category = (
            "auth"
            if path in {"/api/auth/login", "/api/auth/register"}
            else "ai"
            if path == "/api/chat"
            or path.endswith(("/ask", "/summarize", "/index", "/generate", "/upload"))
            else "write"
        )
        if not throttle.allow(
            (ip, category),
            10 if category == "auth" else 15 if category == "ai" else 120,
        ):
            return JSONResponse(
                status_code=429,
                headers={"Retry-After": "60"},
                content={
                    "error": {
                        "code": "rate_limited",
                        "message": "Too many requests. Please wait a minute.",
                    }
                },
            )
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Cache-Control"] = "no-store"
    return response


@app.exception_handler(HTTPException)
async def http_error(request, error):
    return JSONResponse(
        status_code=error.status_code,
        content={
            "error": {"code": str(error.status_code), "message": str(error.detail)}
        },
        headers=error.headers,
    )


@app.exception_handler(RequestValidationError)
async def validation_error(request, error):
    # Do not echo rejected input, especially passwords.
    fields = [
        {"field": ".".join(str(x) for x in e["loc"][1:]), "message": e["msg"]}
        for e in error.errors()
    ]
    return JSONResponse(
        status_code=422,
        content={
            "error": {
                "code": "validation_error",
                "message": "Please check the form fields.",
                "fields": fields,
            }
        },
    )


@app.exception_handler(Exception)
async def unexpected_error(request, error):
    logging.getLogger(__name__).error("Unhandled request error", exc_info=error)
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "internal_error",
                "message": "Something went wrong. Check backend logs or try again.",
            }
        },
    )
