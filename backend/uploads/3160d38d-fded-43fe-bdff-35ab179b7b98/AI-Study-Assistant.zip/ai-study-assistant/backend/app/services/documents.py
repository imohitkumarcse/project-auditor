import threading
from functools import lru_cache
import fitz
from fastapi import HTTPException
from app.core.config import settings

INDEX_LOCK = threading.Lock()


@lru_cache(maxsize=1)
def embedding_model():
    try:
        from sentence_transformers import SentenceTransformer

        return SentenceTransformer(
            settings.embedding_model,
            local_files_only=settings.embedding_local_only,
            trust_remote_code=False,
        )
    except Exception:
        raise HTTPException(
            503,
            "Local embeddings are unavailable. Install AI dependencies and run the embedding preparation script; no external embedding API is used.",
        )


@lru_cache(maxsize=1)
def vector_client():
    try:
        import chromadb
        from chromadb.config import Settings as ChromaSettings

        return chromadb.PersistentClient(
            path=str(settings.storage_dir / "vectors"),
            settings=ChromaSettings(anonymized_telemetry=False),
        )
    except Exception:
        raise HTTPException(
            503,
            "Local Chroma storage is unavailable. Install dependencies and check storage permissions.",
        )


def extract(path):
    try:
        with fitz.open(path) as pdf:
            if pdf.needs_pass:
                raise HTTPException(
                    422,
                    "Password-protected PDFs are not supported. Upload an unlocked copy.",
                )
            if len(pdf) > 400:
                raise HTTPException(422, "PDF exceeds the 400-page limit.")
            texts = [page.get_text("text").strip() for page in pdf]
        if sum(len(x) for x in texts) < 50:
            raise HTTPException(
                422,
                "No usable text was found. This may be a scanned PDF; OCR is not installed. Upload a text-based PDF.",
            )
        if sum(len(x) for x in texts) > 2_000_000:
            raise HTTPException(422, "Extracted text exceeds the processing limit.")
        return texts
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(422, "This file could not be read as a valid PDF.")


def chunks(texts):
    result = []
    for page, text in enumerate(texts, 1):
        for start in range(0, len(text), 1000):
            part = text[start : start + 1200]
            if part.strip():
                result.append(
                    {"id": f"p{page}-c{start // 1000 + 1}", "page": page, "text": part}
                )
    return result


def index_document(document):
    entries = chunks(document.page_texts)
    model = embedding_model()
    with INDEX_LOCK:
        collection = vector_client().get_or_create_collection(
            "doc_" + document.id.replace("-", ""), metadata={"hnsw:space": "cosine"}
        )
        for start in range(0, len(entries), 64):
            batch = entries[start : start + 64]
            embeddings = model.encode(
                [e["text"] for e in batch], normalize_embeddings=True
            ).tolist()
            collection.upsert(
                ids=[e["id"] for e in batch],
                documents=[e["text"] for e in batch],
                embeddings=embeddings,
                metadatas=[
                    {"page": e["page"], "user_id": document.user_id} for e in batch
                ],
            )


def retrieve(document, question, limit=5):
    if document.status != "ready":
        raise HTTPException(
            409,
            "This document has extracted text but is not indexed. Open Documents and retry indexing after installing local embeddings.",
        )
    model = embedding_model()
    try:
        collection = vector_client().get_collection(
            "doc_" + document.id.replace("-", "")
        )
        result = collection.query(
            query_embeddings=model.encode(
                [question], normalize_embeddings=True
            ).tolist(),
            n_results=min(limit, collection.count()),
            where={"user_id": document.user_id},
        )
        return [
            {"id": id_, "page": meta["page"], "text": text}
            for id_, meta, text in zip(
                result["ids"][0], result["metadatas"][0], result["documents"][0]
            )
        ]
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(
            503, "Document index could not be read. Please reindex this document."
        )


def delete_index(document):
    # No index exists if the optional local AI dependencies have never been installed.
    try:
        client = vector_client()
        name = "doc_" + document.id.replace("-", "")
        if name in [
            c.name if hasattr(c, "name") else str(c) for c in client.list_collections()
        ]:
            client.delete_collection(name)
    except HTTPException:
        if document.status == "ready":
            raise
