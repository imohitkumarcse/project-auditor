import json, time, asyncio
import httpx
from fastapi import HTTPException
from app.core.config import settings

AI_GATE = asyncio.Semaphore(2)


def unavailable(message):
    return HTTPException(503, message)


async def status():
    try:
        async with httpx.AsyncClient(timeout=3, trust_env=False) as client:
            response = await client.get(settings.ollama_base_url + "/api/tags")
            response.raise_for_status()
            names = [x["name"] for x in response.json().get("models", [])]
        available = (
            settings.ollama_model in names or settings.ollama_model + ":latest" in names
        )
        return {
            "available": available,
            "runtime_connected": True,
            "model": settings.ollama_model,
            "message": "Local model ready."
            if available
            else f"Model {settings.ollama_model} is not installed. Import it into Ollama.",
        }
    except (httpx.HTTPError, ValueError, KeyError):
        return {
            "available": False,
            "runtime_connected": False,
            "model": settings.ollama_model,
            "message": "Ollama is offline. Start Ollama locally, then install the configured model.",
        }


async def generate(messages, schema=None):
    try:
        await asyncio.wait_for(AI_GATE.acquire(), timeout=2)
    except TimeoutError:
        raise HTTPException(429, "Local AI is busy. Please retry shortly.")
    started = time.perf_counter()
    try:
        payload = {
            "model": settings.ollama_model,
            "messages": messages,
            "stream": False,
            "options": {"temperature": 0.3, "num_ctx": 8192, "num_predict": 3000},
        }
        if schema:
            payload["format"] = schema
        async with httpx.AsyncClient(
            timeout=settings.ai_timeout_seconds, trust_env=False
        ) as client:
            response = await client.post(
                settings.ollama_base_url + "/api/chat", json=payload
            )
        if response.status_code == 404:
            raise unavailable(
                f"Model {settings.ollama_model} is not installed in Ollama."
            )
        response.raise_for_status()
        data = response.json()
        text = data.get("message", {}).get("content", "").strip()
        if not text:
            raise HTTPException(
                502, "The local model returned an empty answer. Please retry."
            )
        return text, {
            "latency_ms": round((time.perf_counter() - started) * 1000),
            "model": settings.ollama_model,
            "eval_count": data.get("eval_count"),
            "eval_duration_ns": data.get("eval_duration"),
        }
    except httpx.TimeoutException:
        raise HTTPException(
            504, "Local model timed out. Try a shorter request or a smaller model."
        )
    except httpx.HTTPError:
        raise unavailable(
            "Cannot reach the local Ollama model. Check the AI status in Settings."
        )
    except (ValueError, TypeError):
        raise HTTPException(502, "Ollama returned an invalid response.")
    finally:
        AI_GATE.release()


TUTOR_SYSTEM = (
    "You are EduLlama, a careful college study tutor. Explain accurately in Markdown. "
    "State uncertainty; never invent sources or pretend to have read documents. "
    "Help students learn rather than merely supplying unsupported claims."
)


async def tutor(history, subject, style):
    return await generate(
        [
            {
                "role": "system",
                "content": TUTOR_SYSTEM
                + f" Subject: {subject}. Answer style: {style}.",
            }
        ]
        + history
    )
