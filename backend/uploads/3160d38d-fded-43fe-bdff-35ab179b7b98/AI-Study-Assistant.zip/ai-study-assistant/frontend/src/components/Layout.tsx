import { useState } from "react";
import { NavLink, Outlet, Link } from "react-router-dom";
import {
  GraduationCap,
  LayoutDashboard,
  MessagesSquare,
  Files,
  FileText,
  ListChecks,
  CalendarDays,
  NotebookPen,
  Settings,
  LogOut,
  PanelLeftClose,
  PanelLeftOpen,
  Menu,
  X,
  ShieldCheck,
  ChevronRight,
} from "lucide-react";
import { useApp, useResource } from "../lib/state";
import type { AIStatus } from "../types";
const links = [
  ["/", "Overview", LayoutDashboard],
  ["/tutor", "AI tutor", MessagesSquare],
  ["/documents", "My documents", Files],
  ["/summaries", "Summarizer", FileText],
  ["/quizzes", "Practice quizzes", ListChecks],
  ["/planner", "Study planner", CalendarDays],
  ["/notes", "Saved notes", NotebookPen],
] as const;
export default function Layout() {
  const { user, signOut } = useApp();
  const [collapsed, setCollapsed] = useState(false),
    [mobile, setMobile] = useState(false);
  const status = useResource<AIStatus>("/health/ai");
  return (
    <div className={`app-shell ${collapsed ? "sidebar-collapsed" : ""}`}>
      <a href="#main-content" className="skip-link">
        Skip to content
      </a>
      {mobile && (
        <button
          className="sidebar-overlay"
          aria-label="Close navigation"
          onClick={() => setMobile(false)}
        />
      )}
      <aside className={`sidebar ${mobile ? "mobile-open" : ""}`}>
        <Link to="/" className="brand">
          <div className="brand-mark">
            <GraduationCap size={25} />
          </div>
          <span>
            EduLlama<small>YOUR STUDY COMPANION</small>
          </span>
        </Link>
        <button
          className="mobile-close icon-button"
          onClick={() => setMobile(false)}
          aria-label="Close menu"
        >
          <X size={20} />
        </button>
        <p className="nav-label">WORKSPACE</p>
        <nav aria-label="Main navigation">
          {links.map(([to, label, Icon]) => (
            <NavLink
              key={to}
              to={to}
              end={to === "/"}
              title={collapsed ? label : undefined}
              onClick={() => setMobile(false)}
              className={({ isActive }) =>
                `nav-link ${isActive ? "active" : ""}`
              }
            >
              <Icon size={20} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="local-card">
            <ShieldCheck size={21} />
            <strong>Local-first learning</strong>
            <p>Your AI runs on your machine. No hosted inference APIs.</p>
            <Link to="/settings">
              Connection settings <ChevronRight size={14} />
            </Link>
          </div>
          <NavLink
            className="nav-link"
            to="/settings"
            onClick={() => setMobile(false)}
          >
            <Settings size={20} />
            <span>Settings</span>
          </NavLink>
          <button
            className="nav-link collapse-control"
            onClick={() => setCollapsed(!collapsed)}
          >
            {collapsed ? (
              <PanelLeftOpen size={20} />
            ) : (
              <PanelLeftClose size={20} />
            )}
            <span>Collapse sidebar</span>
          </button>
        </div>
      </aside>
      <div className="workspace">
        <header className="topbar">
          <div className="topbar-location">
            <button
              className="icon-button mobile-menu"
              aria-label="Open navigation"
              onClick={() => setMobile(true)}
            >
              <Menu size={22} />
            </button>
            <GraduationCap size={18} />
            <span>My learning workspace</span>
          </div>
          <div className="topbar-actions">
            <Link
              to="/settings"
              className={`status-pill ${status.data?.available ? "online" : "offline"}`}
            >
              <span className="status-dot" />
              {status.loading
                ? "Checking AI…"
                : status.error
                  ? "Backend unavailable"
                  : status.data?.available
                    ? "Local AI ready"
                    : "Local AI offline"}
            </Link>
            <div className="avatar" aria-label={user?.name}>
              {user?.name.charAt(0).toUpperCase()}
            </div>
            <button
              className="icon-button"
              title="Sign out"
              aria-label="Sign out"
              onClick={() => void signOut()}
            >
              <LogOut size={18} />
            </button>
          </div>
        </header>
        <main id="main-content" className="main-content">
          <Outlet />
        </main>
        <footer className="workspace-footer">
          <span>Learn at your pace. Keep your data local.</span>
          <span>EduLlama · AI Study Assistant</span>
        </footer>
      </div>
    </div>
  );
}
