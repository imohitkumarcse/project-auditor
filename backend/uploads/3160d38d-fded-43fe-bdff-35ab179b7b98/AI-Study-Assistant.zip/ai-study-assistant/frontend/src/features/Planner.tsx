import { useState, type FormEvent } from "react";
import {
  Plus,
  Pencil,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Clock,
  CalendarDays,
} from "lucide-react";
import { api, json, subjects, localDate, displayDate } from "../lib/api";
import { useResource, useApp } from "../lib/state";
import type { Task } from "../types";
import {
  Heading,
  Button,
  Field,
  Modal,
  Loading,
  ErrorBox,
  Empty,
} from "../components/ui";
export default function Planner() {
  const tasks = useResource<Task[]>("/tasks");
  const { notify } = useApp();
  const [view, setView] = useState<"day" | "week" | "all" | "revision">("week"),
    [date, setDate] = useState(localDate()),
    [editing, setEditing] = useState<Task | null | undefined>(undefined),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const start = new Date(date + "T12:00:00"),
    weekStart = new Date(start);
  weekStart.setDate(start.getDate() - ((start.getDay() + 6) % 7));
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekStart.getDate() + 6);
  const filtered = (tasks.data || [])
    .filter(
      (t) =>
        view === "all" ||
        (view === "revision" && t.revision) ||
        (view === "day" && t.due_date === date) ||
        (view === "week" &&
          t.due_date >= localDate(weekStart) &&
          t.due_date <= localDate(weekEnd)),
    )
    .sort(
      (a, b) =>
        a.due_date.localeCompare(b.due_date) ||
        Number(a.completed) - Number(b.completed),
    );
  const done = filtered.filter((t) => t.completed).length;
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const body = {
      title: f.get("title"),
      subject: f.get("subject"),
      priority: f.get("priority"),
      due_date: f.get("due_date"),
      duration: Number(f.get("duration")),
      revision: f.get("revision") === "on",
    };
    setBusy(true);
    setError("");
    try {
      await api(
        editing ? `/tasks/${editing.id}` : "/tasks",
        json(editing ? "PATCH" : "POST", body),
      );
      setEditing(undefined);
      await tasks.reload();
      notify(editing ? "Study session updated." : "Study session created.");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function toggle(t: Task) {
    try {
      await api(`/tasks/${t.id}`, json("PATCH", { completed: !t.completed }));
      await tasks.reload();
    } catch (e) {
      notify((e as Error).message, true);
    }
  }
  async function remove(t: Task) {
    if (!confirm("Delete this study session?")) return;
    try {
      await api(`/tasks/${t.id}`, json("DELETE"));
      await tasks.reload();
      notify("Study session deleted.");
    } catch (e) {
      notify((e as Error).message, true);
    }
  }
  function move(direction: number) {
    const d = new Date(date + "T12:00:00");
    d.setDate(d.getDate() + direction * (view === "week" ? 7 : 1));
    setDate(localDate(d));
  }
  return (
    <>
      <Heading
        eyebrow="SMALL STEPS. STEADY PROGRESS."
        title="Study planner"
        description="Give your goals a place in your day."
        action={
          <Button
            onClick={() => {
              setEditing(null);
              setError("");
            }}
          >
            <Plus size={17} />
            Add study session
          </Button>
        }
      />
      <div className="planner-summary">
        <div>
          <CalendarDays size={24} />
          <div>
            <strong>{filtered.length} planned sessions</strong>
            <span>
              {view === "week"
                ? "This week"
                : view === "day"
                  ? "Selected day"
                  : view === "revision"
                    ? "Revision checklist"
                    : "All sessions"}
            </span>
          </div>
        </div>
        <div>
          <Clock size={24} />
          <div>
            <strong>
              {filtered
                .filter((t) => !t.completed)
                .reduce((s, t) => s + t.duration, 0)}{" "}
              minutes
            </strong>
            <span>Remaining study time</span>
          </div>
        </div>
        <div>
          <strong>
            {done} / {filtered.length}
          </strong>
          <span>Sessions completed</span>
          <progress
            value={done}
            max={filtered.length || 1}
            aria-label="Completed sessions"
          />
        </div>
      </div>
      <div className="planner-toolbar">
        <div className="segmented" aria-label="Planner view">
          {(["day", "week", "all", "revision"] as const).map((v) => (
            <button
              key={v}
              className={v === view ? "active" : ""}
              onClick={() => setView(v)}
              aria-pressed={v === view}
            >
              {v === "revision"
                ? "Revision"
                : v.charAt(0).toUpperCase() + v.slice(1)}
            </button>
          ))}
        </div>
        {(view === "day" || view === "week") && (
          <div className="date-controls">
            <button
              className="icon-button"
              aria-label="Previous period"
              onClick={() => move(-1)}
            >
              <ChevronLeft size={18} />
            </button>
            <label>
              <span className="sr-only">Selected date</span>
              <input
                type="date"
                value={date}
                onChange={(e) => {
                  if (e.target.value) setDate(e.target.value);
                }}
              />
            </label>
            <button
              className="icon-button"
              aria-label="Next period"
              onClick={() => move(1)}
            >
              <ChevronRight size={18} />
            </button>
            <button
              className="text-button"
              onClick={() => setDate(localDate())}
            >
              Today
            </button>
          </div>
        )}
      </div>
      {tasks.loading ? (
        <Loading />
      ) : tasks.error ? (
        <ErrorBox message={tasks.error} retry={() => void tasks.reload()} />
      ) : (
        <section className="card planner-list">
          {view === "week" && (
            <p className="eyebrow">
              {displayDate(localDate(weekStart))} –{" "}
              {displayDate(localDate(weekEnd))}
            </p>
          )}
          {filtered.length ? (
            filtered.map((task) => (
              <div
                className={`planner-task ${task.completed ? "done" : ""}`}
                key={task.id}
              >
                <input
                  type="checkbox"
                  checked={task.completed}
                  onChange={() => void toggle(task)}
                  aria-label={`Mark ${task.title} ${task.completed ? "incomplete" : "complete"}`}
                />
                <div className="planner-task-content">
                  <strong>{task.title}</strong>
                  <div>
                    <span>{task.subject}</span>
                    <span>{displayDate(task.due_date)}</span>
                    <span>
                      <Clock size={13} />
                      {task.duration} min
                    </span>
                    {task.revision && <span className="badge">Revision</span>}
                  </div>
                </div>
                <span className={`badge priority-${task.priority}`}>
                  {task.priority}
                </span>
                <button
                  className="icon-button"
                  aria-label={`Edit ${task.title}`}
                  onClick={() => {
                    setEditing(task);
                    setError("");
                  }}
                >
                  <Pencil size={16} />
                </button>
                <button
                  className="icon-button danger-text"
                  aria-label={`Delete ${task.title}`}
                  onClick={() => void remove(task)}
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))
          ) : (
            <Empty
              title="Make a little room for learning"
              description="No sessions in this view. Add a focused study session or check another day."
              action={
                <Button className="secondary" onClick={() => setEditing(null)}>
                  <Plus size={16} />
                  Add a session
                </Button>
              }
            />
          )}
        </section>
      )}
      {editing !== undefined && (
        <Modal
          title={editing ? "Edit study session" : "Plan a study session"}
          onClose={() => {
            if (!busy) setEditing(undefined);
          }}
        >
          {error && <ErrorBox message={error} />}
          <form onSubmit={submit}>
            <Field label="What will you study?">
              <input
                autoFocus
                name="title"
                defaultValue={editing?.title || ""}
                placeholder="e.g. Practice binary search problems"
                maxLength={200}
                required
              />
            </Field>
            <div className="form-grid">
              <Field label="Subject">
                <select
                  name="subject"
                  defaultValue={editing?.subject || "Python"}
                >
                  {subjects.map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </Field>
              <Field label="Priority">
                <select
                  name="priority"
                  defaultValue={editing?.priority || "medium"}
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </Field>
              <Field label="Due date">
                <input
                  name="due_date"
                  type="date"
                  defaultValue={editing?.due_date || date}
                  required
                />
              </Field>
              <Field label="Duration (minutes)">
                <input
                  name="duration"
                  type="number"
                  min={5}
                  max={600}
                  defaultValue={editing?.duration || 30}
                  required
                />
              </Field>
            </div>
            <label className="checkbox-label">
              <input
                name="revision"
                type="checkbox"
                defaultChecked={editing?.revision || false}
              />
              Add to revision checklist
            </label>
            <div className="form-actions">
              <Button
                className="secondary"
                type="button"
                onClick={() => setEditing(undefined)}
                disabled={busy}
              >
                Cancel
              </Button>
              <Button type="submit" busy={busy}>
                Save session
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </>
  );
}
