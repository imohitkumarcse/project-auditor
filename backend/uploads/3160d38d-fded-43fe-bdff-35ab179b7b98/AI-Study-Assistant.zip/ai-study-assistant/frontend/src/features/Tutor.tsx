import { useEffect, useRef, useState, type FormEvent } from "react";
import { useSearchParams } from "react-router-dom";
import {
  Plus,
  Trash2,
  Send,
  Copy,
  Bookmark,
  GraduationCap,
  Sparkles,
  MessagesSquare,
} from "lucide-react";
import { api, json, subjects, styles } from "../lib/api";
import { useApp, useResource } from "../lib/state";
import type { Conversation, Message } from "../types";
import {
  Heading,
  Button,
  Field,
  ErrorBox,
  Markdown,
  Loading,
} from "../components/ui";
export default function Tutor() {
  const { user, notify } = useApp();
  const history = useResource<Conversation[]>("/conversations");
  const [params, setParams] = useSearchParams();
  const [id, setId] = useState<string | null>(params.get("conversation")),
    [messages, setMessages] = useState<Message[]>([]),
    [text, setText] = useState(""),
    [subject, setSubject] = useState(user?.subject || "Python"),
    [style, setStyle] = useState(user?.explanation_style || "beginner"),
    [busy, setBusy] = useState(false),
    [loading, setLoading] = useState(false),
    [error, setError] = useState("");
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const selected = params.get("conversation");
    setId(selected);
    if (!selected) {
      setMessages([]);
      return;
    }
    let active = true;
    setLoading(true);
    api<Conversation>(`/conversations/${selected}`)
      .then((c) => {
        if (active) {
          setMessages(c.messages || []);
          setSubject(c.subject);
        }
      })
      .catch((e) => {
        if (active) setError(e.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [params]);
  useEffect(() => {
    if (messages.length || busy)
      end.current?.scrollIntoView({ behavior: "auto", block: "nearest" });
  }, [messages, busy]);
  async function send(e: FormEvent) {
    e.preventDefault();
    if (!text.trim() || busy) return;
    setBusy(true);
    setError("");
    const prompt = text.trim();
    try {
      const result = await api<{ conversation_id: string; message: Message }>(
        "/chat",
        json("POST", { message: prompt, conversation_id: id, subject, style }),
      );
      setMessages((old) => [
        ...old,
        { id: crypto.randomUUID(), role: "user", content: prompt },
        result.message,
      ]);
      setId(result.conversation_id);
      if (!id) setParams({ conversation: result.conversation_id });
      setText("");
      void history.reload();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function remove(conversation: Conversation) {
    if (!window.confirm("Delete this conversation and all its messages?"))
      return;
    try {
      await api(`/conversations/${conversation.id}`, json("DELETE"));
      if (id === conversation.id) {
        setParams({});
        setMessages([]);
      }
      await history.reload();
    } catch (e) {
      notify((e as Error).message, true);
    }
  }
  async function save(message: Message) {
    try {
      await api(
        "/notes",
        json("POST", {
          title: message.content.slice(0, 70),
          content: message.content,
          subject,
        }),
      );
      notify("Response saved to your notes.");
    } catch (e) {
      notify((e as Error).message, true);
    }
  }
  async function copy(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      notify("Response copied.");
    } catch {
      notify("Clipboard access is unavailable in this browser.", true);
    }
  }
  return (
    <>
      <Heading
        eyebrow="MAKE THE COMPLEX FEEL SIMPLE"
        title="Your AI tutor"
        description="A patient learning partner, powered by your local Ollama model."
      />
      <div className="tutor-layout">
        <aside className="card conversation-sidebar">
          <Button
            className="secondary full-width"
            disabled={busy}
            onClick={() => {
              setParams({});
              setMessages([]);
              setError("");
            }}
          >
            <Plus size={17} />
            New conversation
          </Button>
          <p className="nav-label">YOUR CONVERSATIONS</p>
          {history.error && <ErrorBox message={history.error} />}
          <div className="history-list">
            {history.data?.map((c) => (
              <div
                className={`history-item ${c.id === id ? "selected" : ""}`}
                key={c.id}
              >
                <button
                  disabled={busy}
                  onClick={() => {
                    setParams({ conversation: c.id });
                    setError("");
                  }}
                >
                  <MessagesSquare size={16} />
                  <span>{c.title}</span>
                </button>
                <button
                  disabled={busy}
                  aria-label={`Delete ${c.title}`}
                  className="icon-button"
                  onClick={() => void remove(c)}
                >
                  <Trash2 size={15} />
                </button>
              </div>
            ))}
          </div>
          {!history.loading && !history.data?.length && (
            <p className="muted small">
              Your conversations will appear here after a successful AI
              response.
            </p>
          )}
          <div className="tutor-local-note">
            <GraduationCap size={22} />
            <strong>Designed for understanding</strong>
            <p>
              AI can make mistakes. Verify important facts with your course
              materials.
            </p>
          </div>
        </aside>
        <section className="card chat-panel">
          <div className="chat-controls">
            <Field label="Subject">
              <select
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                disabled={busy}
              >
                {subjects.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </Field>
            <Field label="Explanation style">
              <select
                value={style}
                onChange={(e) => setStyle(e.target.value)}
                disabled={busy}
              >
                {styles.map(([v, l]) => (
                  <option key={v} value={v}>
                    {l}
                  </option>
                ))}
              </select>
            </Field>
          </div>
          <div className="chat-messages">
            {loading ? (
              <Loading />
            ) : messages.length ? (
              messages.map((m) => (
                <div className={`message ${m.role}`} key={m.id}>
                  <div className="message-avatar">
                    {m.role === "assistant" ? (
                      <GraduationCap size={18} />
                    ) : (
                      user?.name.charAt(0)
                    )}
                  </div>
                  <div className="message-body">
                    <strong>
                      {m.role === "assistant" ? "EduLlama" : "You"}
                    </strong>
                    <Markdown text={m.content} />
                    {m.role === "assistant" && (
                      <div className="message-actions">
                        <button onClick={() => void copy(m.content)}>
                          <Copy size={14} />
                          Copy
                        </button>
                        <button onClick={() => void save(m)}>
                          <Bookmark size={14} />
                          Save to notes
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="chat-empty">
                <div className="tutor-emblem">
                  <GraduationCap size={34} />
                </div>
                <span className="eyebrow">NO QUESTION IS TOO SMALL</span>
                <h2>
                  What would you like
                  <br />
                  to understand today?
                </h2>
                <p>
                  Choose a subject and an explanation style.
                  <br />
                  Then let your curiosity lead the way.
                </p>
                <div className="prompt-grid">
                  {[
                    "Explain recursion with a simple example",
                    "How does database normalization work?",
                    "Help me understand binary search",
                    "Give me a step-by-step study strategy",
                  ].map((p) => (
                    <button onClick={() => setText(p)} key={p}>
                      <Sparkles size={16} />
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {busy && <Loading label="Your local model is thinking…" />}
            <div ref={end} />
          </div>
          {error && <ErrorBox message={error} />}
          <form className="chat-compose" onSubmit={send}>
            <label className="sr-only" htmlFor="tutor-message">
              Your question
            </label>
            <textarea
              id="tutor-message"
              value={text}
              maxLength={6000}
              onChange={(e) => setText(e.target.value)}
              placeholder="Ask a question. Find a new way to understand."
              rows={2}
              required
              disabled={busy || loading}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  e.currentTarget.form?.requestSubmit();
                }
              }}
            />
            <Button
              busy={busy}
              disabled={!text.trim() || loading}
              aria-label="Send message"
              type="submit"
            >
              <Send size={19} />
            </Button>
          </form>
          <div className="chat-footnote">
            Local inference only · Responses are not streamed in this version ·
            Shift + Enter for a new line
          </div>
        </section>
      </div>
    </>
  );
}
