import { useState, type FormEvent } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import {
  GraduationCap,
  ArrowRight,
  BookOpen,
  ShieldCheck,
  Check,
} from "lucide-react";
import { useApp } from "../lib/state";
import { api, json } from "../lib/api";
import type { User } from "../types";
import { Button, Field, ErrorBox } from "../components/ui";
export default function Auth({ register = false }: { register?: boolean }) {
  const { user, setUser, authError } = useApp();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  if (user) return <Navigate to="/" replace />;
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    setBusy(true);
    setError("");
    try {
      const body = {
        email: form.get("email"),
        password: form.get("password"),
        ...(register ? { name: form.get("name") } : {}),
      };
      setUser(
        await api<User>(
          register ? "/auth/register" : "/auth/login",
          json("POST", body),
        ),
      );
      navigate("/");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="auth-page">
      <section className="auth-story">
        <div className="brand">
          <div className="brand-mark">
            <GraduationCap size={28} />
          </div>
          <span>
            EduLlama<small>YOUR STUDY COMPANION</small>
          </span>
        </div>
        <div className="auth-story-content">
          <span className="tag">A little clarity. A lot of possibility.</span>
          <h1>
            Make room for
            <br />
            your next
            <br />
            <span>breakthrough.</span>
          </h1>
          <p>
            A thoughtful workspace to understand difficult concepts, turn your
            materials into practice, and build a study rhythm that lasts.
          </p>
          <div className="auth-features">
            <div>
              <Check size={18} />
              Learn with your own local AI tutor
            </div>
            <div>
              <Check size={18} />
              Bring your notes and PDFs together
            </div>
            <div>
              <Check size={18} />
              Make steady progress, one session at a time
            </div>
          </div>
          <div className="auth-quote">
            <BookOpen size={24} />
            <p>Better understanding starts with better questions.</p>
            <small>BUILT FOR CURIOUS MINDS</small>
          </div>
        </div>
        <div className="auth-local">
          <ShieldCheck size={18} />
          Local AI. No paid inference API.
        </div>
      </section>
      <section className="auth-form-area">
        <div className="auth-form">
          <p className="eyebrow">YOUR NEXT CHAPTER</p>
          <h2>{register ? "Create your workspace" : "Welcome back"}</h2>
          <p className="muted">
            {register
              ? "Start learning with more focus and less friction."
              : "Your notes, plans, and next big idea are waiting."}
          </p>
          {(error || authError) && <ErrorBox message={error || authError} />}
          <form onSubmit={submit}>
            {register && (
              <Field label="Full name">
                <input
                  name="name"
                  autoComplete="name"
                  minLength={2}
                  maxLength={80}
                  placeholder="Your name"
                  required
                />
              </Field>
            )}
            <Field label="Email address">
              <input
                type="email"
                name="email"
                autoComplete="email"
                placeholder="you@college.edu"
                required
              />
            </Field>
            <Field
              label="Password"
              hint={register ? "Use at least 10 characters." : ""}
            >
              <input
                type="password"
                name="password"
                minLength={register ? 10 : 1}
                maxLength={128}
                autoComplete={register ? "new-password" : "current-password"}
                required
                placeholder={
                  register ? "Create a strong password" : "Enter your password"
                }
              />
            </Field>
            <Button busy={busy} className="full-width" type="submit">
              {register ? "Create account" : "Sign in"}
              <ArrowRight size={18} />
            </Button>
          </form>
          <p className="auth-switch">
            {register ? "Already have an account?" : "New to EduLlama?"}{" "}
            <Link to={register ? "/login" : "/register"}>
              {register ? "Sign in" : "Create an account"}
            </Link>
          </p>
          <p className="privacy-note">
            <ShieldCheck size={16} />
            Passwords are hashed. Your workspace is private to your account.
          </p>
        </div>
      </section>
    </div>
  );
}
