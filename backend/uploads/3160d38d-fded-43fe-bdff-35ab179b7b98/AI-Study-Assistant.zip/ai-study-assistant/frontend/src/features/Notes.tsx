import { useState, type FormEvent } from "react";
import { Plus, Search, Pencil, Trash2, NotebookPen } from "lucide-react";
import { api, json, subjects } from "../lib/api";
import { useResource, useApp } from "../lib/state";
import type { Note } from "../types";
import {
  Heading,
  Button,
  Field,
  Modal,
  Empty,
  ErrorBox,
  Loading,
  Markdown,
} from "../components/ui";
export default function Notes() {
  const notes = useResource<Note[]>("/notes");
  const { notify } = useApp();
  const [search, setSearch] = useState(""),
    [subject, setSubject] = useState("all"),
    [editing, setEditing] = useState<Note | null | undefined>(undefined),
    [selected, setSelected] = useState<Note | null>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const filtered = (notes.data || []).filter(
    (n) =>
      (subject === "all" || n.subject === subject) &&
      `${n.title} ${n.content} ${n.subject}`
        .toLowerCase()
        .includes(search.toLowerCase()),
  );
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    setBusy(true);
    setError("");
    try {
      const n = await api<Note>(
        editing ? `/notes/${editing.id}` : "/notes",
        json(editing ? "PATCH" : "POST", {
          title: form.get("title"),
          subject: form.get("subject"),
          content: form.get("content"),
        }),
      );
      setEditing(undefined);
      setSelected(n);
      await notes.reload();
      notify("Note saved.");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function remove(note: Note) {
    if (!confirm("Delete this note?")) return;
    try {
      await api(`/notes/${note.id}`, json("DELETE"));
      if (selected?.id === note.id) setSelected(null);
      await notes.reload();
      notify("Note deleted.");
    } catch (e) {
      notify((e as Error).message, true);
    }
  }
  return (
    <>
      <Heading
        eyebrow="IDEAS WORTH COMING BACK TO"
        title="Saved notes"
        description="Keep explanations, revision notes, and your own insights in one place."
        action={
          <Button
            onClick={() => {
              setEditing(null);
              setError("");
            }}
          >
            <Plus size={17} />
            New note
          </Button>
        }
      />
      <div className="notes-toolbar">
        <label className="search-field">
          <Search size={19} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search your saved material…"
            aria-label="Search notes"
          />
        </label>
        <label>
          <span className="sr-only">Filter by subject</span>
          <select value={subject} onChange={(e) => setSubject(e.target.value)}>
            <option value="all">All subjects</option>
            {subjects.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </label>
      </div>
      {notes.loading ? (
        <Loading />
      ) : notes.error ? (
        <ErrorBox message={notes.error} retry={() => void notes.reload()} />
      ) : !filtered.length ? (
        <div className="card">
          <Empty
            title={
              notes.data?.length
                ? "No matching notes"
                : "A home for your understanding"
            }
            description={
              notes.data?.length
                ? "Try a different search or subject."
                : "Create a note, or save a useful answer from your AI tutor."
            }
          />
        </div>
      ) : (
        <div className="notes-grid">
          {filtered.map((note) => (
            <article className="card note-card" key={note.id}>
              <div className="card-heading">
                <span className="badge">{note.subject}</span>
                <NotebookPen size={18} className="muted" />
              </div>
              <button className="note-open" onClick={() => setSelected(note)}>
                <h2>{note.title}</h2>
                <p>
                  {note.content.replace(/[#*`]/g, "").slice(0, 180)}
                  {note.content.length > 180 ? "…" : ""}
                </p>
              </button>
              <div className="note-footer">
                <small>{new Date(note.created_at).toLocaleDateString()}</small>
                <div>
                  <button
                    className="icon-button"
                    aria-label={`Edit ${note.title}`}
                    onClick={() => {
                      setEditing(note);
                      setError("");
                    }}
                  >
                    <Pencil size={16} />
                  </button>
                  <button
                    className="icon-button"
                    aria-label={`Delete ${note.title}`}
                    onClick={() => void remove(note)}
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
      {selected && editing === undefined && (
        <Modal title={selected.title} onClose={() => setSelected(null)}>
          <span className="badge">{selected.subject}</span>
          <Markdown text={selected.content} />
          <Button className="secondary" onClick={() => setEditing(selected)}>
            <Pencil size={16} />
            Edit note
          </Button>
        </Modal>
      )}
      {editing !== undefined && (
        <Modal
          title={editing ? "Edit note" : "Create a note"}
          onClose={() => {
            if (!busy) setEditing(undefined);
          }}
        >
          {error && <ErrorBox message={error} />}
          <form onSubmit={submit}>
            <Field label="Title">
              <input
                autoFocus
                name="title"
                defaultValue={editing?.title || ""}
                maxLength={200}
                required
                placeholder="Give this idea a name"
              />
            </Field>
            <Field label="Subject">
              <select
                name="subject"
                defaultValue={editing?.subject || "General"}
              >
                {subjects.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </Field>
            <Field label="Your notes" hint="Markdown is supported.">
              <textarea
                name="content"
                rows={10}
                defaultValue={editing?.content || ""}
                maxLength={50000}
                required
                placeholder="Explain it in your own words…"
              />
            </Field>
            <div className="form-actions">
              <Button
                className="secondary"
                type="button"
                onClick={() => setEditing(undefined)}
                disabled={busy}
              >
                Cancel
              </Button>
              <Button type="submit" busy={busy}>
                Save note
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </>
  );
}
