import { useState, type FormEvent } from "react";
import { Link } from "react-router-dom";
import {
  ListChecks,
  Sparkles,
  CheckCircle2,
  XCircle,
  RotateCcw,
} from "lucide-react";
import { api, json, subjects } from "../lib/api";
import { useApp, useResource } from "../lib/state";
import type { Document, Quiz, QuizReview } from "../types";
import {
  Heading,
  Button,
  Field,
  ErrorBox,
  Empty,
  Loading,
} from "../components/ui";
export default function Quizzes() {
  const docs = useResource<Document[]>("/documents");
  const saved =
    useResource<{ id: string; title: string; count: number }[]>("/quizzes");
  const { notify } = useApp();
  const [source, setSource] = useState("topic"),
    [quiz, setQuiz] = useState<Quiz | null>(null),
    [answers, setAnswers] = useState<number[]>([]),
    [review, setReview] = useState<QuizReview | null>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  async function generate(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    setBusy(true);
    setError("");
    try {
      const q = await api<Quiz>(
        "/quizzes/generate",
        json("POST", {
          source,
          subject: form.get("subject") || "Python",
          topic: form.get("topic") || "",
          document_id: form.get("document_id") || null,
          count: Number(form.get("count")),
          difficulty: form.get("difficulty"),
        }),
      );
      setQuiz(q);
      setAnswers(q.questions.map(() => -1));
      setReview(null);
      void saved.reload();
      notify(
        "Quiz generated and structurally validated. Review important answers against your course materials.",
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function submit() {
    if (!quiz) return;
    setBusy(true);
    setError("");
    try {
      setReview(
        await api<QuizReview>(
          `/quizzes/${quiz.id}/submit`,
          json("POST", { answers }),
        ),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function open(id: string) {
    setBusy(true);
    setError("");
    try {
      const q = await api<Quiz>(`/quizzes/${id}`);
      setQuiz(q);
      setAnswers(q.questions.map(() => -1));
      setReview(null);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Heading
        eyebrow="TURN UNDERSTANDING INTO CONFIDENCE"
        title="Practice quizzes"
        description="Test what you know. Learn from what you miss."
      />
      {error && <ErrorBox message={error} />}
      {quiz ? (
        <section className="quiz-session">
          <div className="card quiz-intro">
            <div>
              <span className="eyebrow">
                {review ? "YOUR RESULTS" : "PRACTICE SESSION"}
              </span>
              <h2>{quiz.title}</h2>
              <p className="muted">
                {review
                  ? `${review.score} of ${review.total} correct · ${Math.round((review.score / review.total) * 100)}%`
                  : `${quiz.questions.length} questions · ${answers.filter((a) => a >= 0).length} answered`}
              </p>
            </div>
            <Button
              className="secondary"
              disabled={busy}
              onClick={() => {
                setQuiz(null);
                setReview(null);
              }}
            >
              <RotateCcw size={16} />
              Back to quizzes
            </Button>
          </div>
          {quiz.questions.map((q, i) => (
            <article className="card quiz-question" key={i}>
              <span className="eyebrow">
                QUESTION {i + 1} OF {quiz.questions.length}
              </span>
              <h3>{q.question}</h3>
              <fieldset disabled={busy || !!review}>
                <legend className="sr-only">Answer question {i + 1}</legend>
                {q.options.map((option, j) => (
                  <label
                    key={j}
                    className={`quiz-option ${answers[i] === j ? "selected" : ""} ${review && review.questions[i].correct_index === j ? "correct" : ""} ${review && answers[i] === j && review.questions[i].correct_index !== j ? "incorrect" : ""}`}
                  >
                    <input
                      type="radio"
                      name={`question-${i}`}
                      checked={answers[i] === j}
                      onChange={() =>
                        setAnswers((old) =>
                          old.map((a, k) => (k === i ? j : a)),
                        )
                      }
                    />
                    <span className="option-letter">
                      {String.fromCharCode(65 + j)}
                    </span>
                    <span>{option}</span>
                    {review && review.questions[i].correct_index === j && (
                      <CheckCircle2 size={18} />
                    )}
                  </label>
                ))}
              </fieldset>
              {review && (
                <div
                  className={`quiz-explanation ${answers[i] === review.questions[i].correct_index ? "answer-correct" : "answer-incorrect"}`}
                >
                  <strong>
                    {answers[i] === review.questions[i].correct_index ? (
                      <CheckCircle2 size={17} />
                    ) : (
                      <XCircle size={17} />
                    )}{" "}
                    {answers[i] === review.questions[i].correct_index
                      ? "Correct"
                      : "Review this one"}
                  </strong>
                  <p>{review.questions[i].explanation}</p>
                </div>
              )}
            </article>
          ))}
          {!review && (
            <Button
              busy={busy}
              disabled={answers.some((a) => a < 0)}
              onClick={() => void submit()}
            >
              Check my answers
            </Button>
          )}
          <p className="muted small">
            AI-generated questions are structurally validated, not independently
            verified for academic correctness.
          </p>
        </section>
      ) : (
        <div className="quiz-layout">
          <form className="card quiz-config" onSubmit={generate}>
            <h2>Create a practice quiz</h2>
            <Field label="Build a quiz from">
              <select
                value={source}
                onChange={(e) => setSource(e.target.value)}
                disabled={busy}
              >
                <option value="topic">A topic</option>
                <option value="subject">A subject</option>
                <option value="document">An uploaded PDF</option>
              </select>
            </Field>
            {source === "document" ? (
              <Field label="Document">
                <select name="document_id" required disabled={busy}>
                  <option value="">Select an indexed PDF</option>
                  {docs.data
                    ?.filter((d) => d.status === "ready")
                    .map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name}
                      </option>
                    ))}
                </select>
                {!docs.data?.some((d) => d.status === "ready") && (
                  <p className="muted small">
                    No indexed PDFs yet.{" "}
                    <Link className="text-link" to="/documents">
                      Upload or index a PDF
                    </Link>
                  </p>
                )}
              </Field>
            ) : (
              <Field label="Subject">
                <select name="subject" disabled={busy}>
                  {subjects.map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </Field>
            )}
            {source === "topic" && (
              <Field label="Topic">
                <input
                  name="topic"
                  placeholder="e.g. Recursion and the call stack"
                  maxLength={500}
                  required
                  disabled={busy}
                />
              </Field>
            )}
            <div className="form-grid">
              <Field label="Questions">
                <input
                  type="number"
                  name="count"
                  min={1}
                  max={15}
                  defaultValue={5}
                  required
                  disabled={busy}
                />
              </Field>
              <Field label="Difficulty">
                <select name="difficulty" defaultValue="medium" disabled={busy}>
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </Field>
            </div>
            <Button type="submit" className="full-width" busy={busy}>
              <Sparkles size={17} />
              Generate quiz
            </Button>
            <p className="muted small">
              Generated by local Ollama. Failed validation never saves a quiz.
              PDF quizzes cover retrieved excerpts.
            </p>
          </form>
          <section className="card">
            <h2>Your practice library</h2>
            {saved.loading ? (
              <Loading />
            ) : saved.error ? (
              <ErrorBox message={saved.error} />
            ) : saved.data?.length ? (
              <div className="saved-quiz-list">
                {saved.data.map((q) => (
                  <button
                    key={q.id}
                    onClick={() => void open(q.id)}
                    disabled={busy}
                  >
                    <ListChecks size={22} />
                    <div>
                      <strong>{q.title}</strong>
                      <small>{q.count} questions · Start a fresh attempt</small>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <Empty
                title="Practice makes understanding stick"
                description="Create your first quiz. Saved quizzes stay here for another round."
                action={<ListChecks size={26} className="muted" />}
              />
            )}
          </section>
        </div>
      )}
    </>
  );
}
