import { useState, type FormEvent } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { FileText, Sparkles, Bookmark } from "lucide-react";
import { useResource, useApp } from "../lib/state";
import { api, json } from "../lib/api";
import type { Document } from "../types";
import {
  Heading,
  Field,
  Button,
  ErrorBox,
  Markdown,
  Empty,
  Loading,
} from "../components/ui";
const modes = [
  ["short", "Short summary", "The essentials in a few paragraphs."],
  ["detailed", "Detailed summary", "A deeper, structured understanding."],
  [
    "sections",
    "Section summaries",
    "Detected headings, or page-grouped notes.",
  ],
  ["concepts", "Key concepts", "The big ideas and their connections."],
  ["definitions", "Important definitions", "Terminology, clearly explained."],
  ["revision", "Revision notes", "Focused notes for your next exam."],
];
export default function Summaries() {
  const docs = useResource<Document[]>("/documents");
  const { notify } = useApp();
  const [params] = useSearchParams();
  const [id, setId] = useState(params.get("doc") || ""),
    [mode, setMode] = useState("short"),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [result, setResult] = useState<{
      summary: string;
      batches_processed: number;
    } | null>(null);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    setResult(null);
    try {
      setResult(
        await api(`/documents/${id}/summarize`, json("POST", { mode })),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function save() {
    if (!result) return;
    try {
      await api(
        "/notes",
        json("POST", {
          title:
            `${modes.find((m) => m[0] === mode)?.[1]}: ${docs.data?.find((d) => d.id === id)?.name}`.slice(
              0,
              200,
            ),
          subject: "General",
          content: result.summary,
        }),
      );
      notify("Summary saved to notes.");
    } catch (e) {
      notify((e as Error).message, true);
    }
  }
  return (
    <>
      <Heading
        eyebrow="READ LESS NOISE. REMEMBER MORE."
        title="PDF summarizer"
        description="Turn long reading into useful understanding—with your local model."
      />
      {docs.loading ? (
        <Loading />
      ) : docs.error ? (
        <ErrorBox message={docs.error} />
      ) : !docs.data?.length ? (
        <div className="card">
          <Empty
            title="Start with a document"
            description="Upload a text-based PDF before creating your first summary."
            action={
              <Link className="button" to="/documents">
                Upload a PDF
              </Link>
            }
          />
        </div>
      ) : (
        <div className="summary-layout">
          <form className="card summary-config" onSubmit={submit}>
            <h2>Build your study notes</h2>
            <Field label="Choose a document">
              <select
                value={id}
                onChange={(e) => {
                  setId(e.target.value);
                  setResult(null);
                }}
                required
                disabled={busy}
              >
                <option value="">Select from your library</option>
                {docs.data.map((d) => (
                  <option value={d.id} key={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
            </Field>
            <fieldset disabled={busy}>
              <legend>What do you need?</legend>
              <div className="summary-modes">
                {modes.map(([value, title, desc]) => (
                  <label
                    className={`summary-mode ${mode === value ? "selected" : ""}`}
                    key={value}
                  >
                    <input
                      type="radio"
                      name="mode"
                      value={value}
                      checked={mode === value}
                      onChange={() => {
                        setMode(value);
                        setResult(null);
                      }}
                    />
                    <div>
                      <strong>{title}</strong>
                      <span>{desc}</span>
                    </div>
                  </label>
                ))}
              </div>
            </fieldset>
            <Button
              busy={busy}
              className="full-width"
              type="submit"
              disabled={!id}
            >
              <Sparkles size={17} />
              Generate study notes
            </Button>
            <p className="muted small">
              Long documents are processed in batches and combined. This may
              take several minutes on a CPU.
            </p>
          </form>
          <section className="card summary-output">
            {error && <ErrorBox message={error} />}{" "}
            {busy ? (
              <Loading label="Reading each document batch with your local model…" />
            ) : result ? (
              <>
                <div className="card-heading">
                  <h2>Your study notes</h2>
                  <Button className="secondary" onClick={() => void save()}>
                    <Bookmark size={16} />
                    Save
                  </Button>
                </div>
                <span className="badge">
                  {result.batches_processed} source batch(es) processed
                </span>
                <Markdown text={result.summary} />
                <p className="muted small">
                  AI-generated notes: verify important facts against the
                  original PDF.
                </p>
              </>
            ) : (
              <Empty
                title="The important parts, brought together"
                description="Select a document and a format. Your generated notes will appear here."
                action={<FileText size={25} className="muted" />}
              />
            )}
          </section>
        </div>
      )}
    </>
  );
}
