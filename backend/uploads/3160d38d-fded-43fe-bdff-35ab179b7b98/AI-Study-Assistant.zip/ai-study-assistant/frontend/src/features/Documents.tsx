import { useEffect, useRef, useState, type FormEvent } from "react";
import { useSearchParams, Link } from "react-router-dom";
import {
  Upload,
  FileText,
  Trash2,
  ExternalLink,
  RefreshCw,
  Send,
  Bookmark,
} from "lucide-react";
import { useApp, useResource } from "../lib/state";
import { api, json } from "../lib/api";
import type { Document } from "../types";
import {
  Heading,
  Button,
  Empty,
  ErrorBox,
  Loading,
  Markdown,
  Field,
} from "../components/ui";
type Answer = {
  answer: string;
  sources: { id: string; page: number; text: string }[];
};
export default function Documents() {
  const docs = useResource<Document[]>("/documents");
  const { notify } = useApp();
  const [params, setParams] = useSearchParams();
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false),
    [indexing, setIndexing] = useState(false),
    [asking, setAsking] = useState(false),
    [error, setError] = useState(""),
    [question, setQuestion] = useState(""),
    [answer, setAnswer] = useState<Answer | null>(null);
  const selected = docs.data?.find((d) => d.id === params.get("doc"));
  useEffect(() => {
    setAnswer(null);
    setQuestion("");
    setError("");
  }, [params]);
  async function upload(file: File | undefined) {
    if (!file) return;
    if (
      !file.name.toLowerCase().endsWith(".pdf") ||
      file.size > 20 * 1024 * 1024
    ) {
      setError("Select a PDF no larger than 20 MB.");
      return;
    }
    setBusy(true);
    setError("");
    const form = new FormData();
    form.append("file", file);
    try {
      const doc = await api<Document>("/documents/upload", {
        method: "POST",
        body: form,
      });
      await docs.reload();
      setParams({ doc: doc.id });
      notify(
        doc.status === "ready"
          ? "PDF uploaded and indexed."
          : "PDF uploaded; text extracted. Local indexing still needs setup.",
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
      if (input.current) input.current.value = "";
    }
  }
  async function remove(doc: Document) {
    if (!confirm(`Delete ${doc.name} and its local retrieval index?`)) return;
    try {
      await api(`/documents/${doc.id}`, json("DELETE"));
      await docs.reload();
      if (selected?.id === doc.id) setParams({});
      notify("Document deleted.");
    } catch (e) {
      notify((e as Error).message, true);
    }
  }
  async function reindex() {
    if (!selected) return;
    setIndexing(true);
    setError("");
    try {
      await api(`/documents/${selected.id}/index`, json("POST"));
      await docs.reload();
      notify("Local retrieval index is ready.");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setIndexing(false);
    }
  }
  async function ask(e: FormEvent) {
    e.preventDefault();
    if (!selected) return;
    setAsking(true);
    setError("");
    setAnswer(null);
    try {
      setAnswer(
        await api<Answer>(
          `/documents/${selected.id}/ask`,
          json("POST", { question }),
        ),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setAsking(false);
    }
  }
  async function save() {
    if (!answer || !selected) return;
    try {
      await api(
        "/notes",
        json("POST", {
          title: question.slice(0, 100),
          subject: "General",
          content:
            answer.answer +
            "\n\nSource: " +
            selected.name +
            "\n" +
            answer.sources.map((s) => `Page ${s.page}: ${s.text}`).join("\n\n"),
        }),
      );
      notify("Document answer and passages saved.");
    } catch (e) {
      notify((e as Error).message, true);
    }
  }
  return (
    <>
      <Heading
        eyebrow="YOUR PERSONAL STUDY LIBRARY"
        title="My documents"
        description="Bring your course materials. Ask better questions. Find the important parts."
        action={
          <Button busy={busy} onClick={() => input.current?.click()}>
            <Upload size={17} />
            Upload PDF
          </Button>
        }
      />
      <input
        ref={input}
        type="file"
        accept="application/pdf,.pdf"
        className="sr-only"
        aria-label="Upload PDF file"
        onChange={(e) => void upload(e.target.files?.[0])}
      />
      {error && <ErrorBox message={error} />}
      {docs.error && (
        <ErrorBox message={docs.error} retry={() => void docs.reload()} />
      )}
      <button
        className="upload-zone"
        disabled={busy}
        onClick={() => input.current?.click()}
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          if (!busy) void upload(e.dataTransfer.files[0]);
        }}
      >
        <div className="icon-tile">
          <Upload size={24} />
        </div>
        <strong>
          {busy
            ? "Extracting text and preparing local retrieval…"
            : "Drop your PDF here, or browse files"}
        </strong>
        <span>
          Text-based PDFs · Up to 20 MB and 400 pages · Stored locally
        </span>
      </button>
      {docs.loading ? (
        <Loading />
      ) : !docs.data?.length ? (
        <div className="card">
          <Empty
            title="Make your reading work harder"
            description="Upload lecture notes, a textbook chapter, or a paper. Your library is currently empty."
          />
        </div>
      ) : (
        <div className="documents-layout">
          <section className="card document-library">
            <h2>
              Library <span className="count">{docs.data.length}</span>
            </h2>
            {docs.data.map((doc) => (
              <div
                className={`library-item ${doc.id === selected?.id ? "selected" : ""}`}
                key={doc.id}
              >
                <button
                  className="library-select"
                  disabled={asking || indexing}
                  onClick={() => setParams({ doc: doc.id })}
                >
                  <div className="pdf-icon">
                    <FileText size={22} />
                  </div>
                  <div>
                    <strong>{doc.name}</strong>
                    <small>
                      {doc.pages} pages · {(doc.size / 1024).toFixed(0)} KB
                    </small>
                    <span
                      className={`badge ${doc.status === "ready" ? "success" : "warning"}`}
                    >
                      {doc.status === "ready" ? "Indexed" : "Text only"}
                    </span>
                  </div>
                </button>
                <button
                  aria-label={`Delete ${doc.name}`}
                  className="icon-button"
                  disabled={asking || indexing}
                  onClick={() => void remove(doc)}
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
          </section>
          <section className="card document-detail">
            {!selected ? (
              <Empty
                title="Choose a document"
                description="Select a PDF from your library to see its details and ask questions."
              />
            ) : (
              <>
                <div className="card-heading">
                  <h2>{selected.name}</h2>
                  <a
                    className="icon-button"
                    href={`/api/documents/${selected.id}/file`}
                    target="_blank"
                    rel="noreferrer"
                    aria-label="Open original PDF"
                  >
                    <ExternalLink size={19} />
                  </a>
                </div>
                <div className="document-meta">
                  <span>{selected.pages} pages</span>
                  <span>{(selected.size / 1024 / 1024).toFixed(2)} MB</span>
                  <span>
                    {new Date(selected.created_at).toLocaleDateString()}
                  </span>
                </div>
                <p
                  className={`processing-note ${selected.status !== "ready" ? "warning-note" : ""}`}
                >
                  {selected.processing_message}
                </p>
                <div className="document-actions">
                  {selected.status !== "ready" && (
                    <Button
                      className="secondary"
                      busy={indexing}
                      onClick={() => void reindex()}
                    >
                      <RefreshCw size={16} />
                      Retry local indexing
                    </Button>
                  )}
                  <Link
                    to={`/summaries?doc=${selected.id}`}
                    className="button secondary"
                  >
                    <FileText size={16} />
                    Create summary
                  </Link>
                </div>
                <hr />
                <h3>Ask this document</h3>
                <p className="muted small">
                  Answers use retrieved passages. Open the original PDF to
                  verify references.
                </p>
                <form onSubmit={ask}>
                  <Field label="Your question">
                    <textarea
                      value={question}
                      onChange={(e) => setQuestion(e.target.value)}
                      maxLength={2000}
                      placeholder="What are the key ideas in this chapter?"
                      required
                      rows={3}
                      disabled={asking}
                    />
                  </Field>
                  <Button
                    busy={asking}
                    disabled={selected.status !== "ready"}
                    type="submit"
                  >
                    <Send size={16} />
                    Ask document
                  </Button>
                </form>
                {answer && (
                  <div className="document-answer">
                    <Markdown text={answer.answer} />
                    <Button className="secondary" onClick={() => void save()}>
                      <Bookmark size={16} />
                      Save answer
                    </Button>
                    <h3>Source passages</h3>
                    {answer.sources.length ? (
                      answer.sources.map((source) => (
                        <details key={source.id}>
                          <summary>
                            Page {source.page} · {source.id}
                          </summary>
                          <p>{source.text}</p>
                          <a
                            className="text-link"
                            href={`/api/documents/${selected.id}/file#page=${source.page}`}
                            target="_blank"
                            rel="noreferrer"
                          >
                            View page <ExternalLink size={14} />
                          </a>
                        </details>
                      ))
                    ) : (
                      <p className="muted small">
                        No source passages cited. Treat this answer as
                        insufficiently grounded.
                      </p>
                    )}
                  </div>
                )}
              </>
            )}
          </section>
        </div>
      )}
    </>
  );
}
