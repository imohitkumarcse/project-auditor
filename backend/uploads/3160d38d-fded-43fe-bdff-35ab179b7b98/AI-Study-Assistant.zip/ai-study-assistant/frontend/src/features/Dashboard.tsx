import { Link } from "react-router-dom";
import {
  ArrowUpRight,
  MessagesSquare,
  Upload,
  ListChecks,
  FileText,
  CalendarDays,
  NotebookPen,
  CheckCircle2,
  Clock,
  Plus,
  ArrowRight,
  BookOpen,
  Sparkles,
} from "lucide-react";
import { useResource, useApp } from "../lib/state";
import { api, json, localDate } from "../lib/api";
import type { Dashboard as Data, Task } from "../types";
import { Heading, CardTitle, Loading, ErrorBox, Empty } from "../components/ui";
export default function Dashboard() {
  const { data, loading, error, reload } = useResource<Data>("/dashboard");
  const { notify } = useApp();
  if (loading) return <Loading />;
  if (error) return <ErrorBox message={error} retry={() => void reload()} />;
  if (!data) return null;
  const today = localDate(),
    tasks = data.tasks.filter((t) => t.due_date === today),
    percent = data.stats.tasks
      ? Math.round((data.stats.completed / data.stats.tasks) * 100)
      : 0;
  async function toggle(task: Task) {
    try {
      await api(
        `/tasks/${task.id}`,
        json("PATCH", { completed: !task.completed }),
      );
      await reload();
    } catch (e) {
      notify((e as Error).message, true);
    }
  }
  return (
    <>
      <Heading
        eyebrow={new Date().toLocaleDateString(undefined, {
          weekday: "long",
          month: "long",
          day: "numeric",
        })}
        title={`Good to see you, ${data.user.name.split(" ")[0]}.`}
        description="A little progress today goes a long way."
        action={
          <Link className="button secondary" to="/planner">
            <Plus size={17} />
            Plan a study session
          </Link>
        }
      />
      <section className="welcome-panel">
        <div>
          <span className="hero-kicker">
            <Sparkles size={15} />
            YOUR PERSONAL LEARNING SPACE
          </span>
          <h2>
            Less overwhelm.
            <br />
            More understanding.
          </h2>
          <p>
            Ask a question, explore your notes, or practice something new.
            <br className="desktop-break" />
            Your next breakthrough is one study session away.
          </p>
          <Link className="button" to="/tutor">
            Start learning <ArrowRight size={17} />
          </Link>
        </div>
        <div className="hero-visual" aria-hidden="true">
          <div className="visual-orbit orbit-one" />
          <div className="visual-orbit orbit-two" />
          <div className="visual-center">
            <BookOpen size={42} />
          </div>
          <div className="visual-label label-top">
            <CheckCircle2 size={16} />
            One concept at a time
          </div>
          <div className="visual-label label-bottom">
            <Sparkles size={16} />
            Built around you
          </div>
        </div>
      </section>
      <div className="stat-grid">
        {[
          [FileText, "Documents", data.stats.documents, "Your study library"],
          [
            CheckCircle2,
            "Tasks completed",
            data.stats.completed,
            `${data.stats.tasks} total tasks`,
          ],
          [NotebookPen, "Saved notes", data.stats.notes, "Ideas worth keeping"],
          [
            Clock,
            "Planned today",
            `${tasks.filter((t) => !t.completed).reduce((s, t) => s + t.duration, 0)} min`,
            "Upcoming study time",
          ],
        ].map(([Icon, label, value, caption]) => {
          const I = Icon as typeof FileText;
          return (
            <div className="stat-card" key={String(label)}>
              <div className="stat-icon">
                <I size={19} />
              </div>
              <div>
                <p>{String(label)}</p>
                <strong>{value as string | number}</strong>
                <small>{String(caption)}</small>
              </div>
            </div>
          );
        })}
      </div>
      <section className="quick-section">
        <div className="section-caption">PICK UP WHERE CURIOSITY TAKES YOU</div>
        <div className="quick-grid">
          {[
            [
              MessagesSquare,
              "Ask your AI tutor",
              "Make a tricky concept click.",
              "/tutor",
            ],
            [
              Upload,
              "Upload a PDF",
              "Turn reading into understanding.",
              "/documents",
            ],
            [
              ListChecks,
              "Practice with a quiz",
              "Find out what you really know.",
              "/quizzes",
            ],
            [
              FileText,
              "Create a summary",
              "The key ideas, without the noise.",
              "/summaries",
            ],
          ].map(([Icon, title, description, to]) => {
            const I = Icon as typeof Upload;
            return (
              <Link className="quick-card" to={String(to)} key={String(to)}>
                <I size={23} />
                <ArrowUpRight className="quick-arrow" size={18} />
                <h3>{String(title)}</h3>
                <p>{String(description)}</p>
              </Link>
            );
          })}
        </div>
      </section>
      <div className="dashboard-columns">
        <section className="card">
          <CardTitle
            title="Today's study plan"
            link="Open planner"
            to="/planner"
          />
          {tasks.length ? (
            <div className="task-list">
              {tasks.map((task) => (
                <div className="task-row" key={task.id}>
                  <input
                    type="checkbox"
                    aria-label={`Complete ${task.title}`}
                    checked={task.completed}
                    onChange={() => void toggle(task)}
                  />
                  <div className={task.completed ? "completed-text" : ""}>
                    <strong>{task.title}</strong>
                    <small>
                      {task.subject} · {task.duration} min
                    </small>
                  </div>
                  <span className={`badge priority-${task.priority}`}>
                    {task.priority}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <Empty
              title="A fresh day, a clear plan"
              description="Add your first study session for today."
              action={
                <Link className="text-link" to="/planner">
                  Plan your day <ArrowRight size={15} />
                </Link>
              }
            />
          )}
          <div className="progress-footer">
            <div>
              <span>Overall task progress</span>
              <strong>{percent}%</strong>
            </div>
            <progress
              value={data.stats.completed}
              max={data.stats.tasks || 1}
              aria-label="Overall task progress"
            />
            <small>
              {data.stats.completed} of {data.stats.tasks} tasks completed
            </small>
          </div>
        </section>
        <section className="card">
          <CardTitle title="Recent documents" to="/documents" />
          {data.documents.length ? (
            <div className="document-list">
              {data.documents.map((doc) => (
                <Link
                  className="document-row"
                  key={doc.id}
                  to={`/documents?doc=${doc.id}`}
                >
                  <div className="pdf-icon">
                    <FileText size={21} />
                  </div>
                  <div>
                    <strong>{doc.name}</strong>
                    <small>
                      {doc.pages} pages ·{" "}
                      {doc.status === "ready"
                        ? "Ready to study"
                        : "Text extracted; indexing needed"}
                    </small>
                  </div>
                  <ArrowUpRight size={16} />
                </Link>
              ))}
            </div>
          ) : (
            <Empty
              title="Your library starts here"
              description="Upload a PDF to make your study material easier to explore."
              action={
                <Link to="/documents" className="text-link">
                  Upload your first PDF <Upload size={15} />
                </Link>
              }
            />
          )}
        </section>
      </div>
      <section className="card recent-conversations">
        <CardTitle title="Recent conversations" to="/tutor" />
        {data.conversations.length ? (
          <div className="conversation-grid">
            {data.conversations.map((c) => (
              <Link to={`/tutor?conversation=${c.id}`} key={c.id}>
                <MessagesSquare size={19} />
                <div>
                  <strong>{c.title}</strong>
                  <small>{c.subject}</small>
                </div>
                <ArrowUpRight size={16} />
              </Link>
            ))}
          </div>
        ) : (
          <div className="inline-empty">
            <CalendarDays size={20} />
            <span>
              No conversations yet. Bring a question; we’ll help you work
              through it.
            </span>
            <Link to="/tutor" className="text-link">
              Ask a question <ArrowRight size={14} />
            </Link>
          </div>
        )}
      </section>
    </>
  );
}
