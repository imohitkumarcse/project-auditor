import { useState, type FormEvent } from "react";
import {
  RefreshCw,
  ShieldCheck,
  Server,
  GraduationCap,
  Monitor,
} from "lucide-react";
import { api, json, subjects, styles } from "../lib/api";
import { useApp, useResource } from "../lib/state";
import type { User, AIStatus } from "../types";
import { Heading, Field, Button, ErrorBox, Loading } from "../components/ui";
export default function Settings() {
  const { user, setUser, notify } = useApp();
  const status = useResource<AIStatus>("/health/ai");
  const backend = useResource<{ status: string }>("/health");
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    setBusy(true);
    setError("");
    try {
      setUser(
        await api<User>(
          "/auth/me",
          json("PATCH", {
            name: form.get("name"),
            subject: form.get("subject"),
            explanation_style: form.get("explanation_style"),
            theme: form.get("theme"),
          }),
        ),
      );
      notify("Preferences updated.");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Heading
        eyebrow="MAKE THIS SPACE YOURS"
        title="Settings"
        description="Your profile, your preferences, your local learning setup."
      />
      <div className="settings-layout">
        <form className="card" onSubmit={submit}>
          <h2>Profile & preferences</h2>
          {error && <ErrorBox message={error} />}
          <Field label="Full name">
            <input
              name="name"
              defaultValue={user?.name}
              minLength={2}
              maxLength={80}
              required
            />
          </Field>
          <Field
            label="Email address"
            hint="Email changes are not supported in this version."
          >
            <input type="email" value={user?.email || ""} readOnly />
          </Field>
          <div className="form-grid">
            <Field label="Preferred subject">
              <select name="subject" defaultValue={user?.subject}>
                {subjects.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </Field>
            <Field label="Explanation style">
              <select
                name="explanation_style"
                defaultValue={user?.explanation_style}
              >
                {styles.map(([v, l]) => (
                  <option value={v} key={v}>
                    {l}
                  </option>
                ))}
              </select>
            </Field>
          </div>
          <Field label="Appearance">
            <select name="theme" defaultValue={user?.theme}>
              <option value="system">Use system preference</option>
              <option value="light">Light</option>
              <option value="dark">Dark</option>
            </select>
          </Field>
          <Button busy={busy} type="submit">
            Save preferences
          </Button>
        </form>
        <div className="settings-stack">
          <section className="card">
            <div className="card-heading">
              <h2>Connection status</h2>
              <button
                className="icon-button"
                onClick={() => {
                  void status.reload();
                  void backend.reload();
                }}
                aria-label="Refresh connection status"
              >
                <RefreshCw size={18} />
              </button>
            </div>
            <div className="connection-row">
              <Server size={21} />
              <div>
                <strong>FastAPI backend</strong>
                <small>
                  {backend.loading
                    ? "Checking…"
                    : backend.error || "Connected to your local backend"}
                </small>
              </div>
              <span className={`badge ${backend.data ? "success" : "warning"}`}>
                {backend.data ? "Online" : "Offline"}
              </span>
            </div>
            <div className="connection-row">
              <GraduationCap size={22} />
              <div>
                <strong>Local Ollama model</strong>
                <small>{status.data?.model || "Checking configuration…"}</small>
              </div>
              <span
                className={`badge ${status.data?.available ? "success" : "warning"}`}
              >
                {status.data?.available ? "Ready" : "Unavailable"}
              </span>
            </div>
            {status.loading ? (
              <Loading label="Checking local model…" />
            ) : status.error ? (
              <ErrorBox message={status.error} />
            ) : (
              <p className="processing-note">{status.data?.message}</p>
            )}
          </section>
          <section className="card privacy-card">
            <ShieldCheck size={25} />
            <h2>Local by design</h2>
            <p>
              Your tutor calls a loopback Ollama server. PDFs are extracted
              locally and use local embedding models—never a hosted inference or
              embedding API.
            </p>
            <p>
              Database files and uploaded PDFs are stored on the backend
              machine. They are not encrypted at rest; protect your device and
              backups.
            </p>
            <div>
              <Monitor size={17} />
              CPU performance varies. A GPU can improve latency.
            </div>
          </section>
        </div>
      </div>
    </>
  );
}
