export type User = {
  id: string;
  name: string;
  email: string;
  subject: string;
  explanation_style: string;
  theme: "light" | "dark" | "system";
};
export type Task = {
  id: string;
  title: string;
  subject: string;
  priority: "low" | "medium" | "high";
  due_date: string;
  duration: number;
  completed: boolean;
  revision: boolean;
};
export type Document = {
  id: string;
  name: string;
  size: number;
  pages: number;
  status: string;
  processing_message: string;
  created_at: string;
};
export type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  created_at?: string;
};
export type Conversation = {
  id: string;
  title: string;
  subject: string;
  created_at: string;
  messages?: Message[];
};
export type Note = {
  id: string;
  title: string;
  subject: string;
  content: string;
  created_at: string;
};
export type AIStatus = {
  available: boolean;
  runtime_connected: boolean;
  model: string;
  message: string;
};
export type Dashboard = {
  user: User;
  tasks: Task[];
  documents: Document[];
  conversations: Conversation[];
  stats: { tasks: number; completed: number; documents: number; notes: number };
  demo: boolean;
};
export type Quiz = {
  id: string;
  title: string;
  questions: { question: string; options: string[] }[];
};
export type QuizReview = {
  score: number;
  total: number;
  answers: number[];
  questions: {
    question: string;
    options: string[];
    correct_index: number;
    explanation: string;
  }[];
};
