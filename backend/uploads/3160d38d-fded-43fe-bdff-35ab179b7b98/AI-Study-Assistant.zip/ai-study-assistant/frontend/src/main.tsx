import React from "react";
import ReactDOM from "react-dom/client";
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  Outlet,
  Link,
} from "react-router-dom";
import { AppProvider, useApp } from "./lib/state";
import { Loading } from "./components/ui";
import Layout from "./components/Layout";
import Auth from "./features/Auth";
import Dashboard from "./features/Dashboard";
import Tutor from "./features/Tutor";
import Documents from "./features/Documents";
import Summaries from "./features/Summaries";
import Quizzes from "./features/Quizzes";
import Planner from "./features/Planner";
import Notes from "./features/Notes";
import Settings from "./features/Settings";
import "./styles.css";
function Protected() {
  const { user, initializing } = useApp();
  if (initializing) return <Loading />;
  return user ? <Outlet /> : <Navigate to="/login" replace />;
}
function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <Routes>
          <Route path="login" element={<Auth />} />
          <Route path="register" element={<Auth register />} />
          <Route element={<Protected />}>
            <Route element={<Layout />}>
              <Route index element={<Dashboard />} />
              <Route path="tutor" element={<Tutor />} />
              <Route path="documents" element={<Documents />} />
              <Route path="summaries" element={<Summaries />} />
              <Route path="quizzes" element={<Quizzes />} />
              <Route path="planner" element={<Planner />} />
              <Route path="notes" element={<Notes />} />
              <Route path="settings" element={<Settings />} />
              <Route
                path="*"
                element={
                  <div className="card">
                    <h1>Page not found</h1>
                    <Link className="button" to="/">
                      Back to your workspace
                    </Link>
                  </div>
                }
              />
            </Route>
          </Route>
        </Routes>
      </AppProvider>
    </BrowserRouter>
  );
}
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
