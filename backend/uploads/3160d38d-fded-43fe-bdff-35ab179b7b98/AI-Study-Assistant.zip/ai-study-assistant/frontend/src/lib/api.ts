export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}
export async function api<T>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`/api${path}`, {
      ...options,
      credentials: "include",
      headers:
        options.body instanceof FormData
          ? options.headers
          : { "Content-Type": "application/json", ...options.headers },
    });
  } catch {
    throw new ApiError(
      "Backend is unreachable. Start FastAPI on port 8000 and try again.",
      0,
    );
  }
  if (response.status === 204) return undefined as T;
  const body = await response.json().catch(() => ({
    error: { message: "The server returned an unreadable response." },
  }));
  if (!response.ok) {
    const fields = body.error?.fields
      ?.map(
        (f: { field: string; message: string }) => `${f.field}: ${f.message}`,
      )
      .join(" ");
    throw new ApiError(
      fields || body.error?.message || "Request failed.",
      response.status,
    );
  }
  return body as T;
}
export const json = (method: string, data?: unknown): RequestInit => ({
  method,
  body: data === undefined ? undefined : JSON.stringify(data),
});
export const subjects = [
  "Python",
  "Data Structures",
  "DBMS",
  "Computer Organization",
  "Digital Electronics",
  "Discrete Structures",
  "General",
];
export const styles = [
  ["beginner", "Beginner-friendly"],
  ["step-by-step", "Step by step"],
  ["example", "Give an example"],
  ["exam", "Exam-oriented"],
  ["practice", "Practice questions"],
];
export function localDate(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
export function displayDate(value: string) {
  return new Date(value + "T12:00:00").toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
  });
}
