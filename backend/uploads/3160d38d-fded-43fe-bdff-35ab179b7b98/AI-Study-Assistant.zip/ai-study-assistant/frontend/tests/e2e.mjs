import { chromium } from "playwright";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
const base = process.env.APP_URL || "http://127.0.0.1:5173";
const out =
  process.env.QA_OUTPUT ||
  fileURLToPath(new URL("../../docs/qa/", import.meta.url));
fs.mkdirSync(out, { recursive: true });
const browser = await chromium.launch({
  ...(process.env.CHROMIUM_PATH
    ? { executablePath: process.env.CHROMIUM_PATH }
    : {}),
  headless: true,
  args: ["--no-sandbox"],
});
const context = await browser.newContext({
  viewport: { width: 1440, height: 1000 },
  colorScheme: "light",
});
const page = await context.newPage();
const errors = [],
  results = [];
page.on("pageerror", (e) => errors.push(e.message));

async function check(name, fn) {
  try {
    await fn();
    results.push({ name, result: "PASS" });
  } catch (e) {
    results.push({ name, result: "FAIL", error: e.message });
    throw e;
  }
}
async function shot(name) {
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${out}/${name}.png`, fullPage: true });
  if (name === "dashboard-desktop") {
    fs.writeFileSync(
      `${out}/dashboard-preview.html`,
      await page.evaluate(() => {
        const html = document.documentElement.cloneNode(true);
        html.querySelectorAll("script").forEach((s) => s.remove());
        return "<!doctype html>" + html.outerHTML;
      }),
    );
  }
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth > window.innerWidth,
  );
  if (overflow) throw new Error(`Horizontal overflow: ${name}`);
}
const email = `qa-${Date.now()}@example.edu`,
  password = "local-study-test-123";
try {
  await page.goto(base + "/login");
  await page.getByRole("heading", { name: "Welcome back" }).waitFor();
  await shot("login-desktop");
  await page.goto(base + "/register");
  await shot("register-desktop");
  await check("Registration and protected dashboard", async () => {
    await page.getByLabel("Full name").fill("QA Student");
    await page.getByLabel("Email address").fill(email);
    await page.getByLabel("Password", { exact: true }).fill(password);
    await page.getByRole("button", { name: "Create account" }).click();
    await page.getByRole("heading", { name: "Good to see you, QA." }).waitFor();
  });
  await shot("dashboard-empty-desktop");
  await page.goto(base + "/planner");
  await check("Planner create, edit and complete", async () => {
    await page
      .getByRole("button", { name: "Add study session", exact: true })
      .click();
    await page
      .getByLabel("What will you study?")
      .fill("QA: Revise database transactions");
    await page.getByLabel("Subject", { exact: true }).selectOption("DBMS");
    await page.getByLabel("Add to revision checklist").check();
    await page.getByRole("button", { name: "Save session" }).click();
    await page
      .getByText("QA: Revise database transactions", { exact: true })
      .waitFor();
    await page
      .getByRole("button", { name: "Edit QA: Revise database transactions" })
      .click();
    await page.getByLabel("Duration (minutes)").fill("45");
    await shot("planner-modal-desktop");
    await page.getByRole("button", { name: "Save session" }).click();
    await page
      .getByRole("checkbox", {
        name: "Mark QA: Revise database transactions complete",
      })
      .click();
    await page
      .getByRole("checkbox", {
        name: "Mark QA: Revise database transactions incomplete",
      })
      .waitFor();
  });
  await page.goto(base + "/notes");
  await check("Notes create, search and read", async () => {
    await page.getByRole("button", { name: "New note" }).click();
    await page.getByLabel("Title", { exact: true }).fill("QA: ACID properties");
    await page.getByLabel("Subject", { exact: true }).selectOption("DBMS");
    await page
      .getByLabel("Your notes")
      .fill(
        "## Transaction foundations\n\n- **Atomicity:** all or nothing.\n- **Consistency:** valid database states.\n- **Isolation:** concurrent work stays separated.\n- **Durability:** committed work persists.\n\nQA fixture created by an automated test, not demo app data.",
      );
    await page.getByRole("button", { name: "Save note", exact: true }).click();
    await page.getByRole("dialog").waitFor();
    await shot("notes-read-desktop");
    await page.getByRole("button", { name: "Close dialog" }).click();
    await page.getByRole("textbox", { name: "Search notes" }).fill("ACID");
    await page.getByRole("heading", { name: "QA: ACID properties" }).waitFor();
  });
  await page.goto(base + "/documents");
  await check("PDF upload with honest processing status", async () => {
    await page
      .getByLabel("Upload PDF file")
      .setInputFiles(
        fileURLToPath(new URL("./fixtures/chapter.pdf", import.meta.url)),
      );
    await page
      .getByRole("heading", { name: "chapter.pdf", exact: true })
      .waitFor({ timeout: 120000 });
  });
  await shot("documents-detail-desktop");
  await page.goto(base + "/tutor");
  await check(
    "Unavailable AI produces an error, not a saved response",
    async () => {
      await page.getByLabel("Your question").fill("Explain recursion");
      await page.getByRole("button", { name: "Send message" }).click();
      await page
        .getByRole("alert")
        .filter({ hasText: "Cannot reach the local Ollama" })
        .waitFor();
      const conversations = await context.request.get(
        base + "/api/conversations",
      );
      if ((await conversations.json()).length !== 0)
        throw new Error("Failed AI request saved a conversation");
    },
  );
  await shot("tutor-error-desktop");
  await page.goto(base + "/quizzes");
  await check("Quiz unavailable error", async () => {
    await page
      .getByLabel("Topic", { exact: true })
      .fill("Database transactions");
    await page.getByRole("button", { name: "Generate quiz" }).click();
    await page
      .getByRole("alert")
      .filter({ hasText: "Cannot reach the local Ollama" })
      .waitFor();
  });
  await page.goto(base + "/summaries");
  await check("Summary unavailable error", async () => {
    await page
      .getByLabel("Choose a document")
      .selectOption({ label: "chapter.pdf" });
    await page.getByRole("button", { name: "Generate study notes" }).click();
    await page
      .getByRole("alert")
      .filter({ hasText: "Cannot reach the local Ollama" })
      .waitFor();
  });
  for (const [route, name] of [
    ["", "dashboard"],
    ["tutor", "tutor"],
    ["documents", "documents"],
    ["summaries", "summaries"],
    ["quizzes", "quizzes"],
    ["planner", "planner"],
    ["notes", "notes"],
    ["settings", "settings"],
  ]) {
    await page.goto(`${base}/${route}`);
    await page.locator("main h1").waitFor();
    await page.waitForTimeout(500);
    await shot(`${name}-desktop`);
  }
  await check("Saved theme preference", async () => {
    await page.getByLabel("Appearance").selectOption("dark");
    await page.getByRole("button", { name: "Save preferences" }).click();
    await page.waitForFunction(
      () => document.documentElement.dataset.theme === "dark",
    );
    await shot("settings-dark-desktop");
    await page.getByLabel("Appearance").selectOption("light");
    await page.getByRole("button", { name: "Save preferences" }).click();
    await page.waitForFunction(
      () => document.documentElement.dataset.theme === "light",
    );
  });
  await page.setViewportSize({ width: 390, height: 844 });
  for (const [route, name] of [
    ["", "dashboard"],
    ["tutor", "tutor"],
    ["documents", "documents"],
    ["summaries", "summaries"],
    ["quizzes", "quizzes"],
    ["planner", "planner"],
    ["notes", "notes"],
    ["settings", "settings"],
  ]) {
    await page.goto(`${base}/${route}`);
    await page.locator("main h1").waitFor();
    await page.waitForTimeout(400);
    await shot(`${name}-mobile`);
    if (name === "documents") {
      await page
        .getByRole("button")
        .filter({ hasText: "chapter.pdf" })
        .first()
        .click();
      await shot("documents-detail-mobile");
    }
  }
  await check("Mobile navigation", async () => {
    await page.getByRole("button", { name: "Open navigation" }).click();
    await shot("navigation-mobile");
    await page
      .getByRole("navigation")
      .getByRole("link", { name: "Study planner" })
      .click();
    await page.getByRole("heading", { name: "Study planner" }).waitFor();
  });
  await page
    .getByRole("button", { name: "Add study session", exact: true })
    .click();
  await shot("planner-modal-mobile");
  await page.getByRole("button", { name: "Cancel" }).click();
  await check("Logout and login", async () => {
    await page.getByRole("button", { name: "Sign out" }).click();
    await page.getByRole("heading", { name: "Welcome back" }).waitFor();
    await shot("login-mobile");
    await page.goto(base + "/");
    await page.getByRole("heading", { name: "Welcome back" }).waitFor();
    await page.getByLabel("Email address").fill(email);
    await page.getByLabel("Password", { exact: true }).fill(password);
    await page.getByRole("button", { name: "Sign in", exact: true }).click();
    await page.getByRole("heading", { name: "Good to see you, QA." }).waitFor();
  });
  await page.getByRole("button", { name: "Sign out" }).click();
  await page.goto(base + "/register");
  await shot("register-mobile");
  if (errors.length) throw new Error("Browser errors: " + errors.join("; "));
  results.push({
    name: "All route captures: desktop 1440px and mobile 390px; no horizontal overflow",
    result: "PASS",
  });
} catch (e) {
  console.error(e.message);
  process.exitCode = 1;
} finally {
  fs.writeFileSync(
    out + "/browser-results.json",
    JSON.stringify({ results, browserErrors: errors }, null, 2),
  );
  console.log(JSON.stringify({ results, browserErrors: errors }, null, 2));
  await browser.close();
}
